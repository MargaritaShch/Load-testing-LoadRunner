Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("MSA_DeviceTicket", 
		"t=EwCwAlN5BAAUu1V9OkIAK55tj6h8OjaXgvkszYkAAY9NEMMOG1ZC6Y77F/RDA0mh4UnGvcndoXhMVquNuZ9n8TZIGWc9//xSeF/c4+cV3Vq0aBVFi14JxFEDmbNfa8NriWoVVqcpXpx00LOiHa7WOpLDRDVN+WBoA4WjIxeI+J12n4mFT3uPotLcW31GZ1gDsEWs0bOc+D4Obylokyj98AC93St+benkpdlHHzc+eJUHW2z+12YL4rxo+Wc+k3h0Pp+/m8n04GtBsYQEv41s49MjA2Y0rEdztmIsYGiMaiaHxDAuRkdfCKYduEie4P8hyn4qVRVFvlmNlKszby2o8mOtF1KzDs54Fb6c3yTQSwQJgjowCuCVKanklnxjTAEDZgAACDgQ19u9HbjLgAFb5csmfK1UpLesGa3lheum/JopRJkMQxRj+w2Ve7LGlZ50sqYhdggs8+ggvpf0E4bepv+Ft39o5sShK21ScLw/nzBPHIWi/"
		"yXtCdh1UHcnBtFShZ8gBHWT0uvoVXjjZDT8xAfeDSTOaHkT1RRf769p+xppCxx96FVgeoXm5SnK3wQRfBQkqlFqwG8ppIFBpSsa7sPrREQuHSiTGb4AFiFtLfGTcrnA5nzZAu+We+tkTmYoMshC/BUuwFgN5eQ4/rb84EeDN5jkFcWrOgl+0cUqeqvcvESQLy1pKfgRRBrJqA5ZQqMrxafYLOFADMchmqAxaix92Zwo6GLDi4aBXK2n3p4iFJCzImbQzxZNVwp948aSTR5t5GtBPH77w3BJDKOa7Fgh3COTm7rZQz5hSlO7q3X78E++gsrX4kpKhlmccKRDqDggbV31CwpPibi/SzxcZShOTxThGQmNEG0v47sM5b92nPw/bN8Tk2E2cnV5wCLqWqMuprY6ZfhKp86RSRC2AQ==&p=");

	web_custom_request("Telemetry.Request", 
		"URL=https://nw-umwatson.events.data.microsoft.com/Telemetry.Request", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		"EncType=application/xml", 
		"BodyBinary=\\xD0\\x0E\\x00\\x00<?xml version=\"1.0\"?>\n<req ver=\"2\">\n <tlm>\n  <src>\n   <desc>\n    <mach>\n     <os>\n      <arg nm=\"vermaj\" val=\"10\"/>\n      <arg nm=\"vermin\" val=\"0\"/>\n      <arg nm=\"verbld\" val=\"22621\"/>\n      <arg nm=\"vercsdbld\" val=\"3447\"/>\n      <arg nm=\"verqfe\" val=\"3447\"/>\n      <arg nm=\"csdbld\" val=\"3447\"/>\n      <arg nm=\"versp\" val=\"0\"/>\n      <arg nm=\"arch\" val=\"9\"/>\n      <arg nm=\"lcid\" val=\"1049\"/>\n      <arg nm=\""
		"geoid\" val=\"203\"/>\n      <arg nm=\"sku\" val=\"100\"/>\n      <arg nm=\"domain\" val=\"0\"/>\n      <arg nm=\"portos\" val=\"0\"/>\n      <arg nm=\"ram\" val=\"10178\"/>\n      <arg nm=\"svolsz\" val=\"475\"/>\n      <arg nm=\"wimbt\" val=\"0\"/>\n      <arg nm=\"blddt\" val=\"220506\"/>\n      <arg nm=\"bldtm\" val=\"1250\"/>\n      <arg nm=\"bldbrch\" val=\"ni_release\"/>\n      <arg nm=\"os\" val=\"Windows\"/>\n      <arg nm=\"osver\" val=\"10.0.22621.3447.amd64fre.ni_release.220506-1250\"/"
		">\n      <arg nm=\"buildflightid\" val=\"2C34B461-1255-485F-8845-420F1E8BA2E3.1\"/>\n      <arg nm=\"expid\" val=\"RS:19AAF\"/>\n      <arg nm=\"edition\" val=\"CoreSingleLanguage\"/>\n     </os>\n     <hw>\n      <arg nm=\"form\" val=\"2\"/>\n      <arg nm=\"arch\" val=\"9\"/>\n      <arg nm=\"deviceclass\" val=\"Windows.Desktop\"/>\n      <arg nm=\"sysmfg\" val=\"LENOVO\"/>\n      <arg nm=\"syspro\" val=\"81NC\"/>\n      <arg nm=\"bv\" val=\"AMCN26WW(V1.09)\"/>\n      <arg nm=\"ram\" val=\""
		"12288\"/>\n      <arg nm=\"proccnt\" val=\"8\"/>\n      <arg nm=\"proclsp\" val=\"2296\"/>\n      <arg nm=\"wscpusc\" val=\"0\"/>\n      <arg nm=\"wsdsksc\" val=\"0\"/>\n      <arg nm=\"wscpudn\" val=\"AMD Ryzen 7 3700U with Radeon Vega Mobile Gfx  \"/>\n      <arg nm=\"wsdgsc\" val=\"0\"/>\n      <arg nm=\"aoac\" val=\"0\"/>\n      <arg nm=\"bssku\" val=\"LENOVO_MT_81NC_BU_idea_FM_IdeaPad S340-15API\"/>\n      <arg nm=\"chid\" val=\"{f2def22a-533a-5854-80c0-e4d4975be589}\"/>\n      <arg nm=\""
		"sdksz\" val=\"476\"/>\n     </hw>\n     <ctrl>\n      <arg nm=\"tm\" val=\"133575634989818650\"/>\n      <arg nm=\"mid\" val=\"35B0B1E1-AF52-4219-BA84-001C4F6E30CD\"/>\n      <arg nm=\"sample\" val=\"67722097\"/>\n      <arg nm=\"msft\" val=\"0\"/>\n      <arg nm=\"test\" val=\"0\"/>\n      <arg nm=\"scf\" val=\"0\"/>\n      <arg nm=\"commercialid\" val=\"\"/>\n      <arg nm=\"telemetry\" val=\"Optional\"/>\n     </ctrl>\n    </mach>\n   </desc>\n  </src>\n  <reqs>\n   <req key=\"1\">\n    "
		"<namespace svc=\"watson\" ptr=\"generic\" gp=\"generic\" app=\"msedge.exe\">\n     <arg nm=\"p1\" val=\"msedge.exe\"/>\n     <arg nm=\"p2\" val=\"123.0.2420.81\"/>\n     <arg nm=\"p3\" val=\"msedge_elf.dll\"/>\n     <arg nm=\"p4\" val=\"123.0.2420.81\"/>\n     <arg nm=\"p5\" val=\"3039847\"/>\n     <arg nm=\"p6\" val=\"utility\"/>\n     <arg nm=\"p7\" val=\"0x517a7ed\"/>\n     <arg nm=\"p8\" val=\"0\"/>\n    </namespace>\n    <ctrl>\n     <arg nm=\"reportid\" val=\""
		"e7226fdd-4f28-4639-ba92-c7fe5492de7a\"/>\n     <arg nm=\"procmeta.Channel\" val=\"\"/>\n     <arg nm=\"procmeta.MetricsClientId\" val=\"a9f26822-0148-449d-839d-c1f5b6ea6f6f\"/>\n     <arg nm=\"procmeta.MetricsClientIdHash\" val=\"3337287604877298657\"/>\n     <arg nm=\"procmeta.MetricsSessionId\" val=\"475\"/>\n     <arg nm=\"procmeta.OfficialBuild\" val=\"1\"/>\n     <arg nm=\"procmeta.RuntimeVariationsSeedETag\" val=\"&quot;ak7HcQpnlZn8m9aTyRR+TBlDs+Nu0eAPyPPJlhBg3/g=&quot;\"/>\n     <arg nm=\""
		"procmeta.UXConfigCorrelationId\" val=\"htUAmUE/s5srHwFFnrD6S8HhSDlCxS4N4+NzDmg9iGA=\"/>\n     <arg nm=\"procmeta.VariationsSeedETag\" val=\"&quot;CkuAmlPxHz2CRaInBV6iam5U2dRk7lDEzgtb+B9NUT8=&quot;\"/>\n    </ctrl>\n    <cmd nm=\"event\">\n     <arg nm=\"eventtype\" val=\"crashpad_exp\"/>\n     <arg nm=\"cat\" val=\"generic\"/>\n     <arg nm=\"p1\" val=\"msedge.exe\"/>\n     <arg nm=\"p2\" val=\"123.0.2420.81\"/>\n     <arg nm=\"p3\" val=\"msedge_elf.dll\"/>\n     <arg nm=\"p4\" val=\""
		"123.0.2420.81\"/>\n     <arg nm=\"p5\" val=\"3039847\"/>\n     <arg nm=\"p6\" val=\"utility\"/>\n     <arg nm=\"p7\" val=\"0x517a7ed\"/>\n     <arg nm=\"p8\" val=\"0\"/>\n     <arg nm=\"appsessionguid\" val=\"00003f60-0001-003e-4a1c-0709558eda01\"/>\n    </cmd>\n   </req>\n  </reqs>\n </tlm>\n</req>\n", 
		LAST);

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"123.0.2420.81");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.22621");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	lr_think_time(10);

	web_url("generate_204", 
		"URL=http://edge-http.microsoft.com/captiveportal/generate_204", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("pglt-edgeChromium-ntp=41; DOMAIN=ntp.msn.com");

	web_add_cookie("pglt-edgeChromium-dhp=41; DOMAIN=ntp.msn.com");

	web_add_cookie("_EDGE_V=1; DOMAIN=ntp.msn.com");

	web_add_cookie("MUIDB=054414BB474160B521EF0776469C61F6; DOMAIN=ntp.msn.com");

	web_add_cookie("MicrosoftApplicationsTelemetryDeviceId=659515f7-d611-4844-87ca-1a2d2bf763f3; DOMAIN=ntp.msn.com");

	web_add_cookie("APP_ANON=A=022CDA96091158A16CEFA276FFFFFFFF; DOMAIN=ntp.msn.com");

	web_add_cookie("aace=%7b%22child%22%3a0%7d; DOMAIN=ntp.msn.com");

	web_add_cookie("els=%7b%22account_type%22%3a%22MSA%22%7d; DOMAIN=ntp.msn.com");

	web_add_cookie("MUID=047FE09A36C068D9071EF357375969CA; DOMAIN=ntp.msn.com");

	web_add_cookie("sptmarket=ru||ge|en-xl|en-xl|en||RefA=7934B235D5F64C70AF51B7EA0CB4CB27.RefC=2023-11-18T11:40:36Z; DOMAIN=ntp.msn.com");

	web_add_cookie("USRLOC=BID=MjQwNDE0MTMxNzE0XzZiZGZjZmRkMTIxZDcxNDFhNzNhM2VmNTU5ZGVkY2Q3MGM4MDBjZmM1N2QxN2U1ZTdmMTQ2MWFlNzMwNThmNmE=; DOMAIN=ntp.msn.com");

	web_add_cookie("lt=t=EwBIA6AEAAAU+FEkrYVKODxcga16pzW/y5vRf68AAaEM9XfPeavWIEfjjeKT7MHf55yNQHnDUg6MpIlhw2plF73ZgHIwtNZTTYPnD4cZHv1KuepFlIpFsDeEpufd/pNP2eo6Gh+hygT4KtnV4ywbcdobOUl6PNsI0bu78vYCRTUSqeUA6SDAmjK0GkeyjA6HW+LkOwQMQ5GG3e5psIzWmK6UjCrG6EbU3QihaKHHTRtqGR2ArY1YPxfo9WsiVmDd7mVxMvwUISKj9X9k3rSJ368ZJv3OH/7/UerCCAjFs6E5sT6rXYLAzzX+oPuyLzEQca2DKA3f2RYRWalPHV49F7DgSiiYmW5PaAV5FO6M4v/Jq3gOw5zROt6bXoomqawDZgAACDETXrUahmW2GAKO0pl+"
		"D4iDZCAR5kTxJCJZ2WLafqOXFRPbPLGIGaq8snNpZL3EVIgPzxHP1WPHOtK3M3BmGWwUpi2zBAtK1fQPWiy0WRp9YlHgCBRZI6wEZHl6lMyuX5v/yrOD7iOjCyBC9s6zj8JxOXx8nLXT/dh3UiStmD3ioSW35hOAL+bjcmOtWWG+cIBrab+UjZeyMt3ktO4dT61R0r/BgjulDhAjF4CZKKObVpLXo54iavDo0iP6vsne58h+WnktlAuuiDCN523SoRSwmn80wL2rh66I0MhhNAKQ2sVjzaNF7pD4cQtyuuOLpQs0x3NxzxAHF8pV7AAMWicxbgMTo5uZ9HdKC67yPreh+cTIYTlBqEfrNedw5aVZF/CdFtcrI5CSzOAgcgPxNlg9ZlfXNhjEUXgvRoedm7DjFhlB1JX+VDFbeXnqss3UUjKSgMUohdq2xKl672Yn5MEd1GZXpSOgR0RaG35OrMYj1vlqr125TPs9EMdrT955/Qn/I6ocQW"
		"+BibGMJELQMH+iTMlAI5soraB7GdTdMlrh4SmW0C+vlJVpR5ZPUikPfi/ILlsVukmBlPbd9biYN2VFq0xyGYiYE4JWcJIAw7sk/VGXIX5rCrLbPDbHbUX2iTip4QY34vZCc1yfsNIhzbYxqm2Q39prmdwpezBmNkGWSQ0uERGRNM+aFOZy+HmORImkrBASs2tAo1CY2y1nKyx6YE8C&p=; DOMAIN=ntp.msn.com");

	web_add_cookie("msaoptout=0; DOMAIN=ntp.msn.com");

	web_add_cookie("ANON=A=022CDA96091158A16CEFA276FFFFFFFF&E=1d24&W=1; DOMAIN=ntp.msn.com");

	web_add_cookie("ai_session=Vucd7DPNLQqkF+t7cCT2FK|1713089840451|1713089842509; DOMAIN=ntp.msn.com");

	web_add_cookie("OptanonConsent=isGpcEnabled=0&datestamp=Sun+Apr+14+2024+13%3A17%3A22+GMT%2B0300+(%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0%2C+%D1%81%D1%82%D0%B0%D0%BD%D0%B4%D0%B0%D1%80%D1%82%D0%BD%D0%BE%D0%B5+%D0%B2%D1%80%D0%B5%D0%BC%D1%8F)&version=202310.2.0&isIABGlobal=false&hosts=&landingPath=NotLandingPage&groups=C0001%3A1%2CC0002%3A0%2CC0003%3A0%2CC0004%3A0%2CV2STACK42%3A0&AwaitingReconsent=false&browserGpcFlag=0; DOMAIN=ntp.msn.com");

	web_add_cookie("MSFPC=GUID=58c5a592aaf547569539174347400df5&HASH=58c5&LV=202404&V=4&LU=1713089823907; DOMAIN=ntp.msn.com");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-MS-GEC", 
		"2A1D96958FD5C8C5C8A32F18E6097D405C44C3EB78D2801F22FC0F380BD14FAB");

	web_add_header("Sec-MS-GEC-Version", 
		"1-123.0.2420.81");

	web_add_header("Service-Worker-Navigation-Preload", 
		"true");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("X-Client-Data", 
		"eyIxIjoiMSIsIjEwIjoiXCJhazdIY1FwbmxabjhtOWFUeVJSK1RCbERzK051MGVBUHlQUEpsaEJnMy9nPVwiIiwiMiI6IjEiLCIzIjoiMCIsIjQiOiIzMzM3Mjg3NjA0ODc3Mjk4NjU3IiwiNSI6IlwiQ2t1QW1sUHhIejJDUmFJbkJWNmlhbTVVMmRSazdsREV6Z3RiK0I5TlVUOD1cIiIsIjYiOiJzdGFibGUiLCI3IjoiMjA0MDEwOTQ2NTYwMSIsIjkiOiJkZXNrdG9wIn0=");

	web_add_header("X-Edge-Shopping-Flag", 
		"1");

	web_add_header("device-memory", 
		"8");

	web_add_header("downlink", 
		"2.4");

	web_add_header("ect", 
		"4g");

	web_add_header("rtt", 
		"100");

	web_add_header("sec-ch-dpr", 
		"1.25");

	web_add_header("sec-ch-prefers-color-scheme", 
		"light");

	web_add_auto_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_header("sec-ch-ua-arch", 
		"\"x86\"");

	web_add_header("sec-ch-ua-bitness", 
		"\"64\"");

	web_add_header("sec-ch-ua-full-version", 
		"\"123.0.2420.81\"");

	web_add_header("sec-ch-ua-full-version-list", 
		"\"Microsoft Edge\";v=\"123.0.2420.81\", \"Not:A-Brand\";v=\"8.0.0.0\", \"Chromium\";v=\"123.0.6312.106\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-model", 
		"\"\"");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_add_header("sec-ch-ua-platform-version", 
		"\"15.0.0\"");

	web_add_header("sec-edge-ntp", 
		"{\"back_block\":0,\"bg_cur\":{\"configIndex\":4,\"provider\":\"Video\"},\"bg_img_typ\":\"imageAndVideo\",\"exp\":[\"msNtpExp18\",\"msQuickLinksDefaultOneRow\",\"msShoppingWebAssistOnNtp\",\"msShoppingHistogramsOnNtp\",\"msEnableWinHPNewTabBackButtonFocusAndClose\",\"msCustomMaxQuickLinks\",\"msMaxQuickLinksAt20\",\"msAllowThemeInstallationFromChromeStore\",\"msEdgeSplitWindowLinkMode\",\"msUndersideAutoOpenForMsnTopQuestion\"],\"feed_dis\":\"peek\",\"layout\":2,\"quick_links_opt\":0,\""
		"seen_new_dev_fre\":false,\"sel_feed_piv\":\"myFeed\",\"show_greet\":true,\"tscollapsed\":0,\"vp\":{\"height\":429,\"width\":910},\"vt_opened\":false}");

	lr_think_time(24);

	web_url("ntp", 
		"URL=https://ntp.msn.com/edge/ntp?locale=ru&title=%D0%9D%D0%BE%D0%B2%D0%B0%D1%8F%20%D0%B2%D0%BA%D0%BB%D0%B0%D0%B4%D0%BA%D0%B0&dsp=0&sp=%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81&startpage=1&PC=U531&prerender=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Dest", 
		"frame");

	web_url("header.html", 
		"URL=http://localhost:1080/WebTours/header.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t5.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("MC1=GUID=5079aa0dd85f41e69cda66e2bd3fd648&HASH=5079&LV=202402&V=4&LU=1706808086327; DOMAIN=edge.microsoft.com");

	web_add_cookie("Imported_MUID=39FEA931D3406BD01315BD78D25D6A20; DOMAIN=edge.microsoft.com");

	web_add_cookie("MSCC=NR; DOMAIN=edge.microsoft.com");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_auto_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_auto_header("Sec-Mesh-Client-Edge-Version", 
		"123.0.2420.81");

	web_add_auto_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_auto_header("Sec-Mesh-Client-OS-Version", 
		"10.0.22621");

	web_add_auto_header("Sec-Mesh-Client-WebView", 
		"0");

	web_custom_request("msa", 
		"URL=https://edge.microsoft.com/identity/api/v3/msa", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTTP", 
		"EncType=application/json", 
		"Body={\"disable_features\":\"b9528075,a74ddd5e,4441f9c8,82a866e9,6c715cfb,e0075c8a,3f6a1a2,322c815,47fa1a09,b75125e3,7f2ec7fd,89412bf3,1ac69f6f,dee07e4,f7df8885,93277d03,11890ef,b9047d,7727e674,5b3f1b62,de7bc63a,a71c8bf9,d54f5dd3,4e39dc0e,eb936fc6,c2f48bc1,d262757d,f95dbd76,151580ae,7e023b6f,f8b99726,e79ca702,21445d2b,28128745,c0fc353a,cc2ca015,936ed3a7\",\"enable_features\":\"1e558dd0,37e13cbc,190925d1,ddfd6cd3,d8475dc5,4329d89d,67b5d3,52e4f636,eb6bda0a,27e96171,dd212865,c37b3bcf,a996022f,"
		"86db409d,22c15069,4b55f698,79a2946f,d8bd7ef,c9b6ef7a,2c2792dc,1f191e9b,cdd83d43,c073554e,c826eaf4,796f3495,b68a6faa,6e234a72,9507495a,5baa443,fa61d7db,82218f89,8d87c89c,47f46299,3c9dae4d,c10cfd2d,55df554a,890791d0,8da34187,789d387a,d915bfa7,32e2e62b,3c4c8f6e,1f196109,f38fdee,aa4ed18e,2caa34c,d9642ce0,9aec59c7,5917aca9,c428869,30ed0546,2eb6d46b,a2c215cb,a47c71da,8656b6b2,14666474,6918470a,7930653d,8fb8c332,174bb60,bd8fc42a,6e607227,15f0c840,24b90b43,13fe26d0,694dde77,3024cbda,12d1709a,e7f66d0d,"
		"39747e28,41c26479,75b1b341,880d5ac0,567f409c,1207cc22,45c273b4,18a22b0d,3891021f,2c975da3,2373949a,a976f7f5,55a5f854,5cfd95dc,7407dec5,974a1f21,21714a50,95a29f90,177b250e,a49949fb,9e8c649c,bf8cde40,66f69762,df9dd966,ee446086,4ab9326a,99e16ee6,ff424117,a6fd2304,45371e92,12b79225,bf158d94,bf77051e,675f5b01,ddf80091,4d7ba7c7,868da52a,100a933e,91b70444,83b657b7,e7e1e989,7c518418,2b4a426d,10bc8c5b,304a50c6,9fa4b7c7,6c603e1e,17fcb4b7,9f2b90ff,4d578363,f26b1d9f,e28a1926,e2a8ee65,ace2c02,94378a94,75b3cabe"
		",15e4dc79,badd9207,5fe48b97,15f16891,2d289c6b,dbac1097,313163e0,ff72c049,8543db20,85114d6d,8e45b33c,7aef631d,8ae2c758,62fd93b7,894803d7,1bdb75c5,1b7b8f,30618b89,36bbc4df,cfa4d3c0,66440848,f2462fc7,ac6af412,d29e7da8,1dcc6d79,792fbf1a,43d8ef41,9f497c3b,da18d921,34be8803,75888302,8b8dd9d3,8aacb961,6451dfa2,94108217,69a5860e,60985fe2,c10a1ee8,29fbe5ed,be978d29,b271760b,f79249b3,eb2a0f5d,17648a7a,6911c10f,2b99039a,ddcca13f,140ce999,d5c4bb55,f0f6c7c,fbefe0ae,e146e83a,576d9ef7,c9ac8654,b70671bc,e9496d3a,"
		"eb8c662d,a441b019,282948aa,eafd2e1e,e63d4915,b9ffe1a4,609df054,b3867b45,ce3a2f9b,c4136f96,514cd46b,50cbb1f,33a7e900,a1d4ae4,67815f60,a052b118,8b16b1a4,3e1e1ad1,3061cce0,839906b2,8b944d27,7c940d4b,39e38478,2e4fce77,710e2548,61ec3bc,15a8d884,9961d8da,2cee26c3,6411c84,89e6c82c,742c3373,aa7a017d,a2260a76,541c9d3f,3211c726,a23374f3,f34a4bc1,7bc2c97a,f276d9d,d0e9b170,55248c83,9ba6613a,5182d9e4,1d4568d,1b7d6cff,941793d0,ffdec9de,78fcf7c1,a606eeb4,1c1b8a28,54a3cda4,4159a1a,6499fec,9bfaa7d5,1800c72,"
		"bd76bea7,be29afdd,9620c781,6a086057,d1fc594e,2ca9c42,66171647,796721cd,1602d70f,2f341821,8abbcada,1514d0fb,5dc9e840,32471783,c256496d,cec791b2,498b0a6,ce2658a9,42597357,19adb2ef\",\"filter\":{\"version\":\"123.0.2420.81\"}}", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_add_header("X-Client-Data", 
		"eyIxIjoiMSIsIjEwIjoiXCJhazdIY1FwbmxabjhtOWFUeVJSK1RCbERzK051MGVBUHlQUEpsaEJnMy9nPVwiIiwiMiI6IjEiLCIzIjoiMCIsIjQiOiIzMzM3Mjg3NjA0ODc3Mjk4NjU3IiwiNSI6IlwiQ2t1QW1sUHhIejJDUmFJbkJWNmlhbTVVMmRSazdsREV6Z3RiK0I5TlVUOD1cIiIsIjYiOiJzdGFibGUiLCI3IjoiMjA0MDEwOTQ2NTYwMSIsIjkiOiJkZXNrdG9wIn0=");

	web_add_header("Edge-User-Anid", 
		"022CDA96091158A16CEFA276FFFFFFFF");

	web_url("v3", 
		"URL=https://edge.microsoft.com/serviceexperimentation/v3/?osname=win&channel=stable&osver=10.0.22621&devicefamily=desktop&installdate=1607370917&clientversion=123.0.2420.81&experimentationmode=2&scpguard=1&scpfull=0&scpver=1", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTTP", 
		LAST);

	web_revert_auto_header("Sec-Mesh-Client-Arch");

	web_revert_auto_header("Sec-Mesh-Client-Edge-Channel");

	web_revert_auto_header("Sec-Mesh-Client-Edge-Version");

	web_revert_auto_header("Sec-Mesh-Client-OS");

	web_revert_auto_header("Sec-Mesh-Client-OS-Version");

	web_revert_auto_header("Sec-Mesh-Client-WebView");

	web_add_header("X-AFS-CV", 
		"LbBxR9HYTh6w+HqYRmO6cl");

	web_add_header("X-AFS-ClientInfo", 
		"platform=Windows; os=Windows NT; osVer=10.0.22621; app=Microsoft Edge; appVer=123.0.2420.81; appChannel=stable; appInstallationId=3337287604877298657; region=RU;");

	web_add_header("X-Client-Data", 
		"CLUICIcQCLMQCNyIywE=");

	web_custom_request("command", 
		"URL=https://edge.microsoft.com/sync/v1/feeds/me/syncEntities/command/?client=Chromium&client_id=xoA3wCAk%2BKGKcH9sFEoxyQ%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTTP", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x18xoA3wCAk+KGKcH9sFEoxyQ==\\x10c\\x18\\x02*#\\x12\\x04\\x08\\x00\\x10\\x00\\x18\\x012\\x04\\x08\\xFC\\xDE$2\\x0E\\x08\\x81\\xF5\\x02\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00H\\x07\\xC0>\\x01:\\x1FProductionEnvironmentDefinitionR$\n\\x02\\x08\\x05\n\\x02\\x08\t\n\\x02\\x08\n\n\\x04\\x18\\xB1\\xE6\\x02\n\\x04\\x18\\xC6\\xA6\\x02\n\\x04\\x18\\xC7\\x87\\x03\\x10\\x01\\x18\\x00 \\x00Z\\x05\n\\x03106b 00000000000000000000000000000000j\\x02\\x10\\x01r\\x1Cchr:xoA3wCAk+"
		"KGKcH9sFEoxyQ==", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(5);

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t9.inf", 
		"Mode=HTTP", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("EdgeFeatureFlags", 
		"{\"ExtensionUseNewStoreKeys\":true,\"UseHttpsForDownload\":true}");

	web_add_header("MS-CV", 
		"US5GLogv5BBFMllUJC5VzE");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Update-Interactivity", 
		"bg");

	web_url("crx", 
		"URL=https://edge.microsoft.com/extensionwebstorebase/v1/crx?os=win&arch=x64&os_arch=x86_64&nacl_arch=x86-64&prod=edgecrx&prodchannel=&prodversion=123.0.2420.81&lang=ru&acceptformat=crx3,puff&x=id%3Dfjnehcbecaggobjholekjijaaekbnlgj%26v%3D3.84.0%26installedby%3Dinternal%26uc", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("hp_logo.png", 
		"URL=http://localhost:1080/WebTours/images/hp_logo.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://localhost:1080/WebTours/header.html", 
		"Snapshot=t11.inf", 
		LAST);

	web_url("webtours.png", 
		"URL=http://localhost:1080/WebTours/images/webtours.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://localhost:1080/WebTours/header.html", 
		"Snapshot=t12.inf", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("X-AnchorMailbox", 
		"CID:a399d551649951f2");

	web_url("V1Profile", 
		"URL=https://substrate.office.com/profileb2/v2.0/me/V1Profile", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTTP", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"123.0.2420.81");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.22621");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	web_add_header("X-HTTP-Method-Override", 
		"POST");

	lr_think_time(12);

	web_url("threatListUpdates_fetch", 
		"URL=https://edge.microsoft.com/extensionrevocation/v1/threatListUpdates_fetch?req=ChcKBm1zZWRnZRINMTIzLjAuMjQyMC44MRobCAEQCBoNMTcxMzA3NTE0NDAxNSIEIAEgAigEIgIIAQ==&ct=application/x-protobuf&key=d414dd4f9db345fa8003e32adc81b362", 
		"Resource=1", 
		"RecContentType=application/x-protobuf", 
		"Referer=", 
		"Snapshot=t14.inf", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("nav.pl", 
		"URL=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"Snapshot=t15.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"123.0.2420.81");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.22621");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	web_add_header("X-Microsoft-Update-AppId", 
		"kpfehajjjbbcifeehjgfgnabifknmdad,oankkpibpaokgecfckkdkgaoafllipag,eeobbhfgfagbclfofmgbdfoicabjdbkn,fppmbhmldokgmleojlplaaodlkibgikh,ohckeflnhegojcjlcpbfpciadgikcohk,ndikpojcjlepofdkaaldkinkjbeeebkl,fgbafbciocncjfbbonhocjaohoknlaco,jbfaflocpnkhbgcijpkiafdpbjkedane,ojblfafjmiikbkepnnolpgbbhejhlcim,alpjnmnfbgfkmmpcfpejmmoebdndedno,ahmaebgpfccdhgidjaidaoojjcijckba,ebkkldgijmkljgglkajkjgedfnigiakk,mpicjakjneaggahlnmbojhjpnileolnb,lkkdlcloifjinapabfonaibjijloebfb,mkcgfaeepibomfapiapjaceihcojnphg,"
		"plbmmhnabegcabfbcejohgjpkamkddhn,llmidpclgepbgbgoecnhcmgfhmfplfao,jcmcegpcehdchljeldgmmfbgcpnmgedo,omnckhpgfmaoelhddliebabpgblmmnjp,pbdgbpmpeenomngainidcjmopnklimmf,lfmeghnikdkbonehgjihjebgioakijgn,hjaimielcgmceiphgjjfddlgjklfpdei,cllppcmmlnkggcmljjfigkcigaajjmid,kkgjndbbnbmdbcenhbjmfaedkmjegngc,bplppjpoiabhjhoepjajdfpcklleoeih,gonpemdgkjcecdgbnaabipppbmgfggbe");

	web_add_header("X-Microsoft-Update-Interactivity", 
		"bg");

	web_add_header("X-Microsoft-Update-Service-Cohort", 
		"3548");

	web_add_header("X-Microsoft-Update-Updater", 
		"msedge-123.0.2420.81");

	web_custom_request("update", 
		"URL=https://edge.microsoft.com/componentupdater/api/v1/update?cup2key=7:20mKQhP9bfV2Ua_EmEzT3suFuYhBMqF7ns8AL7Ef3ew&cup2hreq=75ddd98a1d7ba24ef07a14021d83e22e38b7fa43e3235546b183f19462ec7b51", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTTP", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"msedge\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"kpfehajjjbbcifeehjgfgnabifknmdad\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.23\",\"enabled\":true,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.42AF0D1905C8F1D8F6167365271C4549A73603B838BA58B9A664C57C00DB1EE5\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.23\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.23,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser"
		"\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"101.0.4906.0\"},{\"appid\":\"oankkpibpaokgecfckkdkgaoafllipag\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.32\",\"enabled\":true,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.44C48B9ECD87ACDDD850F9AA5E1C9D48B7A398DEC13D376CD62D55DADBD464A5\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.32\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.32,\"AppVersion\""
		":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"6498.2023.8.1\"},{\"appid\":\"eeobbhfgfagbclfofmgbdfoicabjdbkn\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.78\",\"enabled\":true,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.8BFD50D350D47445B57BB1D61BBDE41CEDA7AC43DC81FCE95BF1AC646D97D2A0\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.78\",\"AppMajorVersion\":\"123\""
		",\"AppRollout\":0.78,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.0.0.8\"},{\"appid\":\"fppmbhmldokgmleojlplaaodlkibgikh\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.79\",\"enabled\":true,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.A81D1959892AE4180554347DF1B97834ABBA2E1A5E6B9AEBA000ECEA26EABECC\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.79"
		"\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.79,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.15.0.1\"},{\"appid\":\"ohckeflnhegojcjlcpbfpciadgikcohk\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.69\",\"enabled\":true,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.26123BEF7D73536450862D2C4D44963D720AA80B6FC2D8496F559CB9C1FDEB00\"}]},\"ping\":{\"r\":-2},\""
		"targetingattributes\":{\"AppCohort\":\"rrf@0.69\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.69,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"0.0.1.4\"},{\"appid\":\"ndikpojcjlepofdkaaldkinkjbeeebkl\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.75\",\"enabled\":true,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.7B7D2723762BB51B662A5A8B41C4181069DEBE6A885689017238BE129698E7FE\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.75\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.75,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"10.34.0.52\"},{\"appid\":\"fgbafbciocncjfbbonhocjaohoknlaco\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.58\",\"enabled\":true,\"installdate\":-1,\""
		"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.A3CA819F81D9DCA57840EF075B95084F67DB8F7B227D54D803C9EE7378D52870\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.58\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.58,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"2024.3.25.1\"},{\"appid\":\"jbfaflocpnkhbgcijpkiafdpbjkedane\",\"brand\":\"GGLS\",\"cohort\""
		":\"rrf@0.30\",\"enabled\":true,\"lang\":\"ru\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.30\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.3,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.0.0.25\"},{\"appid\":\"ojblfafjmiikbkepnnolpgbbhejhlcim\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.10\",\"enabled\":true,\"lang\":\"ru\",\"ping\":{\"r\":-2},\""
		"targetingattributes\":{\"AppCohort\":\"rrf@0.10\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.1,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"appid\":\"alpjnmnfbgfkmmpcfpejmmoebdndedno\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.38\",\"enabled\":true,\"installdate\":-1,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.ACAF273151A17537328DD498705F2F589745E014A1BBA4FC2B3FA2729CF4A5F6\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.38\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.38,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"11.0.0.0\"},{\"appid\":\"ahmaebgpfccdhgidjaidaoojjcijckba\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.02\",\"enabled\":true,\"lang\":\"ru\",\"ping"
		"\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.02\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.02,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"ebkkldgijmkljgglkajkjgedfnigiakk\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.08\",\"enabled\":true,\"installdate\":-1,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.1B2BA8FC90BA68CD057B9CAAFFC218EAD59A23E37F79192ED37D0C3A7A8BAB03\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.08\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.08,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.0.0.20\"},{\"appid\":\"mpicjakjneaggahlnmbojhjpnileolnb\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.52\",\"enabled\":true,\"lang\":\"ru\",\""
		"packages\":{\"package\":[{\"fp\":\"1.D0760C8DC53D9AC78138D8BB36E76A885A94363E33058BC33FB4E03162A2492C\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.52\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.52,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"4.0.0.19\"},{\"appid\":\"lkkdlcloifjinapabfonaibjijloebfb\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.04\",\""
		"enabled\":true,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.3DF98661B2C8EBCA31A06084870DCEBEA5B939B1844C8856381048EF81B69AD3\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.04\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.04,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"4.0.3.0\"},{\"appid\":\"mkcgfaeepibomfapiapjaceihcojnphg\",\"brand\":\""
		"GGLS\",\"cohort\":\"rrf@0.01\",\"enabled\":true,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.5C73571B0AED9C793771BC811DBDB3C6F02CC771A4D8308E009718B71D976A64\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.01\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.01,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.3.137.99\"},{\"appid\":\""
		"plbmmhnabegcabfbcejohgjpkamkddhn\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.93\",\"enabled\":true,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.F409260DE9C4B5D70B2C4F05AFAE2C37DB0C5B0F2A48F69575BAC81AE36416A3\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.93\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.93,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\""
		"version\":\"3026\"},{\"appid\":\"llmidpclgepbgbgoecnhcmgfhmfplfao\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.39\",\"enabled\":true,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.499678427A59B9EE33B37D1746A495BDB2A2132554FC7EBEE2AA947EB76993F7\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.39\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.39,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\""
		"1.3.185.29\"},\"updatecheck\":{},\"version\":\"2.0.6576.0\"},{\"appid\":\"jcmcegpcehdchljeldgmmfbgcpnmgedo\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.04\",\"enabled\":true,\"installdate\":-1,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.40FA7C4DD457CB5B330E8C81AC44055BEF80305914F96A2D34AB1E54F85AC3AD\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.04\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.04,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority"
		"\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.20240413.1.0\"},{\"appid\":\"omnckhpgfmaoelhddliebabpgblmmnjp\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.99\",\"enabled\":true,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.DD91C7C496E4D9E8DF5BEAA3D33D45F9EF196B4F888D0FAC50EAF08CAD6B29D7\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.99\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.99,\"AppVersion\":\"123.0.2420.81\""
		",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.0.0.2\"},{\"appid\":\"pbdgbpmpeenomngainidcjmopnklimmf\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.22\",\"enabled\":true,\"installdate\":-1,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.2623C1BCB6E4FC3961012C8302CD2E1FB2FC604429E4982767AA0353C52DEF23\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.22\",\"AppMajorVersion\":\"123\",\""
		"AppRollout\":0.22,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"0.0.0.26\"},{\"appid\":\"lfmeghnikdkbonehgjihjebgioakijgn\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.63\",\"enabled\":true,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.57DF0451D29F5FD28183987FFF56BC65D368944933BB2EE0368D9DF1A19955A4\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.63\","
		"\"AppMajorVersion\":\"123\",\"AppRollout\":0.63,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"2.0.0.10\"},{\"appid\":\"hjaimielcgmceiphgjjfddlgjklfpdei\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.83\",\"enabled\":true,\"installdate\":-1,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.A00289AF85D31D698A0F6753B6CE67DBAB4BDFF639BDE5FC588A5D5D8A3885D5\"}]},\"ping\":{\"r\":-2},\""
		"targetingattributes\":{\"AppCohort\":\"rrf@0.83\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.83,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.0.0.5\"},{\"appid\":\"cllppcmmlnkggcmljjfigkcigaajjmid\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.32\",\"enabled\":true,\"installdate\":-1,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.3BF35526038C69EC8D196E207C2120538ECA8B4728F48E03DC3DDBC1950469AE\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.32\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.32,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"122.17473.17436.12\"},{\"appid\":\"kkgjndbbnbmdbcenhbjmfaedkmjegngc\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.09\",\"enabled\":true,\""
		"installdate\":-1,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.DB7BFA24DFB6FF11C49919F5525260AABA8BCED04A26D5F9B48ACA9183DB11CF\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.09\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.09,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"724.1301.930.0\"},{\"appid\":\"bplppjpoiabhjhoepjajdfpcklleoeih\",\""
		"brand\":\"GGLS\",\"cohort\":\"rrf@0.49\",\"enabled\":true,\"installdate\":-1,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.2AFC9BAF29F954E58D0DDF4728D0EA41BCB966285427CAF85B13EC05001677A3\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.49\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.49,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"2024.4.4.1\"}"
		",{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.66\",\"enabled\":true,\"installdate\":-1,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.F09EE458BC072D34B22EAE8853E44B3712E7CFD257A7CBED20BA3B1D9D652B3B\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.66\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.66,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\""
		"1.3.185.29\"},\"updatecheck\":{},\"version\":\"2024.1.5.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":1,\"physmemory\":10,\"sse\":1,\"sse2\":1,\"sse3\":1,\"sse41\":1,\"sse42\":1,\"ssse3\":1},\"ismachine\":1,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22621.3447\"},\"prodversion\":\"123.0.2420.81\",\"protocol\":\"3.1\",\"requestid\":\"{a82c0982-5368-4c6f-b0be-1762f36b18b1}\",\"sessionid\":\""
		"{82b00345-d86d-4871-8a4b-cf415222115c}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":1,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.185.29\"},\"updaterversion\":\"123.0.2420.81\"}}", 
		LAST);

	web_add_header("X-AFS-CV", 
		"vHm+i+1HskUn/y36dn5JjM");

	web_add_header("X-AFS-ClientInfo", 
		"platform=Windows; os=Windows NT; osVer=10.0.22621; app=Microsoft Edge; appVer=123.0.2420.81; appChannel=stable; appInstallationId=3337287604877298657; region=RU;");

	web_add_header("X-Client-Data", 
		"CLUICIcQCLMQCNyIywE=");

	web_custom_request("command_2", 
		"URL=https://edge.microsoft.com/sync/v1/feeds/me/syncEntities/command/?client=Chromium&client_id=xoA3wCAk%2BKGKcH9sFEoxyQ%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t17.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTTP", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x18xoA3wCAk+KGKcH9sFEoxyQ==\\x10c\\x18\\x02*#\\x12\\x04\\x08\\x00\\x10\\x00\\x18\\x012\\x04\\x08\\xF1\\xBFG2\\x0E\\x08\\x81\\xF5\\x02\\x12\\x08\\xFFb\\x19\\xDC\\x8E\\x01\\x00\\x00H\\x07\\xC0>\\x01:\\x1FProductionEnvironmentDefinitionR7\n)\\x12'8\\x00@\\x00R\\x04\\x08\\x00\\x10\\x00`\\x07\\x92\\x03\\x18LbBxR9HYTh6w+HqYRmO6cl.1\n\\x04\\x18\\xB1\\xE6\\x02\\x10\\x01\\x18\\x00 \\x00Z\\x05\n\\x03106b 00000000000000000000000000000000j\\x02\\x10\\x01r\\x1Cchr:xoA3wCAk+KGKcH9sFEoxyQ==", 
		LAST);

	web_add_header("X-AnchorMailbox", 
		"CID:a399d551649951f2");

	web_url("V1Profile_2", 
		"URL=https://substrate.office.com/profileb2/v2.0/me/V1Profile", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("ExpandedDomainsFilterGlobal.json", 
		"URL=https://www.bing.com/bloomfilterfiles/ExpandedDomainsFilterGlobal.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(4);

	web_url("home.html", 
		"URL=http://localhost:1080/WebTours/home.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"Snapshot=t20.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_url("mer_login.gif", 
		"URL=http://localhost:1080/WebTours/images/mer_login.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t21.inf", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("X-Client-Data", 
		"eyIxIjoiMSIsIjEwIjoiXCJhazdIY1FwbmxabjhtOWFUeVJSK1RCbERzK051MGVBUHlQUEpsaEJnMy9nPVwiIiwiMiI6IjEiLCIzIjoiMCIsIjQiOiIzMzM3Mjg3NjA0ODc3Mjk4NjU3IiwiNSI6IlwiQ2t1QW1sUHhIejJDUmFJbkJWNmlhbTVVMmRSazdsREV6Z3RiK0I5TlVUOD1cIiIsIjYiOiJzdGFibGUiLCI3IjoiMjA0MDEwOTQ2NTYwMSIsIjkiOiJkZXNrdG9wIn0=");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_custom_request("rewardsUserInfo", 
		"URL=https://www.bing.com/api/shopping/v1/savings/rewards/rewardsUserInfo", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t22.inf", 
		"Mode=HTTP", 
		"EncType=application/json", 
		"Body={\"anid\":\"022CDA96091158A16CEFA276FFFFFFFF\"}", 
		LAST);

	web_add_header("X-AFS-CV", 
		"wtzzWjme8U1Chq1nRtpRcj");

	web_add_header("X-AFS-ClientInfo", 
		"platform=Windows; os=Windows NT; osVer=10.0.22621; app=Microsoft Edge; appVer=123.0.2420.81; appChannel=stable; appInstallationId=3337287604877298657; region=RU;");

	web_add_header("X-Client-Data", 
		"CLUICIcQCLMQCNyIywE=");

	web_custom_request("command_3", 
		"URL=https://edge.microsoft.com/sync/v1/feeds/me/syncEntities/command/?client=Chromium&client_id=xoA3wCAk%2BKGKcH9sFEoxyQ%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t23.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTTP", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x18xoA3wCAk+KGKcH9sFEoxyQ==\\x10c\\x18\\x02*\\xCF\\x04\\x12\\x04\\x08\\x00\\x10\\x00\\x18\\x012\\x1E\\x08\\x88\\x81\\x02\\x12\\x08X\\xEFt\\xCD\\x83\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xC6\\xA6\\x02\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x01(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xB1\\xE6\\x02\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x02"
		"(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xCF\\xF3\\x03\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xCD\\xBE\\x02\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xF7\\xF7\\x02\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00"
		"(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xC7\\x87\\x03\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x01(\\x040\\x008\\x00@\\x002\\x1E\\x08\\x9F\\xEF\\x05\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xEB\\x95\t\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x040\\x008\\x00@\\x002\\x1E\\x08\\x9A\\xB7\t"
		"\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xFC\\xDE$\\x12\\x08\\xFFb\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xC9\\x8B)\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xA1\\xDD'\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00"
		"(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xD0\\xAF:\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xA9\\xF0O\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xF1\\xBFG\\x12\\x08\\x1C\\xAB\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00"
		"(\\x040\\x008\\x00@\\x002\\x1E\\x08\\xB5\\xDAD\\x12\\x08\\x80\\xD0\\xAD\\xDB\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x040\\x008\\x00@\\x002\\x1E\\x08\\x81\\xF5\\x02\\x12\\x08\\x1C\\xAB\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x060\\x008\\x00@\\x00H\\x0CP\\x00\\xC0>\\x01:\\x1FProductionEnvironmentDefinitionR1\n)\\x12'8\\x00@\\x00R\\x04\\x08\\x00\\x10\\x00`\\x07\\x92\\x03\\x18vHm+i+1HskUn/y36dn5JjM.1\\x10\\x01\\x18\\x00 \\x00Z\\x05\n\\x03106b "
		"00000000000000000000000000000000j\\x02\\x10\\x01r\\x1Cchr:xoA3wCAk+KGKcH9sFEoxyQ==", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_add_header("APIKey", 
		"70109aa3567b40e3bb8ac9e67a07b58a-b00e4868-b511-4be4-90dd-6370c812f0af-7167");

	web_add_header("Client-Id", 
		"NO_AUTH");

	web_add_header("Expect", 
		"100-continue");

	web_add_header("SDK-Version", 
		"EVT-Windows-C++-No-3.5.131.1");

	web_add_header("Tickets", 
		"\"10001\"=\"p:t=GwBmAbuEBAAU2qcZHJoKGNizGOeyqM4OaIoSZ0MOZgAAENO6mHtVbGCAe1gLJDBfFVowAcn8NXHxTrwqjhzinnZQbEu5BQXQjhILB6zX2/8hhEASQJVttpGaGj/vUH4YQ7bW0fLBl8A+fUkRFYU5MVqMaPROp2hUK+XfSGU+nov9fb/F4KaCRG5rIKuGsxnkjCkp84g7h3rFFCqXvhV+O/sEE8MssWlhoV46JJPwew0UifxVa4SFZa+cacY9L6ZTXUyA4KJumeTNBGLNBXwyyJ+aEd/QfugEFjOIOuH9DWExUQExWeoosip30aJsx+oX9Yymn1aAJZIiED2n3iZWuT6FhZUGb8FUm6aX4vjWVxjiZVPgAdeXu9jrrSjjAeYWU7cBgukFoRLcvwGyDJZR1M+OqmEx2nQKcVurQtn0p6aet44wr13D9KprpKuWWXq8oiq45j34cg9xq/XXvcggv4ix8UNgAQ==&p=\"");

	web_add_header("Upload-Time", 
		"1713089945879");

	web_custom_request("1.0", 
		"URL=https://functional.events.data.microsoft.com/OneCollector/1.0/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t24.inf", 
		"ContentEncoding=deflate", 
		"Mode=HTTP", 
		"EncType=application/bond-compact-binary", 
		"BodyBinary=)\\x033.0I<Microsoft.WebBrowser.Personalization.SAN.ImportedHistoryURLsq\\xF8\\xD0\\x86\\xF7\\x89\\x9B\\xAE\\xDC\\x11\\xA9\"o:70109aa3567b40e3bb8ac9e67a07b58a\\xD1\\x06\\x82\\x84@\\xCB\\x15\n\\x01K\\x0B\\x01\t\\x01\\x0510001i\\x06LENOVO\\x89\\x0481NC\\x00\\xCB\\x16\n\\x01\\x00\\xCB\\x17\n\\x01I&r:66195836-a11a-40b1-9c4b-a2a4edce13ce\\xA9\\x0FWindows.Desktop\\x00\\xCB\\x18\n\\x01\\x89\\x0FWindows Desktop\\xA9,10.0.22621.1.amd64fre.ni_release.220506-1250\\x00\\xCB\\x19\n\\x01\\xA9fW"
		":0006160ee23f5a2234350cba651736e8000700000904!0000da39a3ee5e6b4b0d3255bfef95601890afd80709!msedge.exe\\xC9\\x06%2024/04/04:02:39:19!3e6e83!msedge.exe\\x00\\xCB\\x1F\n\\x01I\tUnmeteredi\\x07Unknown\\x00\\xCB \n\\x01)\\x1CEVT-Windows-C++-No-3.5.131.1I$2754F3E4-04E3-403D-AF01-47B9E69E87C1q\n\\x89$2E86DFD5-279D-4C7F-97A1-2B366484710C\\x00\\xCB!\n\\x01i\\x06+03:00\\x00\\xCB%\n\\x01\\x00\\xC9<\\x06custom\\xCBF\n\\x01-\t\n\n"
		"\\x0CAppInfo.ETag\\x00\\x07Channel0\\x00\\x91\\x08\\x00\\x0EConnectionTypei\\x04WiFi\\x00\\x07Countryi\\x02RU\\x00\\x0FEventInfo.Level0\\x00\\x91\\x04\\x00\\x08Languagei\\x02ru\\x00\\x1ANavigationURLsAndVisitTimeiOURL:http://localhost:1080/WebTours/,Title:Web Tours,VisitTime:13357563380268658\\x00\tclient_id0\\x00\\x91\\xC2\\xAF\\xB4\\xA0\\xA3\\xD9\\xB6\\xD0\\\\\\x00\npop_sample0\\x08\\xA8\\x00\\x00\\x00\\x00\\x00\\x00Y@\\x00\tutc_flags0\\x00\\x91\\x80\\x80\\x80\\x80\\x80\\x80@\\x00\\x00\\x00)"
		"\\x033.0I=Microsoft.WebBrowser.Personalization.SAN.PreferenceSanConsentq\\xF8\\xD0\\x86\\xF7\\x89\\x9B\\xAE\\xDC\\x11\\xA9\"o:70109aa3567b40e3bb8ac9e67a07b58a\\xD1\\x06\\x82\\x84@\\xCB\\x15\n\\x01K\\x0B\\x01\t\\x01\\x0510001i\\x06LENOVO\\x89\\x0481NC\\x00\\xCB\\x16\n\\x01\\x00\\xCB\\x17\n\\x01I&r:66195836-a11a-40b1-9c4b-a2a4edce13ce\\xA9\\x0FWindows.Desktop\\x00\\xCB\\x18\n\\x01\\x89\\x0FWindows Desktop\\xA9,10.0.22621.1.amd64fre.ni_release.220506-1250\\x00\\xCB\\x19\n\\x01\\xA9fW"
		":0006160ee23f5a2234350cba651736e8000700000904!0000da39a3ee5e6b4b0d3255bfef95601890afd80709!msedge.exe\\xC9\\x06%2024/04/04:02:39:19!3e6e83!msedge.exe\\x00\\xCB\\x1F\n\\x01I\tUnmeteredi\\x07Unknown\\x00\\xCB \n\\x01)\\x1CEVT-Windows-C++-No-3.5.131.1I$2754F3E4-04E3-403D-AF01-47B9E69E87C1q\\x08\\x89$2E86DFD5-279D-4C7F-97A1-2B366484710C\\x00\\xCB!\n\\x01i\\x06+03:00\\x00\\xCB%\n\\x01\\x00\\xC9<\\x06custom\\xCBF\n\\x01-\t\n\t"
		"\\x0CAppInfo.ETag\\x00\\x07Channel0\\x00\\x91\\x08\\x00\\x0EConnectionTypei\\x04WiFi\\x00\\x0FEventInfo.Level0\\x00\\x91\\x04\\x00\nSanConsent0\\x0C\\x91\\x02\\x00\tTimestampi\\x182024-04-14T10:18:03.668Z\\x00\tclient_id0\\x00\\x91\\xC2\\xAF\\xB4\\xA0\\xA3\\xD9\\xB6\\xD0\\\\\\x00\npop_sample0\\x08\\xA8\\x00\\x00\\x00\\x00\\x00\\x00Y@\\x00\tutc_flags0\\x00\\x91\\x80\\x80\\x80\\x80\\x80\\x80@\\x00\\x00\\x00)"
		"\\x033.0I4Microsoft.WebBrowser.Personalization.SAN.BrowserInfoq\\xF8\\xD0\\x86\\xF7\\x89\\x9B\\xAE\\xDC\\x11\\xA9\"o:70109aa3567b40e3bb8ac9e67a07b58a\\xD1\\x06\\x82\\x84@\\xCB\\x15\n\\x01K\\x0B\\x01\t\\x01\\x0510001i\\x06LENOVO\\x89\\x0481NC\\x00\\xCB\\x16\n\\x01\\x00\\xCB\\x17\n\\x01I&r:66195836-a11a-40b1-9c4b-a2a4edce13ce\\xA9\\x0FWindows.Desktop\\x00\\xCB\\x18\n\\x01\\x89\\x0FWindows Desktop\\xA9,10.0.22621.1.amd64fre.ni_release.220506-1250\\x00\\xCB\\x19\n\\x01\\xA9fW"
		":0006160ee23f5a2234350cba651736e8000700000904!0000da39a3ee5e6b4b0d3255bfef95601890afd80709!msedge.exe\\xC9\\x06%2024/04/04:02:39:19!3e6e83!msedge.exe\\x00\\xCB\\x1F\n\\x01I\tUnmeteredi\\x07Unknown\\x00\\xCB \n\\x01)\\x1CEVT-Windows-C++-No-3.5.131.1I$2754F3E4-04E3-403D-AF01-47B9E69E87C1q\\x06\\x89$2E86DFD5-279D-4C7F-97A1-2B366484710C\\x00\\xCB!\n\\x01i\\x06+03:00\\x00\\xCB%\n\\x01\\x00\\xC9<\\x06custom\\xCBF\n\\x01-\t\n\t"
		"\\x0CAppInfo.ETag\\x00\\x07Channel0\\x00\\x91\\x08\\x00\\x0EConnectionTypei\\x04WiFi\\x00\\x0FEventInfo.Level0\\x00\\x91\\x04\\x00\\x08Languagei\\x02ru\\x00\tTimestampi\\x182024-04-14T10:18:03.668Z\\x00\tclient_id0\\x00\\x91\\xC2\\xAF\\xB4\\xA0\\xA3\\xD9\\xB6\\xD0\\\\\\x00\npop_sample0\\x08\\xA8\\x00\\x00\\x00\\x00\\x00\\x00Y@\\x00\tutc_flags0\\x00\\x91\\x80\\x80\\x80\\x80\\x80\\x80@\\x00\\x00\\x00)"
		"\\x033.0IOMicrosoft.WebBrowser.Personalization.SAN.PreferenceDefaultSearchProviderCurrentq\\xF8\\xD0\\x86\\xF7\\x89\\x9B\\xAE\\xDC\\x11\\xA9\"o:70109aa3567b40e3bb8ac9e67a07b58a\\xD1\\x06\\x82\\x84@\\xCB\\x15\n\\x01K\\x0B\\x01\t\\x01\\x0510001i\\x06LENOVO\\x89\\x0481NC\\x00\\xCB\\x16\n\\x01\\x00\\xCB\\x17\n\\x01I&r:66195836-a11a-40b1-9c4b-a2a4edce13ce\\xA9\\x0FWindows.Desktop\\x00\\xCB\\x18\n\\x01\\x89\\x0FWindows Desktop\\xA9,10.0.22621.1.amd64fre.ni_release.220506-1250\\x00\\xCB\\x19\n"
		"\\x01\\xA9fW:0006160ee23f5a2234350cba651736e8000700000904!0000da39a3ee5e6b4b0d3255bfef95601890afd80709!msedge.exe\\xC9\\x06%2024/04/04:02:39:19!3e6e83!msedge.exe\\x00\\xCB\\x1F\n\\x01I\tUnmeteredi\\x07Unknown\\x00\\xCB \n\\x01)\\x1CEVT-Windows-C++-No-3.5.131.1I$2754F3E4-04E3-403D-AF01-47B9E69E87C1q\\x04\\x89$2E86DFD5-279D-4C7F-97A1-2B366484710C\\x00\\xCB!\n\\x01i\\x06+03:00\\x00\\xCB%\n\\x01\\x00\\xC9<\\x06custom\\xCBF\n\\x01-\t\n\n"
		"\\x0CAppInfo.ETag\\x00\\x07Channel0\\x00\\x91\\x08\\x00\\x0EConnectionTypei\\x04WiFi\\x00\\x14DSPCurrentRejectCode0\\x00\\x00\rDSPCurrentUrliPhttps://yandex.ru/%7Byandex:searchPath%7D?text={searchTerms}&{yandex:referralID}\\x00\\x0FEventInfo.Level0\\x00\\x91\\x04\\x00\tTimestampi\\x182024-04-14T10:18:03.668Z\\x00\tclient_id0\\x00\\x91\\xC2\\xAF\\xB4\\xA0\\xA3\\xD9\\xB6\\xD0\\\\\\x00\npop_sample0\\x08\\xA8\\x00\\x00\\x00\\x00\\x00\\x00Y@\\x00\t"
		"utc_flags0\\x00\\x91\\x80\\x80\\x80\\x80\\x80\\x80@\\x00\\x00\\x00)\\x033.0IBMicrosoft.WebBrowser.Personalization.SAN.PreferenceHomepageCurrentq\\xF8\\xD0\\x86\\xF7\\x89\\x9B\\xAE\\xDC\\x11\\xA9\"o:70109aa3567b40e3bb8ac9e67a07b58a\\xD1\\x06\\x82\\x84@\\xCB\\x15\n\\x01K\\x0B\\x01\t\\x01\\x0510001i\\x06LENOVO\\x89\\x0481NC\\x00\\xCB\\x16\n\\x01\\x00\\xCB\\x17\n\\x01I&r:66195836-a11a-40b1-9c4b-a2a4edce13ce\\xA9\\x0FWindows.Desktop\\x00\\xCB\\x18\n\\x01\\x89\\x0FWindows Desktop\\xA9,"
		"10.0.22621.1.amd64fre.ni_release.220506-1250\\x00\\xCB\\x19\n\\x01\\xA9fW:0006160ee23f5a2234350cba651736e8000700000904!0000da39a3ee5e6b4b0d3255bfef95601890afd80709!msedge.exe\\xC9\\x06%2024/04/04:02:39:19!3e6e83!msedge.exe\\x00\\xCB\\x1F\n\\x01I\tUnmeteredi\\x07Unknown\\x00\\xCB \n\\x01)\\x1CEVT-Windows-C++-No-3.5.131.1I$2754F3E4-04E3-403D-AF01-47B9E69E87C1q\\x02\\x89$2E86DFD5-279D-4C7F-97A1-2B366484710C\\x00\\xCB!\n\\x01i\\x06+03:00\\x00\\xCB%\n\\x01\\x00\\xC9<\\x06custom\\xCBF\n\\x01-\t\n\t"
		"\\x07Channel0\\x00\\x91\\x08\\x00\\x0EConnectionTypei\\x04WiFi\\x00\\x0FEventInfo.Level0\\x00\\x91\\x04\\x00\\x19HomepageCurrentRejectCode0\\x00\\x00\\x12HomepageCurrentUrli\\x1Bhttp://www.msn.com/?pc=LCTE\\x00\tTimestampi\\x182024-04-14T10:18:03.653Z\\x00\tclient_id0\\x00\\x91\\xC2\\xAF\\xB4\\xA0\\xA3\\xD9\\xB6\\xD0\\\\\\x00\npop_sample0\\x08\\xA8\\x00\\x00\\x00\\x00\\x00\\x00Y@\\x00\tutc_flags0\\x00\\x91\\x80\\x80\\x80\\x80\\x80\\x80@\\x00\\x00\\x00", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_cookie("_fbp=fb.1.1703154589881.1946254086; DOMAIN=copilot.microsoft.com");

	web_add_cookie("MC1=GUID=5079aa0dd85f41e69cda66e2bd3fd648&HASH=5079&LV=202402&V=4&LU=1706808086327; DOMAIN=copilot.microsoft.com");

	web_add_cookie("MUID=08F4CA78CBD669582403DE65CA7F68C7; DOMAIN=copilot.microsoft.com");

	web_add_cookie("MUIDB=08F4CA78CBD669582403DE65CA7F68C7; DOMAIN=copilot.microsoft.com");

	web_add_cookie("_EDGE_V=1; DOMAIN=copilot.microsoft.com");

	web_add_cookie("USRLOC=HS=1; DOMAIN=copilot.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=copilot.microsoft.com");

	web_add_cookie("SRCHUID=V=2&GUID=4F1AF59BE8654300BEC8E2E759AFD29E&dmnchg=1; DOMAIN=copilot.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20240206; DOMAIN=copilot.microsoft.com");

	web_add_cookie("SRCHHPGUSR=SRCHLANG=ru; DOMAIN=copilot.microsoft.com");

	web_add_cookie("ANON=A=022CDA96091158A16CEFA276FFFFFFFF&E=1d24&W=1; DOMAIN=copilot.microsoft.com");

	web_add_cookie("Imported_MUID=39FEA931D3406BD01315BD78D25D6A20; DOMAIN=copilot.microsoft.com");

	web_add_cookie("MSCC=NR; DOMAIN=copilot.microsoft.com");

	web_add_cookie("_clck=5zljte%7C2%7Cfkx%7C0%7C1450; DOMAIN=copilot.microsoft.com");

	web_add_cookie("_uetsid=b3d82ef0fa2d11ee990bd10fd370eb0f; DOMAIN=copilot.microsoft.com");

	web_add_cookie("_uetvid=def772809feb11eeb9e4dd4e0d8c68a8; DOMAIN=copilot.microsoft.com");

	web_add_cookie("_clsk=1vdpn1m%7C1713078471097%7C1%7C0%7Cd.clarity.ms%2Fcollect; DOMAIN=copilot.microsoft.com");

	web_add_cookie("_U=1MBEloYctFz3PtG-m8XZJziN6cBDGGRjzeZ28qzf4nRZ6UprO7kgGX1A8F2UYTQMw1TzHsOSPfxRKgdjrBK1W1vHCyRMozAfVpFhSBCYzGJSOYnJfgpWV_WjZbg_N2wAqhjnTKzYzw48oA8wGw5BfqfU-PiAqG7158AQTatjIdr_ESlH7Q3z6q8Mo3Wkx_AM1ANW5XhBMLpYeJH1yAfOIpA; DOMAIN=copilot.microsoft.com");

	web_add_cookie("ak_bmsc=745BB27697518FDEE0653065320537B2~000000000000000000000000000000~YAAQHZJkX36tqbuOAQAAHmwc3BeJ1YG50hyrAUH5hG0L3RcBq/KnFzsEPvzos70d4RwSmtlE9wq0SDPNd1EBsF2pOZDWKH/s9DstIMKwq2Wc8tDSGT2J7Oz3fw29PkpUJGUbyXRs22MmiiHlfeLHU5VdR+MxjHCotQVY2IYWYI6oia0qRG2CJM8S7pzBkUE1p2AeUC5f+/Z8royepJUwQeutHmqR9iEhmcVC1YmxbAKJjrI1fsL6AfzUpRkiOojfbg7ax3mVfaZ2WDbQ86u5cBLaMgRXyov5QCBHgQSnKrEevZM9Mg5FAtiNqkoGBHxzeeFvXYURPunphfp/mqOOgy0C0asjVE3aKsGTf/3CwYJOXROJCE1ouI5napUlMvpVVozMvky521g=; DOMAIN="
		"copilot.microsoft.com");

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"123.0.2420.81");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.22621");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	web_add_header("X-Search-RPSToken", 
		"t=EwDIAqyMBAAUWkziSC7RbDJKS1VkhugDegv7L0eAANn2vsce6VX19LPgKFaLbBkYxUk9AJcSo18+zUf9ySsZOl0RonCmuzLWXzO1lApfQYM+GeUG/ADVHHnyhF1QdJhjcHzJA9+SZdXPNa8a7WzMLVZ1zdyrrBuJEwc75w8Sy03nEZQlq7cIeckX6VvTtNSrR6gNTh7oAKVLp5OquPImA2YAAAijzkXqRR69YBgChRaF45ot6+5ZHGgPJDW8JyDjP8pQe0gDqVGUXlxc/tN3F7lLz0InGmgH67tulPQZSeKHxDjbJIAXR8ugGuUzgbqio5LMqP/5n9FnYoJKxi/luMrA9QX/Q5v3PTgulzwdwKW7j7WLHZQj6ZUFvVVJkV7JWT8QJYcg94wL6hhFbdCA5OhibJAZBOCInTQqegFGbwwjpONsNPCCma28ygbSF4ppwhCZ+mBJJ81OnN4prN3a/yFlu59BBDuAEeAhhIZb2/XcnfJ/"
		"wZtwO3aCJsh9Y1zBi2fuXq5VuTFLBjHhuPTQ+eCMIhxVuiNuFVklIOHwjXLbAK9uEozQ03FsPSK0bAOT/gTCmwtU5lHHDQ0X92o0CsF1lTjK2Y/aT1Iupcxd/0OhEebiDYC++DHCntf/RWqkvbypVaSjaJ/Md63NUUjd6ZLaKjisYi8hNHYUT0dwzsuv/ydKPt/l96z1PMlV4BZXluzjpG5S6NDx63bYI/JTNNBLQrOMNdL5jCY8IltqimQHLIeI+v183yYPF8yRBjSbmHE3kWtku+awyUor5nAC4VlbZdymRPvpYVgi8sFy6WeEIHS4vVbDlCc3U1+rZijKSjurvJOqdu9H9QtjDFg03e7TflL7RT4tT8XGkZ1gwNKQRUgs2p/2lhFZOoSX/rYlCvyo9HVVhofKnrlAP+Evm2AWXMXwiV0RabQfobcoFVQFyVh6vSxPAg==&p=");

	web_url("signin", 
		"URL=https://copilot.microsoft.com/fd/auth/signin?&action=header&provider=windows_live_id&save_token=0", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t25.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("X-Client-Data", 
		"eyIxIjoiMSIsIjEwIjoiXCJhazdIY1FwbmxabjhtOWFUeVJSK1RCbERzK051MGVBUHlQUEpsaEJnMy9nPVwiIiwiMiI6IjEiLCIzIjoiMCIsIjQiOiIzMzM3Mjg3NjA0ODc3Mjk4NjU3IiwiNSI6IlwiQ2t1QW1sUHhIejJDUmFJbkJWNmlhbTVVMmRSazdsREV6Z3RiK0I5TlVUOD1cIiIsIjYiOiJzdGFibGUiLCI3IjoiMjA0MDEwOTQ2NTYwMSIsIjkiOiJkZXNrdG9wIn0=");

	web_custom_request("rewardsUserInfo_2", 
		"URL=https://www.bing.com/api/shopping/v1/savings/rewards/rewardsUserInfo", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t26.inf", 
		"Mode=HTTP", 
		"EncType=application/json", 
		"Body={\"anid\":\"022CDA96091158A16CEFA276FFFFFFFF\"}", 
		LAST);

	web_add_header("X-AFS-CV", 
		"824239801011012352.1");

	web_add_header("X-AFS-ClientInfo", 
		"platform=Windows; os=Windows NT; osVer=10.0.22621; app=Microsoft Edge; appVer=123.0.2420.81; appChannel=stable");

	web_custom_request("subscriptions", 
		"URL=https://edge.microsoft.com/sync/v2/feeds/me/subscriptions", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t27.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=UTF-8", 
		"Body={\"channelurl\":\"ecm:CAbWzLCiGZ6h9tvWyeQLyLZt9o9TLgH7PvpKGfutT7PBF6LBARv7v1yb2MCUv65r6sKgM9EKD1zW+kruJljz9xQCzk41sHvhcQDoQpgwrX8FDqiq/6MtMn5s8h+9FMqHoh7/5kpguI+cCKqrpiSGelaEFDXH6dxTDIQI1q6dPACAOGiV5t2MM0eXxOLFUOqq7UCDZ88ZIsKPuI1qQadRKA==\",\"deviceId\":\"chr:xoA3wCAk+KGKcH9sFEoxyQ==\",\"publisherFilters\":[{\"activityTypes\":[65,66,67,70,71,72,75,77,79,82,103,104,106,109,112,113,115],\"application\":\"edge.activity.windows.com\",\"notificationType\":\"notificationOnly\",\"platform\":\"host\""
		"}]}", 
		LAST);

	web_add_cookie("MUID=047FE09A36C068D9071EF357375969CA; DOMAIN=www.bing.com");

	web_add_cookie("MUIDB=047FE09A36C068D9071EF357375969CA; DOMAIN=www.bing.com");

	web_add_cookie("USRLOC=HS=1&BID=MjQwNDE0MTMxNzE0XzZiZGZjZmRkMTIxZDcxNDFhNzNhM2VmNTU5ZGVkY2Q3MGM4MDBjZmM1N2QxN2U1ZTdmMTQ2MWFlNzMwNThmNmE=; DOMAIN=www.bing.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=www.bing.com");

	web_add_cookie("SRCHUID=V=2&GUID=C12181BD05144ECB80849DC309AB08FA&dmnchg=1; DOMAIN=www.bing.com");

	web_add_cookie("ANON=A=022CDA96091158A16CEFA276FFFFFFFF&E=1d24&W=1; DOMAIN=www.bing.com");

	web_add_cookie("PPLState=1; DOMAIN=www.bing.com");

	web_add_cookie("KievRPSSecAuth=FAB6BBRaTOJILtFsMkpLVWSG6AN6C/svRwNmAAAEgAAACH/mUTlacZh5OAQb7txY2Hmtl3kQ8lGciHw1xn4Bsbk1WYu8lQhSQZ+s1FndCSAlgD20IKrPrYop3TJTzmuW3oJiFARgj3C7EvIesPjC0GmlF5y0X7DSctk6BSpmMxXmbzRSLR8Mg65GyUkUjcHXdRe6FEQkUDq0Xn4/lmcbHwURb+onOdXmap1iCUY3Ny53CW3P0dXm1NnduH8qp5UUDwV1qTOYyA8DZWKg3LkNQcFZSMXSlz9nEQNouoCSLS7kJsiXuHBXD7qhaWYZ+7qUMTkKkFN2V2/VCGuYfyEoeGzOwoErtG+zbB7w05VgFIoVFgixNZLfAMW250R7epRUmacViQ2lLainWn3vEAyE+2se90TZTllKyFwLRtfNhhnPULLGqODoj220iC+E2E/"
		"svhFpo0U8OT0C3hPEKQOXitX3APenCaJNutxEIo/BZsFxAfWTU7KPFBUFsa2uAFV3sMU3iFfElT+7eHnEu3trymnd3/9V53VrmwBvab+mYjYlj7O13hqb5e0qZU6iiVW6jr6wL9S+z9uYM+BmIYxxzZdjhm4wMt1ik9oMqlYyCaAYbngwfRhVUbCu2maFEqKsaUib+WFm2+k6cTrazVHmlr7LoAoE7tQrlpxM5TZully4+uUOU13jEaIpxxxnKN3YIgWpKXhXEs/5KB6FsBXgBHBBYaA93ySrIQvhxrrHjoUDbET7//lxPUlGUnrcNqhX9yEERk57Vlr8niXMiXrHRfr1AssucaT8+nYL7giotEltuhCHOaKtCyzbqHzZNq6/btAmFVewSPOIftGsWHMFYd6QO5P9hmHJi3yJGmqWuM82bHnQyXk562O4V6KEdqoVZ+N/WHefD2KjWC8c55SOiQyZmm527WNGStlLfGtUOOd7xzHGMQ/"
		"OfYad+7tAY/LoLd6EjW+bJjo+KmoH0m4n6SSbLMC2dpX2ZdSiyTz371oaXlTvpM4eWF2T0XCGpeLSB/NTisTez7tGcXxl4QMS22StaPnoUOv1SArDzOczZiPqm+7Gl8HB58NRh37W/gHAVIm8/ojPRN3MD9s6Xk+yCFZhIhjDffs4QmGnFK3BvifnavuJCDOUcn51WlNLFNcLnwb+w9cC8c0XyS13/f6Ztb+6DfeK/KKIbEteD9cjvM3Axw3pPHlRdkPPXduXd1MJ5Lepldv+thPcYnm0XgSSC/wRd+4YnF3wX8uR9cQ90PluZDKuvTTLfWPnD7/W+i0kZequzaykcBMS4jAzGyHdh2BBuPRisZ9XJBUH+easGakaPjQH6vCbpt7yoL1WCltQiaYGIqC+"
		"UxqmY3ZJNFYBthacMY4GzwhBt70xFv8C44E2QmZEtYQ86MWUm90PbIjrE0Lihl3I4cggA40ZQnOvd27JSmOokq5bSUYxwQGUL42DAgGSmNMK02fpJE7OU7aZQwL8ZGy0/guaLo6uWeqP1e46KRUUAFVAg/JAOkeDabRJk7tsLdKbAs6i; DOMAIN=www.bing.com");

	web_add_cookie("MSPTC=XPHtfWqrDXYP49cdnwWNDXf2f53KVEPrBbt-XqaRHW4; DOMAIN=www.bing.com");

	web_add_cookie("MMCASM=ID=06438D28877A431F9ACC9F095B9B96F1; DOMAIN=www.bing.com");

	web_add_cookie("_RwBf=r=0&ilt=0&ihpd=0&ispd=0&rc=0&rb=0&gb=0&rg=0&pc=0&mtu=0&rbb=0&g=0&cid=&clo=0&v=0&l=0001-01-01T00:00:00.0000000&lft=0001-01-01T00:00:00.0000000&aof=0&ard=0001-01-01T00:00:00.0000000&rwdbt=0001-01-01T00:00:00.0000000&rwflt=0001-01-01T00:00:00.0000000&o=2&p=&c=&t=0&s=0001-01-01T00:00:00.0000000+00:00&ts=2024-03-16T08:16:43.5847123+00:00&rwred=0&wls=2&wlb=0&wle=0&ccp=0&lka=0&lkt=0&aad=0&TH=; DOMAIN=www.bing.com");

	web_add_cookie("SRCHUSR=DOB=20231118&T=1710999974000&POEX=W; DOMAIN=www.bing.com");

	web_add_cookie("SRCHHPGUSR=SRCHLANG=ru&DM=0&IG=94517798AEF443A1AEA5B810437715C8&PV=15.0.0&BRW=XW&BRH=M&CW=1488&CH=708&SCW=1473&SCH=2823&DPR=1.3&UTC=180&EXLTT=13&HV=1711021284&PRVCW=1872&PRVCH=1044; DOMAIN=www.bing.com");

	web_add_cookie("Imported_MUID=39FEA931D3406BD01315BD78D25D6A20; DOMAIN=www.bing.com");

	web_add_cookie("EDGSRCHHPGUSR=CIBV=1.1690.0; DOMAIN=www.bing.com");

	web_add_cookie("_U=1fL4ANZkXa4g24AmOjrhpLm2Q-Wyxa6ZdyQgBJ3LF25q2IidcFVBjnJ1EdEAnkGlTpiwc3Y5rCTr_dDM4NZZJI4foyl-NkdD6U3IH00JbmpCQmX1i8crJb1h_8r44bHUc780BrhhBlNdwQx7fR7ZUHs75IRKis9DteQhHTJ6fpSCZgTm8KFS5O4b4kgl9Fh8QJarvCrs5BKIUDCJo6K9NCQ; DOMAIN=www.bing.com");

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"123.0.2420.81");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.22621");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	web_add_header("X-Search-RPSToken", 
		"t=EwDIAgALBAAUWkziSC7RbDJKS1VkhugDegv7L0eAADTtVjXsKtPPQ+sX2DnC3rRH+t3BHAqsraJk/URS6DxxVzqQKYKcOqJmbBaR8OJweh0PpX/4KdrDi1F9WpHopMh4EwV8bqK9HevghS4n3eCHdcyaPaI1xcaSTgOP/v67YUaRIelVVCuqFY7j3yaYSuxscxftaShQAng4MXi3jPgQA2YAAAgtC0bzs34TyBgCPo77DHd1eHjRBfJLILlFnx4/QPex1Naxrjpq5IqwCtfB6lToRB/HhXs9f59tWVoOzRPb2RIdiY20Fr6hK1GX4AY67uxNEhKkOzQlHTw6sYlAT0sKYgKUM1kHSQR8J8UBhsq0jJxXxaQpAwR5xp7SrJP2Ya81ml7fHs2LP4LhweGCCVFDxPsh9w+TbkDLqjve6QRNrpYupPaam4z2JvE7iFSgPbopXTW5rTk0x3LMU3LMl9PXNgBS89ckvFLMbyS8/"
		"ZsfLGBoPUMad2LNNcBY1NqC+uqBVp282WkrO8MylGnfb2Jhviy8OH85VGmeBXtaCTptQQnV8met+bggopfaTat/ssAfSg8nj5p8VQuZl0Uj4kpcujQtck7eNq+h33kFkT6j6LN/1X7In+NzBGP46JOG2sUiDEQHLBcuWq6T8Tr3n3swtHRWQ4jRGuw+L4K3/BoCSHG/Uaj3Cl176V7Mvb67sYI8oAda4VkUagSzzWEhNM4Wov2hqDHFU7YLOnFxMQ2N2zJsOWg3GDqNBxvU6XnB+18KasLyOYInv5EjSua1Ir467ua97ICzOcJqDG6LOFx0y/QNprnO/L9DzSuF0XWcuHcGwdUL1WED0r03ib8SfDO2n9yK9AiR9PX4KO0enKpWgNbWixkmfbHrXixiU8Py89jEKjRf7tuDQhB0e3mpUlCc/dcx9IwFqjlsFG7guD2WCLl3nHhPAg==&p=");

	lr_think_time(4);

	web_url("signin_2", 
		"URL=https://www.bing.com/fd/auth/signin?&action=header&provider=windows_live_id&save_token=0", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t28.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("fwlink", 
		"URL=https://go.microsoft.com/fwlink/?linkid=2133855&bucket=69", 
		"Resource=1", 
		"RecContentType=application/xml", 
		"Referer=", 
		"Snapshot=t29.inf", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("-146237828745445460", 
		"URL=https://edge.microsoft.com/autofillservice/core/page/3693946771987704403/-146237828745445460", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t30.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("APIKey", 
		"70109aa3567b40e3bb8ac9e67a07b58a-b00e4868-b511-4be4-90dd-6370c812f0af-7167");

	web_add_header("Client-Id", 
		"NO_AUTH");

	web_add_header("Expect", 
		"100-continue");

	web_add_header("SDK-Version", 
		"EVT-Windows-C++-No-3.5.131.1");

	web_add_header("Tickets", 
		"\"10001\"=\"p:t=GwBmAbuEBAAU2qcZHJoKGNizGOeyqM4OaIoSZ0MOZgAAENO6mHtVbGCAe1gLJDBfFVowAcn8NXHxTrwqjhzinnZQbEu5BQXQjhILB6zX2/8hhEASQJVttpGaGj/vUH4YQ7bW0fLBl8A+fUkRFYU5MVqMaPROp2hUK+XfSGU+nov9fb/F4KaCRG5rIKuGsxnkjCkp84g7h3rFFCqXvhV+O/sEE8MssWlhoV46JJPwew0UifxVa4SFZa+cacY9L6ZTXUyA4KJumeTNBGLNBXwyyJ+aEd/QfugEFjOIOuH9DWExUQExWeoosip30aJsx+oX9Yymn1aAJZIiED2n3iZWuT6FhZUGb8FUm6aX4vjWVxjiZVPgAdeXu9jrrSjjAeYWU7cBgukFoRLcvwGyDJZR1M+OqmEx2nQKcVurQtn0p6aet44wr13D9KprpKuWWXq8oiq45j34cg9xq/XXvcggv4ix8UNgAQ==&p=\"");

	web_add_header("Upload-Time", 
		"1713089983800");

	web_custom_request("1.0_2", 
		"URL=https://functional.events.data.microsoft.com/OneCollector/1.0/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t31.inf", 
		"ContentEncoding=deflate", 
		"Mode=HTTP", 
		"EncType=application/bond-compact-binary", 
		"BodyBinary=)\\x033.0I8Microsoft.WebBrowser.Personalization.SAN.HistoryAddUrlExq\\xF4\\x96\\xCA\\xE0\\x8C\\x9B\\xAE\\xDC\\x11\\xA9\"o:70109aa3567b40e3bb8ac9e67a07b58a\\xD1\\x06\\x82\\x84@\\xCB\\x15\n\\x01K\\x0B\\x01\t\\x01\\x0510001i\\x06LENOVO\\x89\\x0481NC\\x00\\xCB\\x16\n\\x01\\x00\\xCB\\x17\n\\x01I&r:66195836-a11a-40b1-9c4b-a2a4edce13ce\\xA9\\x0FWindows.Desktop\\x00\\xCB\\x18\n\\x01\\x89\\x0FWindows Desktop\\xA9,10.0.22621.1.amd64fre.ni_release.220506-1250\\x00\\xCB\\x19\n\\x01\\xA9fW"
		":0006160ee23f5a2234350cba651736e8000700000904!0000da39a3ee5e6b4b0d3255bfef95601890afd80709!msedge.exe\\xC9\\x06%2024/04/04:02:39:19!3e6e83!msedge.exe\\x00\\xCB\\x1F\n\\x01I\tUnmeteredi\\x07Unknown\\x00\\xCB \n\\x01)\\x1CEVT-Windows-C++-No-3.5.131.1I$2754F3E4-04E3-403D-AF01-47B9E69E87C1q\\x0E\\x89$2E86DFD5-279D-4C7F-97A1-2B366484710C\\x00\\xCB!\n\\x01i\\x06+03:00\\x00\\xCB%\n\\x01\\x00\\xC9<\\x06custom\\xCBF\n\\x01-\t\n"
		"\\x0C\\x0CAppInfo.ETag\\x00\\x07Channel0\\x00\\x91\\x08\\x00\\x0EConnectionTypei\\x04WiFi\\x00\\x0FCorrelationGuid\\x00\\x0FEventInfo.Level0\\x00\\x91\\x04\\x00\tPageTitlei\\x19\\xD0\\x9D\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD1\\x8F \\xD0\\xB2\\xD0\\xBA\\xD0\\xBB\\xD0\\xB0\\xD0\\xB4\\xD0\\xBA\\xD0\\xB0\\x00\\x05TabId0\\x00\\x91\\xF2\\xA6\\xD4\\x82\r\\x00\tTimestampi\\x182024-04-14T10:19:41.786Z\\x00\tclient_id0\\x00\\x91\\xC2\\xAF\\xB4\\xA0\\xA3\\xD9\\xB6\\xD0\\\\\\x00\\x04muidi "
		"047FE09A36C068D9071EF357375969CA\\x00\npop_sample0\\x08\\xA8\\x00\\x00\\x00\\x00\\x00\\x00Y@\\x00\tutc_flags0\\x00\\x91\\x80\\x80\\x80\\x80\\x80\\x80@\\x00\\x00\\x00)\\x033.0I8Microsoft.WebBrowser.Personalization.SAN.HistoryAddUrlExq\\xF4\\x96\\xCA\\xE0\\x8C\\x9B\\xAE\\xDC\\x11\\xA9\"o:70109aa3567b40e3bb8ac9e67a07b58a\\xD1\\x06\\x82\\x84@\\xCB\\x15\n\\x01K\\x0B\\x01\t\\x01\\x0510001i\\x06LENOVO\\x89\\x0481NC\\x00\\xCB\\x16\n\\x01\\x00\\xCB\\x17\n\\x01I&r"
		":66195836-a11a-40b1-9c4b-a2a4edce13ce\\xA9\\x0FWindows.Desktop\\x00\\xCB\\x18\n\\x01\\x89\\x0FWindows Desktop\\xA9,10.0.22621.1.amd64fre.ni_release.220506-1250\\x00\\xCB\\x19\n\\x01\\xA9fW:0006160ee23f5a2234350cba651736e8000700000904!0000da39a3ee5e6b4b0d3255bfef95601890afd80709!msedge.exe\\xC9\\x06%2024/04/04:02:39:19!3e6e83!msedge.exe\\x00\\xCB\\x1F\n\\x01I\tUnmeteredi\\x07Unknown\\x00\\xCB \n\\x01)\\x1CEVT-Windows-C++"
		"-No-3.5.131.1I$2754F3E4-04E3-403D-AF01-47B9E69E87C1q\\x0C\\x89$2E86DFD5-279D-4C7F-97A1-2B366484710C\\x00\\xCB!\n\\x01i\\x06+03:00\\x00\\xCB%\n\\x01\\x00\\xC9<\\x06custom\\xCBF\n\\x01-\t\n\\x0C\\x0CAppInfo.ETag\\x00\\x07Channel0\\x00\\x91\\x08\\x00\\x0EConnectionTypei\\x04WiFi\\x00\\x0FCorrelationGuid\\x00\\x0FEventInfo.Level0\\x00\\x91\\x04\\x00\tPageTitlei\redge://newtab\\x00\\x05TabId0\\x00\\x91\\xF2\\xA6\\xD4\\x82\r\\x00\tTimestampi\\x182024-04-14T10:19:41.786Z\\x00\t"
		"client_id0\\x00\\x91\\xC2\\xAF\\xB4\\xA0\\xA3\\xD9\\xB6\\xD0\\\\\\x00\\x04muidi 047FE09A36C068D9071EF357375969CA\\x00\npop_sample0\\x08\\xA8\\x00\\x00\\x00\\x00\\x00\\x00Y@\\x00\tutc_flags0\\x00\\x91\\x80\\x80\\x80\\x80\\x80\\x80@\\x00\\x00\\x00", 
		LAST);

	web_add_header("MS-CV", 
		"UUtxA8Xl379V35xryDd1gw");

	lr_think_time(11);

	web_url("activitystatus", 
		"URL=https://edge.microsoft.com/extensiondiagnostic/v1/activitystatus?x=id%3Daegnopegbbhjeeiganiajffnalhlkkjb%26v%3D1.4.0&x=id%3Dfjnehcbecaggobjholekjijaaekbnlgj%26v%3D3.84.0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t32.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"123.0.2420.81");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.22621");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	web_add_header("X-Microsoft-Update-Service-Cohort", 
		"3548");

	web_custom_request("update_2", 
		"URL=https://edge.microsoft.com/componentupdater/api/v1/update", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t33.inf", 
		"Mode=HTTP", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"msedge\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"jcmcegpcehdchljeldgmmfbgcpnmgedo\",\"brand\":\"GGLS\",\"cohort\":\"rrf@0.04\",\"enabled\":true,\"event\":[{\"download_time_ms\":12102,\"downloaded\":40440,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"309.55326.1.0\",\"previousversion\":\"1.20240413.1.0\",\"total\":40440,\"url\":\"http://msedge.b.tlu.dl.delivery.mp.microsoft.com/filestreamingservice/files/"
		"f99d6182-8b0f-4d04-93d1-2c29a567a3c6?P1=1713687037&P2=404&P3=2&P4=jqJ4jLfc6m0PyZrICQIA9YMswyNQONebZnBFGpVyo0iWtY%2fXtRzQB7RdmjstBxp%2fgiP58eOUHLDbCjXWl6uJPA%3d%3d\"},{\"eventresult\":1,\"eventtype\":3,\"install_time_ms\":154,\"nextfp\":\"1.6E3815CB1A887DB2D652E54C3E995A354149E43693E84768CE931FC9E65F379E\",\"nextversion\":\"309.55326.1.0\",\"previousfp\":\"1.40FA7C4DD457CB5B330E8C81AC44055BEF80305914F96A2D34AB1E54F85AC3AD\",\"previousversion\":\"1.20240413.1.0\"}],\"installdate\":-1,\"lang\":\"ru\""
		",\"packages\":{\"package\":[{\"fp\":\"1.6E3815CB1A887DB2D652E54C3E995A354149E43693E84768CE931FC9E65F379E\"}]},\"version\":\"309.55326.1.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":1,\"physmemory\":10,\"sse\":1,\"sse2\":1,\"sse3\":1,\"sse41\":1,\"sse42\":1,\"ssse3\":1},\"ismachine\":1,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22621.3447\"},\"prodversion\":\"123.0.2420.81\",\"protocol\":\"3.1\",\"requestid\":\""
		"{bed40fb6-0eb5-4847-a8a8-c9e08ef24c5f}\",\"sessionid\":\"{82b00345-d86d-4871-8a4b-cf415222115c}\",\"updaterversion\":\"123.0.2420.81\"}}", 
		LAST);

	web_add_header("X-AFS-CV", 
		"l9NKRKZQK/OfbMEhForbvp");

	web_add_header("X-AFS-ClientInfo", 
		"platform=Windows; os=Windows NT; osVer=10.0.22621; app=Microsoft Edge; appVer=123.0.2420.81; appChannel=stable; appInstallationId=3337287604877298657; region=RU;");

	web_add_header("X-Client-Data", 
		"CLUICIcQCLMQCNyIywE=");

	web_custom_request("command_4", 
		"URL=https://edge.microsoft.com/sync/v1/feeds/me/syncEntities/command/?client=Chromium&client_id=xoA3wCAk%2BKGKcH9sFEoxyQ%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t34.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTTP", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x18xoA3wCAk+KGKcH9sFEoxyQ==\\x10c\\x18\\x01\"\\xD3\\x17\n\\xDC\\x02\n$e3b18059-7bd9-4583-9fec-c47813cbf39e \\xB0\\xE6\\xB3\\xDC\\xE51(\\xD8\\x85\\xF4\\xE0\\xED10\\xF7\\x9A\\xF8\\xA3\\xB81:\\x17ntp.record_user_choices\\x90\\x01\\x00\\xAA\\x01\\xE2\\x01\\xB2\\xB4\\x12\\xDD\\x01\n\\x17ntp.record_user_choices\\x12\\xC1\\x01[{\"setting\":\"tscollapsed\",\"source\":\"tscollapsed_to_off\",\"timestamp\":1.698734941076e+12,\"value\":0},{\"setting\":\"breaking_news_dismissed\",\"source\":\""
		"ntp\",\"timestamp\":1.713089872601e+12,\"value\":{}}]\\xBA\\x01\\x1CuOuWSaJEin0p2bX/hQqawC+tIgU=\n\\x89\\x06\n$6b0ce0b4-a942-487c-8059-c12583cf6d4a \\x94\\x8C\\xAE\\x81\\xE71(\\x9D\\xEF\\xAA\\xE0\\xED10\\xBD\\xC6\\xC3\\x86\\xE61:\tencrypted\\x90\\x01\\x00\\xAA\\x01\\x9D\\x05\\x8A\\xB3\\x16\\x98\\x05\n\\xB5\\x03\nXLmf7HlOm+A4cHUmUukhz7luCIkmWUedklsP3djmsfS/jNhGG+Lsu+Yy3R8IR/2bIC19TEX98BIzUBYqFSpUhMg==\\x12\\xD8\\x02V/60tGfSepM7UOOMtOiYUuNqSpQd5YQqlw7z6SKYCdJAH/eJQJ1EtU+4ML6+"
		"7Yx3QgvXilLUkpd5A08SQgZGcA9SrJj0obNmZGRJklwypb5twE4ngTYILB4L4Tqd6NfsZYfS2oClRutIjWCAcCTejgXC3H5Fgp9CJCf+Pz0OVstAj4uEAyQAVkuMelcht4hMFtYXWiS5FnXhOFabKiV2H/H8c2U18UcY1AWEJeDuzTYq4wDaI/3oJZBF79Xp1vQSN+csmMX64LzyTu6CQiP2fU0+eVdIYWBigCZUVo9ZOULnuc58NpsEsyumdgHeX8ng3fFdLSq00/FOVzVnwWMsIw==\\x1A'\n\\x16http://localhost:1080/\\x10\\x00\\x18\\xD9\\xCE\\xB2\\xD1\\x9C\\x94\\xDD\\x17\"\\x00h\\x00*\\xB4\\x01\nXLmf7HlOm+A4cHUmUukhz7luCIkmWUedklsP3djmsfS/jNhGG+Lsu+Yy3R8IR/2bIC19TEX98BIzUBYqFSpUhMg=="
		"\\x12XZZojqwkNr9v7Dy7GlG8r3UCpkbZg5TXbeQmP2+1QXguH/lPukLSE823dLc7ZHfNTh3l9tbp7p8tSRr/KokifEQ==\\xBA\\x01\\x1ClVLxc/bV7z7ktctHUpZ5k8ssMEU=\n\\xA2\\x02\n$732e48c2-6c1a-496e-bdaf-07cbe9d8549d \\x00(\\xE7\\xA1\\xE0\\xE0\\xED10\\xE7\\xA1\\xE0\\xE0\\xED1:\\x1CLAPTOP-UDHO2OV6 (tab node 0)\\x90\\x01\\x00\\xAA\\x01\\xA8\\x01\\xBA\\xBC\\x18\\xA3\\x01\n\\x18xoA3wCAk+KGKcH9sFEoxyQ==\\x1A\\x84\\x01\\x08\\xA6\\x91\\xAA\\xC1\\x06\\x10\\xA4\\x91\\xAA\\xC1\\x06\\x18\\x00 \\x00(\\x002\\x00:n\\x12(chrome-search://"
		"local-ntp/local-ntp.html\\x1A\\x00\"\\x19\\xD0\\x9D\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD1\\x8F \\xD0\\xB2\\xD0\\xBA\\xD0\\xBB\\xD0\\xB0\\xD0\\xB4\\xD0\\xBA\\xD0\\xB00\\x06@\\x18H\\xDE\\xA1\\xE0\\xE0\\xED1P\\x00X\\x00`\\x00x\\xB0\\xC6\\xA0\\xB4\\xA0\\x94\\xDD\\x17\\xA0\\x01\\xC8\\x01\\xC8\\x01\\x06\\xD0\\x01\\x00\\xC8>\\x00 \\x00\\xBA\\x01\\x1C20WG9Ij4Kh0slIEKN0PMSQMP3HI=\n\\xAF\\x01\n$c4d9225e-ab75-42c9-aed9-c868fb423308 \\xDF\\x82\\xBC\\xDB\\xED1(\\xA5\\xEE\\xF1\\xE0\\xED10\\xDC\\xAA\\xDB\\xE8\\xD90"
		":\\x18LAPTOP-UDHO2OV6 (header)\\x90\\x01\\x00\\xAA\\x015\\xBA\\xBC\\x181\n\\x18xoA3wCAk+KGKcH9sFEoxyQ==\\x12\\x15\\x1A\\x0FLAPTOP-UDHO2OV6 \\x01(\\x01\\xBA\\x01\\x1CKPneuqyQIqvhTj1e8nzcIhXfC4Q=\n\\xA2\\x02\n$7f699138-5b05-41f7-a89b-f9833f37891a \\x00(\\xC2\\xA9\\xE6\\xE0\\xED10\\xC2\\xA9\\xE6\\xE0\\xED1:\\x1CLAPTOP-UDHO2OV6 (tab node 1)\\x90\\x01\\x00\\xAA\\x01\\xA8\\x01\\xBA\\xBC\\x18\\xA3\\x01\n\\x18xoA3wCAk+KGKcH9sFEoxyQ=="
		"\\x1A\\x84\\x01\\x08\\xC8\\x92\\xAA\\xC1\\x06\\x10\\xCB\\x92\\xAA\\xC1\\x06\\x18\\x00 \\x00(\\x002\\x00:n\\x12(chrome-search://local-ntp/local-ntp.html\\x1A\\x00\"\\x19\\xD0\\x9D\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD1\\x8F \\xD0\\xB2\\xD0\\xBA\\xD0\\xBB\\xD0\\xB0\\xD0\\xB4\\xD0\\xBA\\xD0\\xB00\\x00@\\x07H\\x81\\x88\\xE4\\xE0\\xED1P\\x00X\\x00`\\x00x\\xE8\\xC7\\xF7\\xD1\\xA0\\x94\\xDD\\x17\\xA0\\x01\\xC8\\x01\\xC8\\x01\\x06\\xD0\\x01\\x00\\xC8>\\x00 \\x01\\xBA\\x01\\x1CX3tO7O/YcASZuiU+ilg8r3eTiEY=\n"
		"\\xF9\\x02\n$d11f4c00-68b9-40db-b2aa-825f6f13d583 \\x00(\\x90\\xC9\\xF1\\xE0\\xED10\\xC3\\xF8\\xF0\\xE0\\xED1:\\x1CLAPTOP-UDHO2OV6 (tab node 3)\\x90\\x01\\x00\\xAA\\x01\\xFF\\x01\\xBA\\xBC\\x18\\xFA\\x01\n\\x18xoA3wCAk+KGKcH9sFEoxyQ==\\x1A\\xDB\\x01\\x08\\xE1\\x92\\xAA\\xC1\\x06\\x10\\xE2\\x92\\xAA\\xC1\\x06\\x18\\x00 \\x01(\\x002\\x00:n\\x12(chrome-search://local-ntp/local-ntp.html\\x1A\\x00\"\\x19\\xD0\\x9D\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD1\\x8F "
		"\\xD0\\xB2\\xD0\\xBA\\xD0\\xBB\\xD0\\xB0\\xD0\\xB4\\xD0\\xBA\\xD0\\xB00\\x00@\\x1BH\\x8E\\xE0\\xE9\\xE0\\xED1P\\x00X\\x00`\\x00x\\xB0\\xED\\xAF\\xFE\\xA0\\x94\\xDD\\x17\\xA0\\x01\\xC8\\x01\\xC8\\x01\\x06\\xD0\\x01\\x00\\xC8>\\x00:U\\x12\\x1Fhttp://localhost:1080/WebTours/\\x1A\\x00\"\tWeb Tours0\\x01@\\x1EH\\xF5\\xC6\\xF1\\xE0\\xED1P\\x00X\\x01`\\x00x\\x88\\x82\\xAB\\xBB\\xA1\\x94\\xDD\\x17\\xA0\\x01\\xC8\\x01\\xC8\\x01\\x06\\xD0\\x01\\x02\\xC8>\\x00 \\x03\\xBA\\x01\\x1CjezMd4cNHOI6aV4/mnud+iX9eGo"
		"=\n\\xF8\\x02\n$abbbaf62-adfb-415f-a44c-052e3e53798c \\x00(\\xD4\\x94\\xE7\\xE0\\xED10\\xDD\\xBD\\xE6\\xE0\\xED1:\\x1CLAPTOP-UDHO2OV6 (tab node 2)\\x90\\x01\\x00\\xAA\\x01\\xFE\\x01\\xBA\\xBC\\x18\\xF9\\x01\n\\x18xoA3wCAk+KGKcH9sFEoxyQ==\\x1A\\xDA\\x01\\x08\\xD1\\x92\\xAA\\xC1\\x06\\x10\\xD0\\x92\\xAA\\xC1\\x06\\x18\\x00 \\x01(\\x002\\x00:n\\x12(chrome-search://local-ntp/local-ntp.html\\x1A\\x00\"\\x19\\xD0\\x9D\\xD0\\xBE\\xD0\\xB2\\xD0\\xB0\\xD1\\x8F "
		"\\xD0\\xB2\\xD0\\xBA\\xD0\\xBB\\xD0\\xB0\\xD0\\xB4\\xD0\\xBA\\xD0\\xB00\\x06@\\x10H\\xD5\\xBD\\xE6\\xE0\\xED1P\\x00X\\x00`\\x00x\\x88\\xE0\\xEA\\xE4\\xA0\\x94\\xDD\\x17\\xA0\\x01\\xC8\\x01\\xC8\\x01\\x06\\xD0\\x01\\x00\\xC8>\\x00:T\\x12\\x1Fhttp://localhost:1080/WebTours/\\x1A\\x00\"\tlocalhost0\\x01@\\x18H\\xC1\\x94\\xE7\\xE0\\xED1P\\x00X\\x01`\\x00x\\xE8\\x9B\\x91\\xEA\\xA0\\x94\\xDD\\x17\\xA0\\x01\\x00\\xC8\\x01\\x06\\xD0\\x01\\x00\\xC8>\\x00 \\x02\\xBA\\x01\\x1Ctv0Wlcv8QzeAM6/nQR0kudQ8e9E="
		"\\x12\\x18xoA3wCAk+KGKcH9sFEoxyQ==\"V\\x08\\x88\\x81\\x02\\x08\\xC6\\xA6\\x02\\x08\\xB1\\xE6\\x02\\x08\\xCF\\xF3\\x03\\x08\\xCD\\xBE\\x02\\x08\\xF7\\xF7\\x02\\x08\\xC7\\x87\\x03\\x08\\x9F\\xEF\\x05\\x08\\xEB\\x95\t\\x08\\x9A\\xB7\t\\x08\\xEE\\xF7!\\x08\\xFC\\xDE$\\x08\\xC9\\x8B)\\x08\\xA1\\xDD'\\x08\\xD0\\xAF:\\x08\\xA9\\xF0O\\x08\\xF1\\xBFG\\x08\\xB5\\xDAD\\x08\\x81\\xF5\\x02\\x10\\x01\\x18\\x00 \\x010\\x01@\\x012\\x80\\x02Bn82%Bk\"Z6Cbsd9[o}cg3R>10\"F%7|Exq+HRHe/AtEAvAu^(_*@#tA8*LG$5\"8!4Y~"
		"W\\\\m-(@Es!v -\"0;uzpV\"(MGuu]lZdcFjI%-Y[hE:&CSPVu!m*WQ;9K(GV- #;xXG<i(DL-kG<72ym4[zx32:P)FMZR-Ph(NO3fU0$JbHbQw09FnNa3i|SSq^Kmt^NzT< G0E6HCOTgU1&.8$p]deW1^N<DM-BFuD'EKP,9'N,fGuKtjR sQ{VG6'')EqGf:\\x1FProductionEnvironmentDefinitionR\\x06\\x10\\x01\\x18\\x00 \\x00Z\\x05\n\\x03106b 00000000000000000000000000000000j\\x02\\x10\\x01r\\x1Cchr:xoA3wCAk+KGKcH9sFEoxyQ==", 
		LAST);

	web_add_header("Origin", 
		"http://localhost:1080");

	web_revert_auto_header("Sec-Fetch-Dest");

	web_add_header("Sec-Fetch-Dest", 
		"frame");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_revert_auto_header("Sec-Fetch-Site");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(6);

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t35.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=userSession", "Value=138767.919238558HVDHiHtpitfiDDDDtcicHpctQAHf", ENDITEM, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		"Name=login.x", "Value=74", ENDITEM, 
		"Name=login.y", "Value=11", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_custom_request("report", 
		"URL=https://deff.nelreports.net/api/report", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t36.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Sec-Fetch-Site", 
		"same-site");

	web_add_header("Sec-MS-GEC", 
		"2A1D96958FD5C8C5C8A32F18E6097D405C44C3EB78D2801F22FC0F380BD14FAB");

	web_add_header("Sec-MS-GEC-Version", 
		"1-123.0.2420.81");

	web_add_header("X-Client-Data", 
		"eyIxIjoiMSIsIjEwIjoiXCJhazdIY1FwbmxabjhtOWFUeVJSK1RCbERzK051MGVBUHlQUEpsaEJnMy9nPVwiIiwiMiI6IjEiLCIzIjoiMCIsIjQiOiIzMzM3Mjg3NjA0ODc3Mjk4NjU3IiwiNSI6IlwiQ2t1QW1sUHhIejJDUmFJbkJWNmlhbTVVMmRSazdsREV6Z3RiK0I5TlVUOD1cIiIsIjYiOiJzdGFibGUiLCI3IjoiMjA0MDEwOTQ2NTYwMiIsIjkiOiJkZXNrdG9wIn0=");

	web_add_header("X-Edge-Shopping-Flag", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("config", 
		"URL=https://assets.msn.com/resolver/api/resolve/v3/config/?expType=AppConfig&expInstance=default&apptype=edgeChromium&v=20240412.461&targetScope={%22audienceMode%22:%22adult%22,%22browser%22:{%22browserType%22:%22edgeChromium%22,%22version%22:%22123%22,%22ismobile%22:%22false%22},%22deviceFormFactor%22:%22desktop%22,%22domain%22:%22ntp.msn.com%22,%22locale%22:{%22content%22:{%22language%22:%22en%22,%22market%22:%22xl%22},%22display%22:{%22language%22:%22en%22,%22market%22:%22xl%22}},%22os%22"
		":%22windows%22,%22platform%22:%22web%22,%22pageType%22:%22dhp%22,%22pageExperiments%22:[%22prg-1s-header%22,%22prg-1s-sm-workid%22,%22prg-1s-sptunirev%22,%22prg-1s-twid%22,%22prg-1s-workid%22,%22prg-1s-wpocfp1%22,%22prg-1sw-artgol%22,%22prg-1sw-clari%22,%22prg-1sw-deferpc%22,%22prg-1sw-dftloc-c%22,%22prg-1sw-fieplc%22,%22prg-1sw-finplsp2%22,%22prg-1sw-finvldc%22,%22prg-1sw-iconmap%22,%22prg-1sw-iplsd-ntp%22,%22prg-1sw-iplsdc-ntp%22,%22prg-1sw-iplsdc1p2%22,%22prg-1sw-iplsdp1%22,"
		"%22prg-1sw-iplsdp2%22,%22prg-1sw-lgen%22,%22prg-1sw-mtr-en-c%22,%22prg-1sw-pde0%22,%22prg-1sw-pr2clarity%22,%22prg-1sw-pro2pre-c%22,%22prg-1sw-profile%22,%22prg-1sw-profilecard%22,%22prg-1sw-profilesma%22,%22prg-1sw-rr2fn%22,%22prg-1sw-rr2fp%22,%22prg-1sw-sacfcliffv3at1%22,%22prg-1sw-srdus%22,%22prg-1sw-tbr11combtup%22,%22prg-1sw-tbr11meterub%22,%22prg-1sw-ucsap%22,%22prg-1sw-wxevolnoti%22,%22prg-1sw-wxhurac-c%22,%22prg-1sw-wxmptreplace%22,%22prg-ad-abd%22,%22prg-ad-article-hc%22,"
		"%22prg-ad-pdedupe-c%22,%22prg-ad-safe%22,%22prg-adspeek%22,%22prg-boost-ntpb-ww%22,%22prg-boost-ntpcm-ww%22,%22prg-boost-winhp%22,%22prg-boost-winhp-ww%22,%22prg-boostcmb-ww%22,%22prg-c-arb-rsz%22,%22prg-cf-wc%22,%22prg-cg-ad-ref-if-2%22,%22prg-cg-ad-sky%22,%22prg-cg-hb%22,%22prg-cg-search%22,%22prg-cg-seclarity%22,%22prg-chpg-ldgw%22,%22prg-chpg-tpft%22,%22prg-edg-tm500%22,%22prg-edg-tmtrig%22,%22prg-ent-prentp%22,%22prg-entpremier-ntp-t%22,%22prg-f3-video%22,%22prg-fin-cdicon%22,"
		"%22prg-fin-cnosign%22,%22prg-fin-errde%22,%22prg-fin-fret1c%22,%22prg-fin-l2nav22%22,%22prg-hd-suggest%22,%22prg-mscl-hld%22,%22prg-msclck-rf%22,%22prg-mvp-bingdflog%22,%22prg-mvp-prodcurpos%22,%22prg-mvp-sitedest%22,%22prg-nav-pros%22,%22prg-ncm%22,%22prg-ntp-earlyfeedssr%22,%22prg-ntp-rfwv-t%22,%22prg-p2-dsbrf%22,%22prg-p2-tsk-cmsev%22,%22prg-peek-ratio-30%22,%22prg-pr1-evolvelifecycle%22,%22prg-pr2-flashrev%22,%22prg-pr2-getpinnedwd%22,%22prg-pr2-pagecontext%22,%22prg-pr2-pulsev2%22,"
		"%22prg-pr2-pulsev2r%22,%22prg-pr2-rmplchdr-t2%22,%22prg-pr2-shoreline%22,%22prg-pr2-sidebar%22,%22prg-pr2-sidebar-t%22,%22prg-pr2-tfpls%22,%22prg-premier-ntp-rc1%22,%22prg-premier-pr1-c%22,%22prg-remflttel%22,%22prg-river-infod2%22,%22prg-river-infodl%22,%22prg-rpt2%22,%22prg-sh-bd-disgb%22,%22prg-sh-bd-newbanner%22,%22prg-sh-bd-newchckot%22,%22prg-sh-bd-nwchk%22,%22prg-sh-bd-pagoff%22,%22prg-sh-bd-video%22,%22prg-sh-bd-xtracash%22,%22prg-sh-recopdp%22,%22prg-sh-rmitmlnk%22,%22prg-sh-usecshk%22,"
		"%22prg-sh-usecshkpdp%22,%22prg-shop-staginc%22,%22prg-shopping-treat%22,%22prg-sp-liveapi%22,%22prg-sv1plus-stag%22,%22prg-tat-msntrvl-c%22,%22prg-titlemapping-1%22,%22prg-titlemapping-a%22,%22prg-tps-sort%22,%22prg-traffic-staginc%22,%22prg-ugc-likechange%22,%22prg-upsaip-r-t%22,%22prg-upsaip-w1-t%22,%22prg-vidbuf1%22,%22prg-wg-directly-jump%22,%22prg-wpo-boostbanner%22,%22prg-wpo-boostcoach%22,%22prg-wtch-inarad-t3%22,%22prg-wx-ncar%22,%22prg-wx-reactads%22]}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t37.inf", 
		"Mode=HTTP", 
		LAST);

	web_revert_auto_header("Origin");

	lr_think_time(4);

	web_custom_request("report_2", 
		"URL=https://deff.nelreports.net/api/report", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t38.inf", 
		"Mode=HTTP", 
		"EncType=application/reports+json", 
		"Body=[{\"age\":279,\"body\":{\"blockedURL\":\"trusted-types-sink\",\"columnNumber\":10544,\"disposition\":\"report\",\"documentURL\":\"https://ntp.msn.com/edge/ntp?locale=ru&title=%D0%9D%D0%BE%D0%B2%D0%B0%D1%8F%20%D0%B2%D0%BA%D0%BB%D0%B0%D0%B4%D0%BA%D0%B0&dsp=0&sp=%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81&startpage=1&PC=U531&prerender=1\",\"effectiveDirective\":\"require-trusted-types-for\",\"lineNumber\":1,\"originalPolicy\":\"child-src 'self';connect-src 'self' *.mavideo.microsoft.com arc.msn.com "
		"assets.msn.com assets2.msn.com assets.msn.cn assets2.msn.cn browser.events.data.msn.com browser.events.data.msn.cn browser.events.data.microsoftstart.com browser.events.data.microsoftstart.cn business.bing.com/api/ usgov.business.bing.com/api/ cdn.hubblecontent.osi.office.net events-sandbox.data.msn.com events-sandbox.data.msn.cn events-sandbox.data.microsoftstart.com events-sandbox.data.microsoftstart.cn finance-services.msn.com https://*.sharepoint.com/_api/v2.0/ https://*.sharepoint-df.com/_api"
		"/v2.0/ https://*.sharepoint.com/_api/v2.1/ https://*.sharepoint-df.com/_api/v2.1/ https://bingretailmsndata.azureedge.net/msndata/ https://browser.pipe.aria.microsoft.com/Collector/ https://dev.virtualearth.net/REST/v1/Imagery/ https://ecn.dev.virtualearth.net https://jsconfig.adsafeprotected.com https://g.bing.com https://msx.bing.com https://petrol.office.microsoft.com/v1/feedback https://privacyportal.onetrust.com/request/v1/consentreceipts https://sapphire.api.microsoftapp.net https://"
		"services.bingapis.com https://substrate.office.com/PeoplePredictionsB2/StreamsPreview https://substrate.office.com/PeoplePredictionsB2/StreamsPreviewById https://substrate.office.com/autodiscover/ https://trafficanswer.trafficmanager.net https://*.clarity.ms https://edge.microsoft.com/edgedeeplearning/ img-s-msn-com.akamaized.net login.microsoftonline.com notification.services.msn.com ocws.officeapps.live.com/ocs/ ocws-eu.officeapps.live.com/ocs/ odc.officeapps.live.com/odc/ "
		"prod-video-cms-amp-microsoft-com.akamaized.net r.bing.com/rp/rms_pr.png raka.bing.com/rp/rms_pr.png ris.api.iris.microsoft.com srtb.msn.com srtb.msn.cn srtb-pulsar.msn.com substrate.office.com/FocusedInboxB2/api/v1/ substrate.office.com/PeoplePredictionsB2/graphql substrate.office.com/PeoplePredictionsB2/MeTaPreview substrate.office.com/PeoplePredictionsB2/SPImageProxied substrate.office.com/PeoplePredictionsB2/SpPreview substrate.office.com/api/beta/me/WorkingSetFiles substrate.office.com/api/"
		"beta/me/officegraphinsights/trending substrate.office.com/recommended/api/beta/edgeworth/ substrate.office.com/api/v2.0/ substrate.office.com/peoplepredictionsb2/feedback substrate.office.com/peoplepredictionsb2/microsoftfeed substrate.office.com/recommended/api/v1.0/files substrate.office.com/search/api/v1/ substrate.office.com/todo/api/v1/ substrate.office.com/todob2/api/v1/ webshell.suite.office.com/api/shell/newtab wss://www.bing.com/opaluqu/speech/recognition/interactive/cognitiveservices/ "
		"wss://sr.bing.com/opaluqu/speech/recognition/interactive/cognitiveservices/ www.bing.com/fd/ls/ls.gif www.msn.com www.msn.cn www.microsoftstart.com cn.bing.com/api/ cn.bing.com/bnc/ cn.bing.com/pnp/ cn.bing.com/profile/interestmanager/update *.cn.mm.bing.net *.mm.cn.bing.net www.bing.com/HPImageArchive.aspx www.bing.com/api/custom/opal/reco/ www.bing.com/DSB cn.bing.com/DSB www.bing.com/DSB/partner/ cn.bing.com/DSB/partner/ www.bing.com/api/ www.bing.com/as/ www.bing.com/AS/Suggestions "
		"www.bing.com/AS/Suggestions/v2 www.bing.com/bnc/ www.bing.com/crop/warmer.png www.bing.com/historyHandler www.bing.com/images/sbidlg www.bing.com/pnp/ www.bing.com/profile/history/data www.bing.com/profile/interestmanager/update www.bing.com/retail/msn/api/shopcard www.bing.com/retailexp/msn/api/ www.bing.com/retailexpdata/msndata/ www.bing.com/rp/rms_pr.png www.bing.com/th wus-streaming-video-msn-com.akamaized.net prod-streaming-video-msn-com.akamaized.net prod-streaming-video.msn.cn "
		"zerocodecms.blob.core.windows.net *.oneservice.msn.com *.oneservice.msn.cn api.msn.com api.msn.cn ent-api.msn.com ent-api.msn.cn ppe-api.msn.com ppe-api.msn.cn graph.microsoft.com/beta/ graph.microsoft.com/v1.0/ https://*.vo.msecnd.net https://user.auth.xboxlive.com/user/authenticate https://xsts.auth.xboxlive.com/xsts/authorize https://titlehub.xboxlive.com/users/ https://t.ssl.ak.dynamic.tiles.virtualearth.net https://dynamic.t0.tiles.ditu.live.com https://dev.virtualearth.net/REST/v1/Routes/ "
		"https://dev.ditu.live.com/REST/v1/Routes/ https://dev.virtualearth.net/REST/v1/Locations/ https://dev.ditu.live.com/REST/v1/Locations/ browser.events.data.microsoft.com;default-src 'none';font-src 'self' data: assets.msn.com assets2.msn.com assets.msn.cn assets2.msn.cn;frame-src https://api.msn.com/auth/cookie/silentpassport https://api.msn.cn/auth/cookie/silentpassport https://www.msn.com https://www.msn.cn https://www.microsoftstart.com login.live.com login.microsoftonline.com www.bing.com/covid"
		" www.bing.com/rewardsapp/flyout www.bing.com/shop www.bing.com/shop/halloween www.bing.com/videos/search www.facebook.com www.odwebp.svc.ms www.youtube.com msn.pluto.tv www.bing.com/wpt/prefetchcib https://res.cdn.office.net/ business.bing.com sip: mailto: edge-auth.microsoft.com;img-src https://* blob: chrome-search://ntpicon/ chrome-search://local-ntp/ chrome-search://theme/ data:;media-src 'self' blob: *.mavideo.microsoft.com assets.msn.com assets2.msn.com assets.msn.cn assets2.msn.cn https://"
		"sapphire.azureedge.net th.bing.com/th wus-streaming-video-msn-com.akamaized.net prod-streaming-video-msn-com.akamaized.net prod-streaming-video.msn.cn liveshopping.azureedge.net;report-to csp-endpoint;style-src 'self' 'unsafe-inline' c.s-microsoft.com/mscc/ assets.msn.com assets2.msn.com assets.msn.cn assets2.msn.cn;worker-src 'self' blob: 'report-sample';require-trusted-types-for 'script';trusted-types serviceWorkerUrlPolicy baw-trustedtypes-policy svgPassThroughPolicy xmlPassThroughPolicy "
		"webpackTrustedTypesPolicy webWorkerUrlPolicy inlineHeadCssPassthroughPolicy bundleUrlPolicy fallbackBundleUrlPolicy scriptSrcUrlPolicy dompurify fast-html base-html-policy 'allow-duplicates';script-src 'nonce-2qvfKGG1LW7BrNTI3Ph7uiJvgvi6Thb9GKn26NXNMl4=' 'strict-dynamic'\",\"referrer\":\"\",\"sample\":\"Element setAttribute|https://assets.msn.com/staticsb/statics/\",\"sourceFile\":\"https://assets.msn.com/staticsb/statics/latest/oneTrust/1.9/scripttemplates/otSDKStub.js\",\"statusCode\":200},\""
		"type\":\"csp-violation\",\"url\":\"https://ntp.msn.com/edge/ntp?locale=ru&title=%D0%9D%D0%BE%D0%B2%D0%B0%D1%8F%20%D0%B2%D0%BA%D0%BB%D0%B0%D0%B4%D0%BA%D0%B0&dsp=0&sp=%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81&startpage=1&PC=U531&prerender=1\",\"user_agent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0\"}]", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("X-AFS-CV", 
		"+yyLvICo/enGONOj7eldki");

	web_add_header("X-AFS-ClientInfo", 
		"platform=Windows; os=Windows NT; osVer=10.0.22621; app=Microsoft Edge; appVer=123.0.2420.81; appChannel=stable; appInstallationId=3337287604877298657; region=RU;");

	web_add_header("X-Client-Data", 
		"CLUICIcQCLMQCNyIywE=");

	web_custom_request("command_5", 
		"URL=https://edge.microsoft.com/sync/v1/feeds/me/syncEntities/command/?client=Chromium&client_id=xoA3wCAk%2BKGKcH9sFEoxyQ%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t39.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTTP", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x18xoA3wCAk+KGKcH9sFEoxyQ==\\x10c\\x18\\x02*\\xCF\\x04\\x12\\x04\\x08\\x00\\x10\\x00\\x18\\x012\\x1E\\x08\\x88\\x81\\x02\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xC6\\xA6\\x02\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x01(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xB1\\xE6\\x02\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x01"
		"(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xCF\\xF3\\x03\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xCD\\xBE\\x02\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xF7\\xF7\\x02\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00"
		"(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xC7\\x87\\x03\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x01(\\x000\\x008\\x00@\\x002\\x1E\\x08\\x9F\\xEF\\x05\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xEB\\x95\t\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\x9A\\xB7\t"
		"\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xFC\\xDE$\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xC9\\x8B)\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xA1\\xDD'\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00"
		"(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xD0\\xAF:\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xA9\\xF0O\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xF1\\xBFG\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00"
		"(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xB5\\xDAD\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\x81\\xF5\\x02\\x12\\x08\\x84\\xC0\\x19\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x0CP\\x00\\xC0>\\x01:\\x1FProductionEnvironmentDefinitionR^\nD\\x12B8\\x00@\\x00R\\x04\\x08\\x00\\x10\\x00`\\x0C\\x92\\x03\\x18wtzzWjme8U1Chq1nRtpRcj.1\\x92\\x03\\x18l9NKRKZQK/OfbMEhForbvp.1\n"
		"\\x04\\x18\\xC6\\xA6\\x02\n\\x04\\x18\\xC7\\x87\\x03\n\\x04\\x18\\xB1\\xE6\\x02\\x10\\x01\\x18\\x00 \\x00Z\\x05\n\\x03106b 00000000000000000000000000000000j\\x02\\x10\\x01r\\x1Cchr:xoA3wCAk+KGKcH9sFEoxyQ==", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"frame");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(11);

	web_url("nav.pl_2", 
		"URL=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/login.pl", 
		"Snapshot=t40.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Sec-MS-GEC", 
		"2A1D96958FD5C8C5C8A32F18E6097D405C44C3EB78D2801F22FC0F380BD14FAB");

	web_add_header("Sec-Fetch-Site", 
		"same-site");

	web_add_header("Origin", 
		"https://ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-MS-GEC-Version", 
		"1-123.0.2420.81");

	web_add_auto_header("X-Client-Data", 
		"eyIxIjoiMSIsIjEwIjoiXCJhazdIY1FwbmxabjhtOWFUeVJSK1RCbERzK051MGVBUHlQUEpsaEJnMy9nPVwiIiwiMiI6IjEiLCIzIjoiMCIsIjQiOiIzMzM3Mjg3NjA0ODc3Mjk4NjU3IiwiNSI6IlwiQ2t1QW1sUHhIejJDUmFJbkJWNmlhbTVVMmRSazdsREV6Z3RiK0I5TlVUOD1cIiIsIjYiOiJzdGFibGUiLCI3IjoiMjA0MDEwOTQ2NTYwMiIsIjkiOiJkZXNrdG9wIn0=");

	web_add_auto_header("X-Edge-Shopping-Flag", 
		"1");

	web_custom_request("favicon.ico", 
		"URL=https://assets.msn.com/statics/icons/favicon.ico", 
		"Method=HEAD", 
		"Resource=1", 
		"RecContentType=image/x-icon", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t41.inf", 
		LAST);

	web_add_cookie("elt="
		"%7B%22access_token%22%3A%22eyJhbGciOiJSU0EtT0FFUCIsImVuYyI6IkExMjhDQkMtSFMyNTYiLCJ4NXQiOiJEZTRNSWJTY1ExeTdMYlBGSVR3emNMRmxrcFkiLCJ6aXAiOiJERUYifQ.SxRT7SBHXq6ai_uMHI-Rzyb6EHFk7jkDeT6Pb4YSD_I_cU5Br_eA_sysCQNT11RCVM1BCfrB2NwK8BU2xaGlRh2XqKKwwmEMo3je8zL2qLLbd1zyfyRZ-nUu-Ks-ulvEphP8LaxQK6Q5WWFFlAC3Le_7PDr2jm76KDcEWL31Q3vlLY-kD-SjUsEHZZNoK0hj6H005f-ubR_mr92caA9gnUL6-C5Y8N1-KTCAgm39S9L4f22PuRJZJ3jo3B-pWlnrlFLdn-wGR_R50D8EcJlB-pnVCnW8I8ntNkmAcXTGUWm812uMI8sbqHYe0_JmcOOoALIf2rEVcJZy4t7R6dvgFw.CnB833luCepxu"
		"FGnVeXD7w.SBrUl8g2BP9N95ZCZR8-rdLKT8UHycGqU8wsuWhTqkOVxYDJtz5p6xvcb0KyUd2JrQ6r_tBDQ2p6HQJ4jVjq1HI4oo2yStITYyFwp5AZu4nu5ApMxk-5hdvbY8zbbZpjkuME7Bq1LSu9ISWwRBIQhwjpjlQq9SViEQlXIO-kp5Ap0iDz5v2SQWj33OOxOGcqrlU1Ndh1yRc4SuSde4zZdxf7Nj6bzYZyIWnUR7aF1_SSGHigimBuFAi4sVnCbgB1GSG-k4vXHaXRUweBE5FHGw02YQKNbOco5G5K18EoYjVSEiVKwwtJsZdxBuTY3fm0mWXmbjjkUcrhwcrLXRYCYEtuYJgh7Z2IC0RxovKv-6IUyR9Wz9iD_MoOgbxzBV_7-ooIpvoMmsxQnCfjT_qvOiLE2pYH1cblK8v-yy2GOGe-1g6fNCWO2ybD3vIUChvfVmueKEPJ1_LrDJZv5MwbGOpRBALEl3HyGoBa9AJtRKY3"
		"PKn-9ppCKusni_iN7nO7cIi6sI4UxHVbSUyEBsto-Ap84ea9nFUW8vshCu1dc5Bs7j3j5kkgqqegNukrqu8ft7WaDK5h8s41O5UDO1MtM_nnTIcPfxRdfeFPFyjna43t3ZBR5Dl1xsjf3SyvwPwhHMq_VdedrcE8OeJgI51N5Nx6jKhV5T_M64z5YPY3AD9aR5J91y71e-sn3caqB6gMEtMxJksr2qW275fe92bSUhWro8zKibzStxmEzWBBZB26NoaTrjUBLcmYI_9pxEk8nsS3fOpS3ubZ4byKypkDQbPIb3yNH0ZXEHQb38N_83Swk7UJFBv6kj_fiQFAi8t2kpilT4cDbReYU5s_P2znwv1V_6uuN8kjIrTF-Ekb5PFB_NSr2afmbjY6yrl4IvGW5IHly3V72Wv57A7sanuyqNPJS-sWQs7WUhhxhXVZYhMKcDDAYwUiMwb7jxcB2HBTudPA2BrbOeblOdTdlEA01cUduKZFjw2kvU"
		"ciSs3F2INRUjPuuAl1Q3yQ-qxcskAxi8upyfcdH1loUTBirrxi8pxd4oN2ujsutxTQP6ShIkJpx2I9DetmeXj8OC_k717S0z12aAnbzaLDl957ZY1EINIqLGsWXUEVS6m05_vZ2sBmu9HafYtuBXGaen1t7I57EnX6vhTFJAFJWdevbzzhYz-duvNDwEqhAkOaLJODZqcJJlDf2i_RhR1q4wFi9ZrsjvXuY3OhK9nxXU3nKDfV4yvk1YrcJeFuZ1RvkN3qjguJ4U3_-uvuXRtJ4d8Le0ZyA0bU4VYAABxMvHvoKCU8jKoDch4LOZLT5aGPIsnSvtnyiwym-20eGLEN59i1q1XaKXa1YyXJLe-9hUPmS-Wb4_jnLO0DwyDOu44rHzo3OJ3t7ceYpnSV0PuY6TFxzeZpdQJVc54uQHvqImxSzro7zw.oaCcURkXMd0VRr2chosSfw%22%2C%22account_type%22%3A%22MSA%22%2C%22l"
		"ogin_hint%22%3A%22naominguema@mail.ru%22%2C%22e%22%3A%22d7410ae0%22%7D; DOMAIN=ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-MS-GEC", 
		"ACC91C13C13940C5F92958826644C2D97BB012E5DE823C4011CFEE6F74688AAB");

	web_add_header("device-memory", 
		"8");

	web_add_header("downlink", 
		"0.15");

	web_add_header("ect", 
		"slow-2g");

	web_add_header("rtt", 
		"3000");

	web_add_header("sec-ch-dpr", 
		"1");

	web_add_header("sec-ch-prefers-color-scheme", 
		"light");

	web_add_header("sec-ch-ua-arch", 
		"\"x86\"");

	web_add_header("sec-ch-ua-bitness", 
		"\"64\"");

	web_add_header("sec-ch-ua-full-version", 
		"\"123.0.2420.81\"");

	web_add_header("sec-ch-ua-full-version-list", 
		"\"Microsoft Edge\";v=\"123.0.2420.81\", \"Not:A-Brand\";v=\"8.0.0.0\", \"Chromium\";v=\"123.0.6312.106\"");

	web_add_header("sec-ch-ua-model", 
		"\"\"");

	web_add_header("sec-ch-ua-platform-version", 
		"\"15.0.0\"");

	web_add_header("sec-ch-viewport-height", 
		"429");

	web_add_header("sec-ch-viewport-width", 
		"910");

	web_add_header("sec-edge-ntp", 
		"{\"back_block\":0,\"bg_cur\":{\"configIndex\":4,\"provider\":\"Video\"},\"bg_img_typ\":\"imageAndVideo\",\"exp\":[\"msNtpExp18\",\"msQuickLinksDefaultOneRow\",\"msShoppingWebAssistOnNtp\",\"msShoppingHistogramsOnNtp\",\"msEnableWinHPNewTabBackButtonFocusAndClose\",\"msCustomMaxQuickLinks\",\"msMaxQuickLinksAt20\",\"msAllowThemeInstallationFromChromeStore\",\"msEdgeSplitWindowLinkMode\",\"msUndersideAutoOpenForMsnTopQuestion\"],\"feed_dis\":\"peek\",\"layout\":2,\"quick_links_opt\":0,\""
		"seen_new_dev_fre\":false,\"sel_feed_piv\":\"myFeed\",\"show_greet\":true,\"tscollapsed\":0,\"vp\":{\"height\":429,\"width\":910},\"vt_opened\":false}");

	web_url("config_2", 
		"URL=https://ntp.msn.com/resolver/api/resolve/v3/config/?expType=AppConfig&expInstance=default&apptype=edgeChromium&v=20240412.461&targetScope={%22audienceMode%22:%22adult%22,%22browser%22:{%22browserType%22:%22edgeChromium%22,%22version%22:%22123%22,%22ismobile%22:%22false%22},%22deviceFormFactor%22:%22desktop%22,%22domain%22:%22ntp.msn.com%22,%22locale%22:{%22content%22:{%22language%22:%22en%22,%22market%22:%22xl%22},%22display%22:{%22language%22:%22en%22,%22market%22:%22xl%22}},%22os%22"
		":%22windows%22,%22platform%22:%22web%22,%22pageType%22:%22dhp%22,%22pageExperiments%22:[%22prg-1s-header%22,%22prg-1s-sm-workid%22,%22prg-1s-sptunirev%22,%22prg-1s-twid%22,%22prg-1s-workid%22,%22prg-1s-wpocfp1%22,%22prg-1sw-artgol%22,%22prg-1sw-clari%22,%22prg-1sw-deferpc%22,%22prg-1sw-dftloc-c%22,%22prg-1sw-fieplc%22,%22prg-1sw-finplsp2%22,%22prg-1sw-finvldc%22,%22prg-1sw-iconmap%22,%22prg-1sw-iplsd-ntp%22,%22prg-1sw-iplsdc-ntp%22,%22prg-1sw-iplsdc1p2%22,%22prg-1sw-iplsdp1%22,"
		"%22prg-1sw-iplsdp2%22,%22prg-1sw-lgen%22,%22prg-1sw-mtr-en-c%22,%22prg-1sw-pde0%22,%22prg-1sw-pr2clarity%22,%22prg-1sw-pro2pre-c%22,%22prg-1sw-profile%22,%22prg-1sw-profilecard%22,%22prg-1sw-profilesma%22,%22prg-1sw-rr2fn%22,%22prg-1sw-rr2fp%22,%22prg-1sw-sacfcliffv3at1%22,%22prg-1sw-srdus%22,%22prg-1sw-tbr11combtup%22,%22prg-1sw-tbr11meterub%22,%22prg-1sw-ucsap%22,%22prg-1sw-wxevolnoti%22,%22prg-1sw-wxhurac-c%22,%22prg-1sw-wxmptreplace%22,%22prg-ad-abd%22,%22prg-ad-article-hc%22,"
		"%22prg-ad-pdedupe-c%22,%22prg-ad-safe%22,%22prg-adspeek%22,%22prg-boost-ntpb-ww%22,%22prg-boost-ntpcm-ww%22,%22prg-boost-winhp%22,%22prg-boost-winhp-ww%22,%22prg-boostcmb-ww%22,%22prg-c-arb-rsz%22,%22prg-cf-wc%22,%22prg-cg-ad-ref-if-2%22,%22prg-cg-ad-sky%22,%22prg-cg-hb%22,%22prg-cg-search%22,%22prg-cg-seclarity%22,%22prg-chpg-ldgw%22,%22prg-chpg-tpft%22,%22prg-edg-tm500%22,%22prg-edg-tmtrig%22,%22prg-ent-prentp%22,%22prg-entpremier-ntp-t%22,%22prg-f3-video%22,%22prg-fin-cdicon%22,"
		"%22prg-fin-cnosign%22,%22prg-fin-errde%22,%22prg-fin-fret1c%22,%22prg-fin-l2nav22%22,%22prg-hd-suggest%22,%22prg-mscl-hld%22,%22prg-msclck-rf%22,%22prg-mvp-bingdflog%22,%22prg-mvp-prodcurpos%22,%22prg-mvp-sitedest%22,%22prg-nav-pros%22,%22prg-ncm%22,%22prg-ntp-earlyfeedssr%22,%22prg-ntp-rfwv-t%22,%22prg-p2-dsbrf%22,%22prg-p2-tsk-cmsev%22,%22prg-peek-ratio-30%22,%22prg-pr1-evolvelifecycle%22,%22prg-pr2-flashrev%22,%22prg-pr2-getpinnedwd%22,%22prg-pr2-pagecontext%22,%22prg-pr2-pulsev2%22,"
		"%22prg-pr2-pulsev2r%22,%22prg-pr2-rmplchdr-t2%22,%22prg-pr2-shoreline%22,%22prg-pr2-sidebar%22,%22prg-pr2-sidebar-t%22,%22prg-pr2-tfpls%22,%22prg-premier-ntp-rc1%22,%22prg-premier-pr1-c%22,%22prg-remflttel%22,%22prg-river-infod2%22,%22prg-river-infodl%22,%22prg-rpt2%22,%22prg-sh-bd-disgb%22,%22prg-sh-bd-newbanner%22,%22prg-sh-bd-newchckot%22,%22prg-sh-bd-nwchk%22,%22prg-sh-bd-pagoff%22,%22prg-sh-bd-video%22,%22prg-sh-bd-xtracash%22,%22prg-sh-recopdp%22,%22prg-sh-rmitmlnk%22,%22prg-sh-usecshk%22,"
		"%22prg-sh-usecshkpdp%22,%22prg-shop-staginc%22,%22prg-shopping-treat%22,%22prg-sp-liveapi%22,%22prg-sv1plus-stag%22,%22prg-tat-msntrvl-c%22,%22prg-titlemapping-1%22,%22prg-titlemapping-a%22,%22prg-tps-sort%22,%22prg-traffic-staginc%22,%22prg-ugc-likechange%22,%22prg-upsaip-r-t%22,%22prg-upsaip-w1-t%22,%22prg-vidbuf1%22,%22prg-wg-directly-jump%22,%22prg-wpo-boostbanner%22,%22prg-wpo-boostcoach%22,%22prg-wtch-inarad-t3%22,%22prg-wx-ncar%22,%22prg-wx-reactads%22]}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/edge/ntp?locale=ru&title=%D0%9D%D0%BE%D0%B2%D0%B0%D1%8F%20%D0%B2%D0%BA%D0%BB%D0%B0%D0%B4%D0%BA%D0%B0&dsp=0&sp=%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81&startpage=1&PC=U531&prerender=1", 
		"Snapshot=t42.inf", 
		"Mode=HTTP", 
		LAST);

	web_revert_auto_header("Sec-MS-GEC-Version");

	web_revert_auto_header("X-Client-Data");

	web_revert_auto_header("X-Edge-Shopping-Flag");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("login.pl_2", 
		"URL=http://localhost:1080/cgi-bin/login.pl?intro=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/login.pl", 
		"Snapshot=t43.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	lr_think_time(19);

	web_url("flights.gif", 
		"URL=http://localhost:1080/WebTours/images/flights.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t44.inf", 
		LAST);

	web_url("itinerary.gif", 
		"URL=http://localhost:1080/WebTours/images/itinerary.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t45.inf", 
		LAST);

	lr_think_time(4);

	web_url("in_home.gif", 
		"URL=http://localhost:1080/WebTours/images/in_home.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t46.inf", 
		LAST);

	web_url("signoff.gif", 
		"URL=http://localhost:1080/WebTours/images/signoff.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t47.inf", 
		LAST);

	web_add_cookie("MC1=GUID=5079aa0dd85f41e69cda66e2bd3fd648&HASH=5079&LV=202402&V=4&LU=1706808086327; DOMAIN=prod-westeurope.access-point.cloudmessaging.edge.microsoft.com");

	web_add_cookie("Imported_MUID=39FEA931D3406BD01315BD78D25D6A20; DOMAIN=prod-westeurope.access-point.cloudmessaging.edge.microsoft.com");

	web_add_cookie("MSCC=NR; DOMAIN=prod-westeurope.access-point.cloudmessaging.edge.microsoft.com");

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("X-AFS-ClientInfo", 
		"platform=Windows; os=Windows NT; osVer=10.0.22621; app=Microsoft Edge; appVer=123.0.2420.81; appChannel=stable; ecmVer=2.0");

	web_add_header("X-Client-ID", 
		"xoA3wCAk+KGKcH9sFEoxyQ==");

	web_add_header("X-Has-Multiple-Syncing-Devices", 
		"0");

	web_websocket_connect("ID=0", 
		"URI=wss://prod-westeurope.access-point.cloudmessaging.edge.microsoft.com/", 
		"Origin=wss://prod-westeurope.access-point.cloudmessaging.edge.microsoft.com", 
		"OnOpenCB=OnOpenCB0", 
		"OnMessageCB=OnMessageCB0", 
		"OnErrorCB=OnErrorCB0", 
		"OnCloseCB=OnCloseCB0", 
		LAST);

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Sec-Fetch-Site", 
		"same-site");

	web_add_header("Sec-MS-GEC", 
		"ACC91C13C13940C5F92958826644C2D97BB012E5DE823C4011CFEE6F74688AAB");

	web_add_header("Sec-MS-GEC-Version", 
		"1-123.0.2420.81");

	web_add_header("X-Client-Data", 
		"eyIxIjoiMSIsIjEwIjoiXCJhazdIY1FwbmxabjhtOWFUeVJSK1RCbERzK051MGVBUHlQUEpsaEJnMy9nPVwiIiwiMiI6IjEiLCIzIjoiMCIsIjQiOiIzMzM3Mjg3NjA0ODc3Mjk4NjU3IiwiNSI6IlwiQ2t1QW1sUHhIejJDUmFJbkJWNmlhbTVVMmRSazdsREV6Z3RiK0I5TlVUOD1cIiIsIjYiOiJzdGFibGUiLCI3IjoiMjA0MDEwOTQ2NTYwMiIsIjkiOiJkZXNrdG9wIn0=");

	web_add_header("X-Edge-Shopping-Flag", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("20240412.461.json", 
		"URL=https://assets.msn.com/periconfigs/feature-manifests/edgechromium/20240412.461.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t49.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_custom_request("report_3", 
		"URL=https://deff.nelreports.net/api/report", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t50.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Sec-Fetch-Site", 
		"same-site");

	web_add_header("Sec-MS-GEC", 
		"ACC91C13C13940C5F92958826644C2D97BB012E5DE823C4011CFEE6F74688AAB");

	web_add_header("Sec-MS-GEC-Version", 
		"1-123.0.2420.81");

	web_add_header("X-Client-Data", 
		"eyIxIjoiMSIsIjEwIjoiXCJhazdIY1FwbmxabjhtOWFUeVJSK1RCbERzK051MGVBUHlQUEpsaEJnMy9nPVwiIiwiMiI6IjEiLCIzIjoiMCIsIjQiOiIzMzM3Mjg3NjA0ODc3Mjk4NjU3IiwiNSI6IlwiQ2t1QW1sUHhIejJDUmFJbkJWNmlhbTVVMmRSazdsREV6Z3RiK0I5TlVUOD1cIiIsIjYiOiJzdGFibGUiLCI3IjoiMjA0MDEwOTQ2NTYwMiIsIjkiOiJkZXNrdG9wIn0=");

	web_add_header("X-Edge-Shopping-Flag", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(4);

	web_url("20240412.461.json_2", 
		"URL=https://assets.msn.com/periconfigs/loc-manifests/edgechromium/20240412.461.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t51.inf", 
		"Mode=HTTP", 
		LAST);

	web_revert_auto_header("Origin");

	web_custom_request("report_4", 
		"URL=https://deff.nelreports.net/api/report", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t52.inf", 
		"Mode=HTTP", 
		"EncType=application/reports+json", 
		"Body=[{\"age\":36403,\"body\":{\"blockedURL\":\"trusted-types-sink\",\"columnNumber\":87196,\"disposition\":\"report\",\"documentURL\":\"https://ntp.msn.com/edge/ntp?locale=ru&title=%D0%9D%D0%BE%D0%B2%D0%B0%D1%8F%20%D0%B2%D0%BA%D0%BB%D0%B0%D0%B4%D0%BA%D0%B0&dsp=0&sp=%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81&startpage=1&PC=U531&prerender=1\",\"effectiveDirective\":\"require-trusted-types-for\",\"lineNumber\":7,\"originalPolicy\":\"child-src 'self';connect-src 'self' *.mavideo.microsoft.com arc.msn.com "
		"assets.msn.com assets2.msn.com assets.msn.cn assets2.msn.cn browser.events.data.msn.com browser.events.data.msn.cn browser.events.data.microsoftstart.com browser.events.data.microsoftstart.cn business.bing.com/api/ usgov.business.bing.com/api/ cdn.hubblecontent.osi.office.net events-sandbox.data.msn.com events-sandbox.data.msn.cn events-sandbox.data.microsoftstart.com events-sandbox.data.microsoftstart.cn finance-services.msn.com https://*.sharepoint.com/_api/v2.0/ https://*.sharepoint-df.com/_api"
		"/v2.0/ https://*.sharepoint.com/_api/v2.1/ https://*.sharepoint-df.com/_api/v2.1/ https://bingretailmsndata.azureedge.net/msndata/ https://browser.pipe.aria.microsoft.com/Collector/ https://dev.virtualearth.net/REST/v1/Imagery/ https://ecn.dev.virtualearth.net https://jsconfig.adsafeprotected.com https://g.bing.com https://msx.bing.com https://petrol.office.microsoft.com/v1/feedback https://privacyportal.onetrust.com/request/v1/consentreceipts https://sapphire.api.microsoftapp.net https://"
		"services.bingapis.com https://substrate.office.com/PeoplePredictionsB2/StreamsPreview https://substrate.office.com/PeoplePredictionsB2/StreamsPreviewById https://substrate.office.com/autodiscover/ https://trafficanswer.trafficmanager.net https://*.clarity.ms https://edge.microsoft.com/edgedeeplearning/ img-s-msn-com.akamaized.net login.microsoftonline.com notification.services.msn.com ocws.officeapps.live.com/ocs/ ocws-eu.officeapps.live.com/ocs/ odc.officeapps.live.com/odc/ "
		"prod-video-cms-amp-microsoft-com.akamaized.net r.bing.com/rp/rms_pr.png raka.bing.com/rp/rms_pr.png ris.api.iris.microsoft.com srtb.msn.com srtb.msn.cn srtb-pulsar.msn.com substrate.office.com/FocusedInboxB2/api/v1/ substrate.office.com/PeoplePredictionsB2/graphql substrate.office.com/PeoplePredictionsB2/MeTaPreview substrate.office.com/PeoplePredictionsB2/SPImageProxied substrate.office.com/PeoplePredictionsB2/SpPreview substrate.office.com/api/beta/me/WorkingSetFiles substrate.office.com/api/"
		"beta/me/officegraphinsights/trending substrate.office.com/recommended/api/beta/edgeworth/ substrate.office.com/api/v2.0/ substrate.office.com/peoplepredictionsb2/feedback substrate.office.com/peoplepredictionsb2/microsoftfeed substrate.office.com/recommended/api/v1.0/files substrate.office.com/search/api/v1/ substrate.office.com/todo/api/v1/ substrate.office.com/todob2/api/v1/ webshell.suite.office.com/api/shell/newtab wss://www.bing.com/opaluqu/speech/recognition/interactive/cognitiveservices/ "
		"wss://sr.bing.com/opaluqu/speech/recognition/interactive/cognitiveservices/ www.bing.com/fd/ls/ls.gif www.msn.com www.msn.cn www.microsoftstart.com cn.bing.com/api/ cn.bing.com/bnc/ cn.bing.com/pnp/ cn.bing.com/profile/interestmanager/update *.cn.mm.bing.net *.mm.cn.bing.net www.bing.com/HPImageArchive.aspx www.bing.com/api/custom/opal/reco/ www.bing.com/DSB cn.bing.com/DSB www.bing.com/DSB/partner/ cn.bing.com/DSB/partner/ www.bing.com/api/ www.bing.com/as/ www.bing.com/AS/Suggestions "
		"www.bing.com/AS/Suggestions/v2 www.bing.com/bnc/ www.bing.com/crop/warmer.png www.bing.com/historyHandler www.bing.com/images/sbidlg www.bing.com/pnp/ www.bing.com/profile/history/data www.bing.com/profile/interestmanager/update www.bing.com/retail/msn/api/shopcard www.bing.com/retailexp/msn/api/ www.bing.com/retailexpdata/msndata/ www.bing.com/rp/rms_pr.png www.bing.com/th wus-streaming-video-msn-com.akamaized.net prod-streaming-video-msn-com.akamaized.net prod-streaming-video.msn.cn "
		"zerocodecms.blob.core.windows.net *.oneservice.msn.com *.oneservice.msn.cn api.msn.com api.msn.cn ent-api.msn.com ent-api.msn.cn ppe-api.msn.com ppe-api.msn.cn graph.microsoft.com/beta/ graph.microsoft.com/v1.0/ https://*.vo.msecnd.net https://user.auth.xboxlive.com/user/authenticate https://xsts.auth.xboxlive.com/xsts/authorize https://titlehub.xboxlive.com/users/ https://t.ssl.ak.dynamic.tiles.virtualearth.net https://dynamic.t0.tiles.ditu.live.com https://dev.virtualearth.net/REST/v1/Routes/ "
		"https://dev.ditu.live.com/REST/v1/Routes/ https://dev.virtualearth.net/REST/v1/Locations/ https://dev.ditu.live.com/REST/v1/Locations/ browser.events.data.microsoft.com;default-src 'none';font-src 'self' data: assets.msn.com assets2.msn.com assets.msn.cn assets2.msn.cn;frame-src https://api.msn.com/auth/cookie/silentpassport https://api.msn.cn/auth/cookie/silentpassport https://www.msn.com https://www.msn.cn https://www.microsoftstart.com login.live.com login.microsoftonline.com www.bing.com/covid"
		" www.bing.com/rewardsapp/flyout www.bing.com/shop www.bing.com/shop/halloween www.bing.com/videos/search www.facebook.com www.odwebp.svc.ms www.youtube.com msn.pluto.tv www.bing.com/wpt/prefetchcib https://res.cdn.office.net/ business.bing.com sip: mailto: edge-auth.microsoft.com;img-src https://* blob: chrome-search://ntpicon/ chrome-search://local-ntp/ chrome-search://theme/ data:;media-src 'self' blob: *.mavideo.microsoft.com assets.msn.com assets2.msn.com assets.msn.cn assets2.msn.cn https://"
		"sapphire.azureedge.net th.bing.com/th wus-streaming-video-msn-com.akamaized.net prod-streaming-video-msn-com.akamaized.net prod-streaming-video.msn.cn liveshopping.azureedge.net;report-to csp-endpoint;style-src 'self' 'unsafe-inline' c.s-microsoft.com/mscc/ assets.msn.com assets2.msn.com assets.msn.cn assets2.msn.cn;worker-src 'self' blob: 'report-sample';require-trusted-types-for 'script';trusted-types serviceWorkerUrlPolicy baw-trustedtypes-policy svgPassThroughPolicy xmlPassThroughPolicy "
		"webpackTrustedTypesPolicy webWorkerUrlPolicy inlineHeadCssPassthroughPolicy bundleUrlPolicy fallbackBundleUrlPolicy scriptSrcUrlPolicy dompurify fast-html base-html-policy 'allow-duplicates';script-src 'nonce-2qvfKGG1LW7BrNTI3Ph7uiJvgvi6Thb9GKn26NXNMl4=' 'strict-dynamic'\",\"referrer\":\"\",\"sample\":\"HTMLScriptElement src|https://assets.msn.com/staticsb/statics/\",\"sourceFile\":\"https://assets.msn.com/staticsb/statics/latest/oneTrust/1.9/scripttemplates/202310.2.0/otBannerSdk.js\",\""
		"statusCode\":200},\"type\":\"csp-violation\",\"url\":\"https://ntp.msn.com/edge/ntp?locale=ru&title=%D0%9D%D0%BE%D0%B2%D0%B0%D1%8F%20%D0%B2%D0%BA%D0%BB%D0%B0%D0%B4%D0%BA%D0%B0&dsp=0&sp=%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81&startpage=1&PC=U531&prerender=1\",\"user_agent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0\"}]", 
		LAST);

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_add_auto_header("Sec-MS-GEC", 
		"ACC91C13C13940C5F92958826644C2D97BB012E5DE823C4011CFEE6F74688AAB");

	web_add_auto_header("Sec-MS-GEC-Version", 
		"1-123.0.2420.81");

	web_add_auto_header("X-Client-Data", 
		"eyIxIjoiMSIsIjEwIjoiXCJhazdIY1FwbmxabjhtOWFUeVJSK1RCbERzK051MGVBUHlQUEpsaEJnMy9nPVwiIiwiMiI6IjEiLCIzIjoiMCIsIjQiOiIzMzM3Mjg3NjA0ODc3Mjk4NjU3IiwiNSI6IlwiQ2t1QW1sUHhIejJDUmFJbkJWNmlhbTVVMmRSazdsREV6Z3RiK0I5TlVUOD1cIiIsIjYiOiJzdGFibGUiLCI3IjoiMjA0MDEwOTQ2NTYwMiIsIjkiOiJkZXNrdG9wIn0=");

	web_add_auto_header("X-Edge-Shopping-Flag", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("c2976549e0778d3cecf62fe9e4735eed.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/index.json/c2976549e0778d3cecf62fe9e4735eed.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t53.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("b7fd6413fc7b29b7edbc1da46bdc606e.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/edgechromiumpagewc/default/index.json/b7fd6413fc7b29b7edbc1da46bdc606e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t54.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("377b22ba609e471d26e80ea6b59411aa.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config.json/377b22ba609e471d26e80ea6b59411aa.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t55.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("b81a4920890a57c52342e3f44f9736a7.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config_en.json/b81a4920890a57c52342e3f44f9736a7.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t56.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("c35ec890b417bfe7d7987a8b0a847804.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config_adult.json/c35ec890b417bfe7d7987a8b0a847804.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t57.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("fdbac5e861118368f5410b859edb51bb.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config_en-xl_adult_windows.json/fdbac5e861118368f5410b859edb51bb.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t58.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("74c1904b8c027abe4940f4d2615bf026.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config_prg-ad-safe.json/74c1904b8c027abe4940f4d2615bf026.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t59.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("4f0ba597b16d8ebae046bc4014e935a4.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config_prg-ncm.json/4f0ba597b16d8ebae046bc4014e935a4.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t60.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("90cb22abb8d534cc0939c3a68ace1702.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config_prg-ntp-earlyfeedssr.json/90cb22abb8d534cc0939c3a68ace1702.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t61.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("1fa0b3a066db5d71a360cd62107be8d6.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/edgechromiumpagewc/default/config_en.json/1fa0b3a066db5d71a360cd62107be8d6.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t62.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("00dcf92cd515755bb4be9156af5416ac.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/edgechromiumpagewc/default/config_prg-peek-ratio-30.json/00dcf92cd515755bb4be9156af5416ac.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t63.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("a53671d29802db0e9724c8bf7547adaa.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/chromiumpagesettings/default/index.json/a53671d29802db0e9724c8bf7547adaa.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t64.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("b8ddb9acdf272ee001af15810bad2427.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/chromiumpagesettings/default/config.json/b8ddb9acdf272ee001af15810bad2427.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t65.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("OptanonConsent=isGpcEnabled=0&datestamp=Sun+Apr+14+2024+13%3A20%3A52+GMT%2B0300+(%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0%2C+%D1%81%D1%82%D0%B0%D0%BD%D0%B4%D0%B0%D1%80%D1%82%D0%BD%D0%BE%D0%B5+%D0%B2%D1%80%D0%B5%D0%BC%D1%8F)&version=202310.2.0&isIABGlobal=false&hosts=&landingPath=NotLandingPage&groups=C0001%3A1%2CC0002%3A0%2CC0003%3A0%2CC0004%3A0%2CV2STACK42%3A0&AwaitingReconsent=false&browserGpcFlag=0; DOMAIN=ntp.msn.com");

	web_revert_auto_header("Origin");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Dest", 
		"serviceworker");

	web_add_header("Service-Worker", 
		"script");

	web_add_header("sec-edge-ntp", 
		"{\"back_block\":0,\"bg_cur\":{\"configIndex\":4,\"provider\":\"Video\"},\"bg_img_typ\":\"imageAndVideo\",\"exp\":[\"msNtpExp18\",\"msQuickLinksDefaultOneRow\",\"msShoppingWebAssistOnNtp\",\"msShoppingHistogramsOnNtp\",\"msEnableWinHPNewTabBackButtonFocusAndClose\",\"msCustomMaxQuickLinks\",\"msMaxQuickLinksAt20\",\"msAllowThemeInstallationFromChromeStore\",\"msEdgeSplitWindowLinkMode\",\"msUndersideAutoOpenForMsnTopQuestion\"],\"feed_dis\":\"peek\",\"layout\":2,\"quick_links_opt\":0,\""
		"seen_new_dev_fre\":false,\"sel_feed_piv\":\"myFeed\",\"show_greet\":true,\"tscollapsed\":0,\"vp\":{\"height\":429,\"width\":910},\"vt_opened\":false}");

	web_url("service-worker.js", 
		"URL=https://ntp.msn.com/edge/ntp/service-worker.js?bundles=latest&riverAgeMinutes=2880&enableNetworkFirst=true&navAgeMinutes=2880&enableNavPreload=true&enableEmptySectionRoute=true&enableFallbackVerticalsFeed=true&networkTimeoutSeconds=5", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://ntp.msn.com/edge/ntp/service-worker.js?bundles=latest&riverAgeMinutes=2880&enableNetworkFirst=true&navAgeMinutes=2880&enableNavPreload=true&enableEmptySectionRoute=true&enableFallbackVerticalsFeed=true&networkTimeoutSeconds=5", 
		"Snapshot=t66.inf", 
		LAST);

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_add_auto_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("3b17ec8179e39e4db449a5bb9524c5e4.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/experiencetrackeredgenextdata/default/index.json/3b17ec8179e39e4db449a5bb9524c5e4.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t67.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("6840e154100216e23cddf9f28cf93c10.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/experiencetrackeredgenextdata/default/config.json/6840e154100216e23cddf9f28cf93c10.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t68.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("f4484a52f96293af07702b096389c42f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/appconfig/default/index.json/f4484a52f96293af07702b096389c42f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t69.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("e775828d82978d77d8a66f407cbe63a8.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/appconfig/default/config.json/e775828d82978d77d8a66f407cbe63a8.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t70.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("3b178c67f28066d38c6b505be61f499a.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/telemetrydataedgechromium/default/index.json/3b178c67f28066d38c6b505be61f499a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t71.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("ae312c156b9f8361fc0b5d46204b924f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/telemetrydata/default/index.json/ae312c156b9f8361fc0b5d46204b924f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t72.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("0ba4590a841ba960259ff23aa6c48357.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/smartlistshareddata/default/index.json/0ba4590a841ba960259ff23aa6c48357.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t73.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("bfa1837e21b67d5bb6a56ed08491515b.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/irisdata/default/index.json/bfa1837e21b67d5bb6a56ed08491515b.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t74.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("78fa9f6b79504824d47807c4c8922914.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/backgrounddata/default/index.json/78fa9f6b79504824d47807c4c8922914.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t75.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("e28f3538f030c58a157e6a822b7eb69a.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topicdata/default/index.json/e28f3538f030c58a157e6a822b7eb69a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t76.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("685a818462b0a40ca38c3a876390e679.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/channeldata/default/index.json/685a818462b0a40ca38c3a876390e679.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t77.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("c1b8026bc72975b3e4ce399943126864.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/nurturingplacementmanager/default/index.json/c1b8026bc72975b3e4ce399943126864.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t78.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("96f798cc3620accf9dd987a2ef794581.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/nurturingplacementmanager/default/index.json/96f798cc3620accf9dd987a2ef794581.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t79.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/telemetrydata/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t80.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_2", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/telemetrydataedgechromium/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t81.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_3", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/smartlistshareddata/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t82.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("35ac53cc8aa7f1fabedacb50108564d2.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/irisdata/default/config.json/35ac53cc8aa7f1fabedacb50108564d2.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t83.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("1b075e61ef08da5a4d1ac297e737afe1.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/irisdata/default/config_adult.json/1b075e61ef08da5a4d1ac297e737afe1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t84.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("4536fedaade4daafeffeea668906a7cf.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/backgrounddata/default/config.json/4536fedaade4daafeffeea668906a7cf.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t85.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_4", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topicdata/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t86.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("7a7d29717431639b25db3fdc872aee9c.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/channeldata/default/config.json/7a7d29717431639b25db3fdc872aee9c.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t87.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("373c04ee1b876439e67eab247f315e20.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/nurturingplacementmanager/default/config.json/373c04ee1b876439e67eab247f315e20.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t88.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("401fb455395d704914fedfc4f0e3d8d2.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/nurturingplacementmanager/default/config_en.json/401fb455395d704914fedfc4f0e3d8d2.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t89.inf", 
		"Mode=HTTP", 
		LAST);

	lr_think_time(5);

	web_url("75ed558f5c473a49eea530fd4e6680f5.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/gridviewfeed/default/index.json/75ed558f5c473a49eea530fd4e6680f5.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t90.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("1456c759bae2323aefe91bd8b1c13923.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/gridviewfeed/default/index.json/1456c759bae2323aefe91bd8b1c13923.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t91.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("7448c0439095f7242faaa13ee2e8e5ba.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/commonsearchboxedgenext/default/index.json/7448c0439095f7242faaa13ee2e8e5ba.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t92.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("5ff0790ccd1ceb24eb9e6789745e535f.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/commonsearchboxedgenext/default/index.json/5ff0790ccd1ceb24eb9e6789745e535f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t93.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("ba9639ddfffff387d76079e62e42fed1.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/stickypeek/default/index.json/ba9639ddfffff387d76079e62e42fed1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t94.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("d600ccbc4e5495b5429a56b9beec271b.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/stickypeek/default/index.json/d600ccbc4e5495b5429a56b9beec271b.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t95.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("6d4a940fa08780b6ba8baaf92ad1dbd6.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/supernav/default/index.json/6d4a940fa08780b6ba8baaf92ad1dbd6.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t96.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("a00173d193331fc0ea16b802ad52a9c8.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/supernav/default/index.json/a00173d193331fc0ea16b802ad52a9c8.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t97.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("68e590f2bbecf21f6d8646c46b3808aa.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shoppingnotification/default/index.json/68e590f2bbecf21f6d8646c46b3808aa.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t98.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("88ccd04559b17b93c732de32a7f17739.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/shoppingnotification/default/index.json/88ccd04559b17b93c732de32a7f17739.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t99.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("b4fc870085bd8bb7fc97d3df197b1cca.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/scrolldownbutton/default/index.json/b4fc870085bd8bb7fc97d3df197b1cca.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t100.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("3ef15953cd9ad3093dc402faef06fc29.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/scrolldownbutton/default/index.json/3ef15953cd9ad3093dc402faef06fc29.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t101.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("7a8b542bdffc40096fcf0cba41622546.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/floatbuttongroupwc/default/index.json/7a8b542bdffc40096fcf0cba41622546.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t102.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("51662eeb5a0e9195e5014861f46911ae.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/floatbuttongroupwc/default/index.json/51662eeb5a0e9195e5014861f46911ae.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t103.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("7d0e768c3fb51ab6a1fa846167ad2ddc.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/channelstore/default/index.json/7d0e768c3fb51ab6a1fa846167ad2ddc.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t104.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("2c5b593b541c2a48d9576204e16f2cf0.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/channelstore/default/index.json/2c5b593b541c2a48d9576204e16f2cf0.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t105.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("85fdc4c8420c087bb5bd1a8e64621157.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/gridviewfeed/default/config.json/85fdc4c8420c087bb5bd1a8e64621157.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t106.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("506177f89e55070b45f5b7b6cb9c3c9a.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/gridviewfeed/default/config_en-xl.json/506177f89e55070b45f5b7b6cb9c3c9a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t107.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("_EDGE_V=1; DOMAIN=arc.msn.com");

	web_add_cookie("APP_ANON=A=022CDA96091158A16CEFA276FFFFFFFF; DOMAIN=arc.msn.com");

	web_add_cookie("aace=%7b%22child%22%3a0%7d; DOMAIN=arc.msn.com");

	web_add_cookie("els=%7b%22account_type%22%3a%22MSA%22%7d; DOMAIN=arc.msn.com");

	web_add_cookie("MUID=047FE09A36C068D9071EF357375969CA; DOMAIN=arc.msn.com");

	web_add_cookie("USRLOC=BID=MjQwNDE0MTMxNzE0XzZiZGZjZmRkMTIxZDcxNDFhNzNhM2VmNTU5ZGVkY2Q3MGM4MDBjZmM1N2QxN2U1ZTdmMTQ2MWFlNzMwNThmNmE=; DOMAIN=arc.msn.com");

	web_add_cookie("lt=t=EwBIA6AEAAAU+FEkrYVKODxcga16pzW/y5vRf68AAaEM9XfPeavWIEfjjeKT7MHf55yNQHnDUg6MpIlhw2plF73ZgHIwtNZTTYPnD4cZHv1KuepFlIpFsDeEpufd/pNP2eo6Gh+hygT4KtnV4ywbcdobOUl6PNsI0bu78vYCRTUSqeUA6SDAmjK0GkeyjA6HW+LkOwQMQ5GG3e5psIzWmK6UjCrG6EbU3QihaKHHTRtqGR2ArY1YPxfo9WsiVmDd7mVxMvwUISKj9X9k3rSJ368ZJv3OH/7/UerCCAjFs6E5sT6rXYLAzzX+oPuyLzEQca2DKA3f2RYRWalPHV49F7DgSiiYmW5PaAV5FO6M4v/Jq3gOw5zROt6bXoomqawDZgAACDETXrUahmW2GAKO0pl+"
		"D4iDZCAR5kTxJCJZ2WLafqOXFRPbPLGIGaq8snNpZL3EVIgPzxHP1WPHOtK3M3BmGWwUpi2zBAtK1fQPWiy0WRp9YlHgCBRZI6wEZHl6lMyuX5v/yrOD7iOjCyBC9s6zj8JxOXx8nLXT/dh3UiStmD3ioSW35hOAL+bjcmOtWWG+cIBrab+UjZeyMt3ktO4dT61R0r/BgjulDhAjF4CZKKObVpLXo54iavDo0iP6vsne58h+WnktlAuuiDCN523SoRSwmn80wL2rh66I0MhhNAKQ2sVjzaNF7pD4cQtyuuOLpQs0x3NxzxAHF8pV7AAMWicxbgMTo5uZ9HdKC67yPreh+cTIYTlBqEfrNedw5aVZF/CdFtcrI5CSzOAgcgPxNlg9ZlfXNhjEUXgvRoedm7DjFhlB1JX+VDFbeXnqss3UUjKSgMUohdq2xKl672Yn5MEd1GZXpSOgR0RaG35OrMYj1vlqr125TPs9EMdrT955/Qn/I6ocQW"
		"+BibGMJELQMH+iTMlAI5soraB7GdTdMlrh4SmW0C+vlJVpR5ZPUikPfi/ILlsVukmBlPbd9biYN2VFq0xyGYiYE4JWcJIAw7sk/VGXIX5rCrLbPDbHbUX2iTip4QY34vZCc1yfsNIhzbYxqm2Q39prmdwpezBmNkGWSQ0uERGRNM+aFOZy+HmORImkrBASs2tAo1CY2y1nKyx6YE8C&p=; DOMAIN=arc.msn.com");

	web_add_cookie("ANON=A=022CDA96091158A16CEFA276FFFFFFFF&E=1d24&W=1; DOMAIN=arc.msn.com");

	web_add_cookie("elt="
		"%7B%22access_token%22%3A%22eyJhbGciOiJSU0EtT0FFUCIsImVuYyI6IkExMjhDQkMtSFMyNTYiLCJ4NXQiOiJEZTRNSWJTY1ExeTdMYlBGSVR3emNMRmxrcFkiLCJ6aXAiOiJERUYifQ.SxRT7SBHXq6ai_uMHI-Rzyb6EHFk7jkDeT6Pb4YSD_I_cU5Br_eA_sysCQNT11RCVM1BCfrB2NwK8BU2xaGlRh2XqKKwwmEMo3je8zL2qLLbd1zyfyRZ-nUu-Ks-ulvEphP8LaxQK6Q5WWFFlAC3Le_7PDr2jm76KDcEWL31Q3vlLY-kD-SjUsEHZZNoK0hj6H005f-ubR_mr92caA9gnUL6-C5Y8N1-KTCAgm39S9L4f22PuRJZJ3jo3B-pWlnrlFLdn-wGR_R50D8EcJlB-pnVCnW8I8ntNkmAcXTGUWm812uMI8sbqHYe0_JmcOOoALIf2rEVcJZy4t7R6dvgFw.CnB833luCepxu"
		"FGnVeXD7w.SBrUl8g2BP9N95ZCZR8-rdLKT8UHycGqU8wsuWhTqkOVxYDJtz5p6xvcb0KyUd2JrQ6r_tBDQ2p6HQJ4jVjq1HI4oo2yStITYyFwp5AZu4nu5ApMxk-5hdvbY8zbbZpjkuME7Bq1LSu9ISWwRBIQhwjpjlQq9SViEQlXIO-kp5Ap0iDz5v2SQWj33OOxOGcqrlU1Ndh1yRc4SuSde4zZdxf7Nj6bzYZyIWnUR7aF1_SSGHigimBuFAi4sVnCbgB1GSG-k4vXHaXRUweBE5FHGw02YQKNbOco5G5K18EoYjVSEiVKwwtJsZdxBuTY3fm0mWXmbjjkUcrhwcrLXRYCYEtuYJgh7Z2IC0RxovKv-6IUyR9Wz9iD_MoOgbxzBV_7-ooIpvoMmsxQnCfjT_qvOiLE2pYH1cblK8v-yy2GOGe-1g6fNCWO2ybD3vIUChvfVmueKEPJ1_LrDJZv5MwbGOpRBALEl3HyGoBa9AJtRKY3"
		"PKn-9ppCKusni_iN7nO7cIi6sI4UxHVbSUyEBsto-Ap84ea9nFUW8vshCu1dc5Bs7j3j5kkgqqegNukrqu8ft7WaDK5h8s41O5UDO1MtM_nnTIcPfxRdfeFPFyjna43t3ZBR5Dl1xsjf3SyvwPwhHMq_VdedrcE8OeJgI51N5Nx6jKhV5T_M64z5YPY3AD9aR5J91y71e-sn3caqB6gMEtMxJksr2qW275fe92bSUhWro8zKibzStxmEzWBBZB26NoaTrjUBLcmYI_9pxEk8nsS3fOpS3ubZ4byKypkDQbPIb3yNH0ZXEHQb38N_83Swk7UJFBv6kj_fiQFAi8t2kpilT4cDbReYU5s_P2znwv1V_6uuN8kjIrTF-Ekb5PFB_NSr2afmbjY6yrl4IvGW5IHly3V72Wv57A7sanuyqNPJS-sWQs7WUhhxhXVZYhMKcDDAYwUiMwb7jxcB2HBTudPA2BrbOeblOdTdlEA01cUduKZFjw2kvU"
		"ciSs3F2INRUjPuuAl1Q3yQ-qxcskAxi8upyfcdH1loUTBirrxi8pxd4oN2ujsutxTQP6ShIkJpx2I9DetmeXj8OC_k717S0z12aAnbzaLDl957ZY1EINIqLGsWXUEVS6m05_vZ2sBmu9HafYtuBXGaen1t7I57EnX6vhTFJAFJWdevbzzhYz-duvNDwEqhAkOaLJODZqcJJlDf2i_RhR1q4wFi9ZrsjvXuY3OhK9nxXU3nKDfV4yvk1YrcJeFuZ1RvkN3qjguJ4U3_-uvuXRtJ4d8Le0ZyA0bU4VYAABxMvHvoKCU8jKoDch4LOZLT5aGPIsnSvtnyiwym-20eGLEN59i1q1XaKXa1YyXJLe-9hUPmS-Wb4_jnLO0DwyDOu44rHzo3OJ3t7ceYpnSV0PuY6TFxzeZpdQJVc54uQHvqImxSzro7zw.oaCcURkXMd0VRr2chosSfw%22%2C%22account_type%22%3A%22MSA%22%2C%22l"
		"ogin_hint%22%3A%22naominguema@mail.ru%22%2C%22e%22%3A%22d7410ae0%22%7D; DOMAIN=arc.msn.com");

	web_add_cookie("OptanonConsent=isGpcEnabled=0&datestamp=Sun+Apr+14+2024+13%3A20%3A52+GMT%2B0300+(%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0%2C+%D1%81%D1%82%D0%B0%D0%BD%D0%B4%D0%B0%D1%80%D1%82%D0%BD%D0%BE%D0%B5+%D0%B2%D1%80%D0%B5%D0%BC%D1%8F)&version=202310.2.0&isIABGlobal=false&hosts=&landingPath=NotLandingPage&groups=C0001%3A1%2CC0002%3A0%2CC0003%3A0%2CC0004%3A0%2CV2STACK42%3A0&AwaitingReconsent=false&browserGpcFlag=0; DOMAIN=arc.msn.com");

	web_revert_auto_header("X-Client-Data");

	web_url("selection", 
		"URL=https://arc.msn.com/v4/api/selection?nct=1&fmt=json&nocookie=0&locale=en-xl&country=GE&muid=047FE09A36C068D9071EF357375969CA&AREF=2&ACHANNEL=4&ABUILD=123.0.6312.106&clr=esdk&edgeid=3337287604877298657&ISU=0&ADEFAB=0&devosver=10.0.22621.3447&OPSYS=WIN10&poptin=1&UITHEME=light&pageConfig=41&ISSIGNEDIN=0&MSN_CANVAS=2&ISMOBILE=0&BROWSER=6&placement=88000308|10837393&bcnt=1|1&SCS_msNtpExp=msNtpExp18&asid=01590f17889947bdc8bd86c5a0b17968", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t108.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("X-Client-Data", 
		"eyIxIjoiMSIsIjEwIjoiXCJhazdIY1FwbmxabjhtOWFUeVJSK1RCbERzK051MGVBUHlQUEpsaEJnMy9nPVwiIiwiMiI6IjEiLCIzIjoiMCIsIjQiOiIzMzM3Mjg3NjA0ODc3Mjk4NjU3IiwiNSI6IlwiQ2t1QW1sUHhIejJDUmFJbkJWNmlhbTVVMmRSazdsREV6Z3RiK0I5TlVUOD1cIiIsIjYiOiJzdGFibGUiLCI3IjoiMjA0MDEwOTQ2NTYwMiIsIjkiOiJkZXNrdG9wIn0=");

	web_url("790fe756a6b5d8578dfa9aa92ccf5943.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/gridviewfeed/default/config_adult.json/790fe756a6b5d8578dfa9aa92ccf5943.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t109.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("f97582c4d622fa277ef319c2cc1098b9.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/gridviewfeed/default/config_en_adult.json/f97582c4d622fa277ef319c2cc1098b9.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t110.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("293a256421f6c038fcfcb160848fd98f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/gridviewfeed/default/config_prg-f3-video.json/293a256421f6c038fcfcb160848fd98f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t111.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("4cea803f5ea56fdf8fdb5604fba31b39.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/gridviewfeed/default/config_en.json/4cea803f5ea56fdf8fdb5604fba31b39.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t112.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("9cb8a7d561b1983ba139e4f359b496f8.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/commonsearchboxedgenext/default/config.json/9cb8a7d561b1983ba139e4f359b496f8.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t113.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("11aa1e6fdc9e57f5afc311217ad11f01.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/commonsearchboxedgenext/default/config_en.json/11aa1e6fdc9e57f5afc311217ad11f01.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t114.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("40917bb56fb4f3306932fdbfd5bf094e.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/stickypeek/default/config.json/40917bb56fb4f3306932fdbfd5bf094e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t115.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("6d8f319b78637fe819de833ce4cd34a9.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/stickypeek/default/config_en.json/6d8f319b78637fe819de833ce4cd34a9.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t116.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("e0966aed8001ef2af4fb715073516299.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/supernav/default/config.json/e0966aed8001ef2af4fb715073516299.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t117.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("0d649c8ac7b1a155b9fad6cfbb497c92.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/supernav/default/config_en-xl_desktop.json/0d649c8ac7b1a155b9fad6cfbb497c92.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t118.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("d582335611681a3a2626eac39fa0cd89.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/supernav/default/config_en-xl.json/d582335611681a3a2626eac39fa0cd89.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t119.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("a8cd5ffe0d9e8118b259f63ce3a23a14.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/supernav/default/config_en.json/a8cd5ffe0d9e8118b259f63ce3a23a14.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t120.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("95ee762be190b48ee040758227d2f150.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shoppingnotification/default/config.json/95ee762be190b48ee040758227d2f150.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t121.inf", 
		"Mode=HTTP", 
		LAST);

	web_revert_auto_header("Sec-MS-GEC");

	web_revert_auto_header("Sec-MS-GEC-Version");

	web_revert_auto_header("X-Client-Data");

	web_revert_auto_header("X-Edge-Shopping-Flag");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Access-Control-Request-Headers", 
		"onesvc-uni-feat-tun");

	web_add_header("Access-Control-Request-Method", 
		"GET");

	web_custom_request("ntp_2", 
		"URL=https://assets.msn.com/service/news/feed/pages/ntp?User=m-047FE09A36C068D9071EF357375969CA&activityId=B81EDEE8-5B95-42D1-95E6-4839775097E5&apikey=0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM&audienceMode=adult&caller=bgtask&cm=en-xl&column=c2&contentType=article,video,slideshow,webcontent&dhp=1&duotone=true&edgExpMask=262144&infopaneCount=17&it=app&memory=8&newsSkip=0&newsTop=48&ocid=anaheim-ntp-feeds&pgc=297&prerender=1&scn=APP_ANON&timeOut=2000&vpSize=910x429&wposchema=byregion", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t122.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("Sec-MS-GEC", 
		"ACC91C13C13940C5F92958826644C2D97BB012E5DE823C4011CFEE6F74688AAB");

	web_add_auto_header("Sec-MS-GEC-Version", 
		"1-123.0.2420.81");

	web_add_auto_header("X-Client-Data", 
		"eyIxIjoiMSIsIjEwIjoiXCJhazdIY1FwbmxabjhtOWFUeVJSK1RCbERzK051MGVBUHlQUEpsaEJnMy9nPVwiIiwiMiI6IjEiLCIzIjoiMCIsIjQiOiIzMzM3Mjg3NjA0ODc3Mjk4NjU3IiwiNSI6IlwiQ2t1QW1sUHhIejJDUmFJbkJWNmlhbTVVMmRSazdsREV6Z3RiK0I5TlVUOD1cIiIsIjYiOiJzdGFibGUiLCI3IjoiMjA0MDEwOTQ2NTYwMiIsIjkiOiJkZXNrdG9wIn0=");

	web_add_auto_header("X-Edge-Shopping-Flag", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("8adec8515e58c80f6f774f2d420cec15.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/shoppingnotification/default/config_en.json/8adec8515e58c80f6f774f2d420cec15.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t123.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("004349d6a7affd45ebceb3979eaf1abc.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/scrolldownbutton/default/config.json/004349d6a7affd45ebceb3979eaf1abc.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t124.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("4a37ddbf30ad3867d004bf02d153cb67.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/scrolldownbutton/default/config_en.json/4a37ddbf30ad3867d004bf02d153cb67.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t125.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("5a9dcf80eb7d47fa0f131fa402bac606.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/floatbuttongroupwc/default/config.json/5a9dcf80eb7d47fa0f131fa402bac606.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t126.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("41ecd6802a906fd75e6990a23ee8ca9c.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/floatbuttongroupwc/default/config_en.json/41ecd6802a906fd75e6990a23ee8ca9c.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t127.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("3d1bf1e54e0fcd0b95d6ce0ffd6c3690.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/channelstore/default/config.json/3d1bf1e54e0fcd0b95d6ce0ffd6c3690.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t128.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("ab7eb2da39d20b0c6219edd0733f0d04.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/channelstore/default/config_en.json/ab7eb2da39d20b0c6219edd0733f0d04.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t129.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("29ad9f1fd48a71e67f3feb642ceaf567.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/supercomponentdata/default/index.json/29ad9f1fd48a71e67f3feb642ceaf567.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t130.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("faaf9be05cdc6a06197ae6e6a7476d39.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/supercomponentdata/default/index.json/faaf9be05cdc6a06197ae6e6a7476d39.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t131.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("f707ab9fec4cc00b2f23af6a2f0632e9.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/backgroundimagewc/default/index.json/f707ab9fec4cc00b2f23af6a2f0632e9.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t132.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("f12847d9790cb54a098b035c6d69ed27.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/index.json/f12847d9790cb54a098b035c6d69ed27.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t133.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("48b42d1305d5f2ca3991d64f46cc0446.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/backgroundimagewc/default/index.json/48b42d1305d5f2ca3991d64f46cc0446.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t134.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("e841249fec6d00ab11fb2f9647cb944e.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/topsitesedgenextwc/default/index.json/e841249fec6d00ab11fb2f9647cb944e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t135.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("d38dd22de002a400c85a0a0a18e9a31a.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/supercomponentdata/default/config.json/d38dd22de002a400c85a0a0a18e9a31a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t136.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("ecd517c395b12971adb8390486022e21.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/supercomponentdata/default/config_en.json/ecd517c395b12971adb8390486022e21.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t137.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("8095580317e5d387067bf918cc84c8a4.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/backgroundimagewc/default/config.json/8095580317e5d387067bf918cc84c8a4.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t138.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("a6bdee88332a8467b794655649881e3c.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/config.json/a6bdee88332a8467b794655649881e3c.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t139.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("363c689d4cbe5cc817f1fc78a163db93.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/backgroundimagewc/default/config_en.json/363c689d4cbe5cc817f1fc78a163db93.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t140.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("e1e727107e5e5537caa713613eec4780.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/config_en-xl.json/e1e727107e5e5537caa713613eec4780.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t141.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("59ec862d217368d460a2705aef2bc160.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/config_adult.json/59ec862d217368d460a2705aef2bc160.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t142.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("3bfb4116ddaedaf78870c7ca82051686.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/config_windows.json/3bfb4116ddaedaf78870c7ca82051686.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t143.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("43ae7adb23028ec6bd8633cfa69f68cb.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/config_adult_windows.json/43ae7adb23028ec6bd8633cfa69f68cb.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t144.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("0fa7e539f29f5e6b523a0cc1f649ed4c.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/config_prg-tps-sort.json/0fa7e539f29f5e6b523a0cc1f649ed4c.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t145.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("dde51732c7a58fc4be282299452b6617.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/topsitesedgenextwc/default/config_prg-edg-tmtrig.json/dde51732c7a58fc4be282299452b6617.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t146.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("_EDGE_V=1; DOMAIN=assets.msn.com");

	web_add_cookie("APP_ANON=A=022CDA96091158A16CEFA276FFFFFFFF; DOMAIN=assets.msn.com");

	web_add_cookie("aace=%7b%22child%22%3a0%7d; DOMAIN=assets.msn.com");

	web_add_cookie("els=%7b%22account_type%22%3a%22MSA%22%7d; DOMAIN=assets.msn.com");

	web_add_cookie("MUIDB=054414BB474160B521EF0776469C61F6; DOMAIN=assets.msn.com");

	web_add_cookie("MUID=047FE09A36C068D9071EF357375969CA; DOMAIN=assets.msn.com");

	web_add_cookie("USRLOC=BID=MjQwNDE0MTMxNzE0XzZiZGZjZmRkMTIxZDcxNDFhNzNhM2VmNTU5ZGVkY2Q3MGM4MDBjZmM1N2QxN2U1ZTdmMTQ2MWFlNzMwNThmNmE=; DOMAIN=assets.msn.com");

	web_add_cookie("lt=t=EwBIA6AEAAAU+FEkrYVKODxcga16pzW/y5vRf68AAaEM9XfPeavWIEfjjeKT7MHf55yNQHnDUg6MpIlhw2plF73ZgHIwtNZTTYPnD4cZHv1KuepFlIpFsDeEpufd/pNP2eo6Gh+hygT4KtnV4ywbcdobOUl6PNsI0bu78vYCRTUSqeUA6SDAmjK0GkeyjA6HW+LkOwQMQ5GG3e5psIzWmK6UjCrG6EbU3QihaKHHTRtqGR2ArY1YPxfo9WsiVmDd7mVxMvwUISKj9X9k3rSJ368ZJv3OH/7/UerCCAjFs6E5sT6rXYLAzzX+oPuyLzEQca2DKA3f2RYRWalPHV49F7DgSiiYmW5PaAV5FO6M4v/Jq3gOw5zROt6bXoomqawDZgAACDETXrUahmW2GAKO0pl+"
		"D4iDZCAR5kTxJCJZ2WLafqOXFRPbPLGIGaq8snNpZL3EVIgPzxHP1WPHOtK3M3BmGWwUpi2zBAtK1fQPWiy0WRp9YlHgCBRZI6wEZHl6lMyuX5v/yrOD7iOjCyBC9s6zj8JxOXx8nLXT/dh3UiStmD3ioSW35hOAL+bjcmOtWWG+cIBrab+UjZeyMt3ktO4dT61R0r/BgjulDhAjF4CZKKObVpLXo54iavDo0iP6vsne58h+WnktlAuuiDCN523SoRSwmn80wL2rh66I0MhhNAKQ2sVjzaNF7pD4cQtyuuOLpQs0x3NxzxAHF8pV7AAMWicxbgMTo5uZ9HdKC67yPreh+cTIYTlBqEfrNedw5aVZF/CdFtcrI5CSzOAgcgPxNlg9ZlfXNhjEUXgvRoedm7DjFhlB1JX+VDFbeXnqss3UUjKSgMUohdq2xKl672Yn5MEd1GZXpSOgR0RaG35OrMYj1vlqr125TPs9EMdrT955/Qn/I6ocQW"
		"+BibGMJELQMH+iTMlAI5soraB7GdTdMlrh4SmW0C+vlJVpR5ZPUikPfi/ILlsVukmBlPbd9biYN2VFq0xyGYiYE4JWcJIAw7sk/VGXIX5rCrLbPDbHbUX2iTip4QY34vZCc1yfsNIhzbYxqm2Q39prmdwpezBmNkGWSQ0uERGRNM+aFOZy+HmORImkrBASs2tAo1CY2y1nKyx6YE8C&p=; DOMAIN=assets.msn.com");

	web_add_cookie("ANON=A=022CDA96091158A16CEFA276FFFFFFFF&E=1d24&W=1; DOMAIN=assets.msn.com");

	web_add_cookie("elt="
		"%7B%22access_token%22%3A%22eyJhbGciOiJSU0EtT0FFUCIsImVuYyI6IkExMjhDQkMtSFMyNTYiLCJ4NXQiOiJEZTRNSWJTY1ExeTdMYlBGSVR3emNMRmxrcFkiLCJ6aXAiOiJERUYifQ.SxRT7SBHXq6ai_uMHI-Rzyb6EHFk7jkDeT6Pb4YSD_I_cU5Br_eA_sysCQNT11RCVM1BCfrB2NwK8BU2xaGlRh2XqKKwwmEMo3je8zL2qLLbd1zyfyRZ-nUu-Ks-ulvEphP8LaxQK6Q5WWFFlAC3Le_7PDr2jm76KDcEWL31Q3vlLY-kD-SjUsEHZZNoK0hj6H005f-ubR_mr92caA9gnUL6-C5Y8N1-KTCAgm39S9L4f22PuRJZJ3jo3B-pWlnrlFLdn-wGR_R50D8EcJlB-pnVCnW8I8ntNkmAcXTGUWm812uMI8sbqHYe0_JmcOOoALIf2rEVcJZy4t7R6dvgFw.CnB833luCepxu"
		"FGnVeXD7w.SBrUl8g2BP9N95ZCZR8-rdLKT8UHycGqU8wsuWhTqkOVxYDJtz5p6xvcb0KyUd2JrQ6r_tBDQ2p6HQJ4jVjq1HI4oo2yStITYyFwp5AZu4nu5ApMxk-5hdvbY8zbbZpjkuME7Bq1LSu9ISWwRBIQhwjpjlQq9SViEQlXIO-kp5Ap0iDz5v2SQWj33OOxOGcqrlU1Ndh1yRc4SuSde4zZdxf7Nj6bzYZyIWnUR7aF1_SSGHigimBuFAi4sVnCbgB1GSG-k4vXHaXRUweBE5FHGw02YQKNbOco5G5K18EoYjVSEiVKwwtJsZdxBuTY3fm0mWXmbjjkUcrhwcrLXRYCYEtuYJgh7Z2IC0RxovKv-6IUyR9Wz9iD_MoOgbxzBV_7-ooIpvoMmsxQnCfjT_qvOiLE2pYH1cblK8v-yy2GOGe-1g6fNCWO2ybD3vIUChvfVmueKEPJ1_LrDJZv5MwbGOpRBALEl3HyGoBa9AJtRKY3"
		"PKn-9ppCKusni_iN7nO7cIi6sI4UxHVbSUyEBsto-Ap84ea9nFUW8vshCu1dc5Bs7j3j5kkgqqegNukrqu8ft7WaDK5h8s41O5UDO1MtM_nnTIcPfxRdfeFPFyjna43t3ZBR5Dl1xsjf3SyvwPwhHMq_VdedrcE8OeJgI51N5Nx6jKhV5T_M64z5YPY3AD9aR5J91y71e-sn3caqB6gMEtMxJksr2qW275fe92bSUhWro8zKibzStxmEzWBBZB26NoaTrjUBLcmYI_9pxEk8nsS3fOpS3ubZ4byKypkDQbPIb3yNH0ZXEHQb38N_83Swk7UJFBv6kj_fiQFAi8t2kpilT4cDbReYU5s_P2znwv1V_6uuN8kjIrTF-Ekb5PFB_NSr2afmbjY6yrl4IvGW5IHly3V72Wv57A7sanuyqNPJS-sWQs7WUhhxhXVZYhMKcDDAYwUiMwb7jxcB2HBTudPA2BrbOeblOdTdlEA01cUduKZFjw2kvU"
		"ciSs3F2INRUjPuuAl1Q3yQ-qxcskAxi8upyfcdH1loUTBirrxi8pxd4oN2ujsutxTQP6ShIkJpx2I9DetmeXj8OC_k717S0z12aAnbzaLDl957ZY1EINIqLGsWXUEVS6m05_vZ2sBmu9HafYtuBXGaen1t7I57EnX6vhTFJAFJWdevbzzhYz-duvNDwEqhAkOaLJODZqcJJlDf2i_RhR1q4wFi9ZrsjvXuY3OhK9nxXU3nKDfV4yvk1YrcJeFuZ1RvkN3qjguJ4U3_-uvuXRtJ4d8Le0ZyA0bU4VYAABxMvHvoKCU8jKoDch4LOZLT5aGPIsnSvtnyiwym-20eGLEN59i1q1XaKXa1YyXJLe-9hUPmS-Wb4_jnLO0DwyDOu44rHzo3OJ3t7ceYpnSV0PuY6TFxzeZpdQJVc54uQHvqImxSzro7zw.oaCcURkXMd0VRr2chosSfw%22%2C%22account_type%22%3A%22MSA%22%2C%22l"
		"ogin_hint%22%3A%22naominguema@mail.ru%22%2C%22e%22%3A%22d7410ae0%22%7D; DOMAIN=assets.msn.com");

	web_add_cookie("OptanonConsent=isGpcEnabled=0&datestamp=Sun+Apr+14+2024+13%3A20%3A52+GMT%2B0300+(%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0%2C+%D1%81%D1%82%D0%B0%D0%BD%D0%B4%D0%B0%D1%80%D1%82%D0%BD%D0%BE%D0%B5+%D0%B2%D1%80%D0%B5%D0%BC%D1%8F)&version=202310.2.0&isIABGlobal=false&hosts=&landingPath=NotLandingPage&groups=C0001%3A1%2CC0002%3A0%2CC0003%3A0%2CC0004%3A0%2CV2STACK42%3A0&AwaitingReconsent=false&browserGpcFlag=0; DOMAIN=assets.msn.com");

	web_add_header("OneSvc-Uni-Feat-Tun", 
		"EdgeInterestTier1Ids:null;LoginState:MSA;Product:anaheim;PageName:default;PageType:dhp;OCID:msedgdhp;ViewPortWidth:895;ViewPortHeight:429;");

	web_url("ntp_3", 
		"URL=https://assets.msn.com/service/news/feed/pages/ntp?User=m-047FE09A36C068D9071EF357375969CA&activityId=B81EDEE8-5B95-42D1-95E6-4839775097E5&apikey=0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM&audienceMode=adult&caller=bgtask&cm=en-xl&column=c2&contentType=article,video,slideshow,webcontent&dhp=1&duotone=true&edgExpMask=262144&infopaneCount=17&it=app&memory=8&newsSkip=0&newsTop=48&ocid=anaheim-ntp-feeds&pgc=297&prerender=1&scn=APP_ANON&timeOut=2000&vpSize=910x429&wposchema=byregion", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t147.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("46888afb2e3bdfaf12e839d4c7a4df4a.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/topsitesedgenextwc/default/config_en.json/46888afb2e3bdfaf12e839d4c7a4df4a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t148.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("f1d9606294bdd519d66b3ee65f617a5d.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shared/msn-ns/sharedtimestamputil/default/index.json/f1d9606294bdd519d66b3ee65f617a5d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t149.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("fadc6336fa6cd60e18c3ffd13e2aec8d.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/sharedtimestamputil/default/index.json/fadc6336fa6cd60e18c3ffd13e2aec8d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t150.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("BBUT8Gt", 
		"URL=https://assets.msn.com/content/view/v1/Preview/BBUT8Gt/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t151.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("ca600c42e74b4ed6305b8f6b6e83e02f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shared/msn-ns/sharedtimestamputil/default/config.json/ca600c42e74b4ed6305b8f6b6e83e02f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t152.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("BBZ2qdh", 
		"URL=https://assets.msn.com/content/view/v1/Preview/BBZ2qdh/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t153.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("d0674e9a9d0c0800b1da066d06c93858.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/sharedtimestamputil/default/config_en.json/d0674e9a9d0c0800b1da066d06c93858.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t154.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("BBXrPDN", 
		"URL=https://assets.msn.com/content/view/v1/Preview/BBXrPDN/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t155.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("58bc691caf590179de398aca6de33d9c.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/weathercardwc/default/index.json/58bc691caf590179de398aca6de33d9c.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t156.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("cea774ddf1fa26960f5652e04d5af13f.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/weathercardwc/default/index.json/cea774ddf1fa26960f5652e04d5af13f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t157.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("e052b1321e297772b978c4ecfa887c03.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/contentgroupcard/default/index.json/e052b1321e297772b978c4ecfa887c03.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t158.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("9313014b85ed145363370784456a6bd5.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/contentgroupcard/default/index.json/9313014b85ed145363370784456a6bd5.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t159.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("ff96f163b9a00ce696721dcaa3638d20.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/moneyinfo/default/index.json/ff96f163b9a00ce696721dcaa3638d20.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t160.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("0783da5c8945c40583dda37cc6349b9e.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/moneyinfo/default/index.json/0783da5c8945c40583dda37cc6349b9e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t161.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("AAEPxOs", 
		"URL=https://assets.msn.com/content/view/v1/Preview/AAEPxOs/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t162.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("57219b5e7221ec41471c43ba1bf668fa.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/publishersubscribefollowbutton/default/index.json/57219b5e7221ec41471c43ba1bf668fa.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t163.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("a6bd660ce0bb9bbf1bcfbc3ce366ce47.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/weathercardwc/default/config.json/a6bd660ce0bb9bbf1bcfbc3ce366ce47.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t164.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("c011e4cfaad1ee1baa92e3c8c3a71e27.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/weathercardwc/default/config_en.json/c011e4cfaad1ee1baa92e3c8c3a71e27.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t165.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("a28dd8e94dbeedb5c513e97facb7a489.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shared/msn-ns/publishersubscribefollowbutton/default/index.json/a28dd8e94dbeedb5c513e97facb7a489.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t166.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("72f9e668c8b0d0e72b382f3b955dcfcd.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/contentgroupcard/default/config.json/72f9e668c8b0d0e72b382f3b955dcfcd.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t167.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("1523118b13420b5fb2fc9926f45f09d3.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/contentgroupcard/default/config_en.json/1523118b13420b5fb2fc9926f45f09d3.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t168.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("3167cefecc63944dcdcb1d650362e6ec.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/contentgroupcard/default/config_en.json/3167cefecc63944dcdcb1d650362e6ec.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t169.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("c0549078894023ef2de5913d56e0f0b5.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/moneyinfo/default/config.json/c0549078894023ef2de5913d56e0f0b5.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t170.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("83b12d29c3fa8d1248eff671be97819d.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/moneyinfo/default/config_en.json/83b12d29c3fa8d1248eff671be97819d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t171.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("2ccf4eb6882046e990ad3f0b46dc0c9e.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/moneyinfo/default/config_en-xl.json/2ccf4eb6882046e990ad3f0b46dc0c9e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t172.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("AAGyAUv", 
		"URL=https://assets.msn.com/content/view/v1/Preview/AAGyAUv/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t173.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("618895fead3f93be36ac14ab724264df.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/shared/msn-ns/publishersubscribefollowbutton/default/config.json/618895fead3f93be36ac14ab724264df.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t174.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("MUID=047FE09A36C068D9071EF357375969CA; DOMAIN=th.bing.com");

	web_add_cookie("USRLOC=HS=1&BID=MjQwNDE0MTMxNzE0XzZiZGZjZmRkMTIxZDcxNDFhNzNhM2VmNTU5ZGVkY2Q3MGM4MDBjZmM1N2QxN2U1ZTdmMTQ2MWFlNzMwNThmNmE=; DOMAIN=th.bing.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=th.bing.com");

	web_add_cookie("SRCHUID=V=2&GUID=C12181BD05144ECB80849DC309AB08FA&dmnchg=1; DOMAIN=th.bing.com");

	web_add_cookie("PPLState=1; DOMAIN=th.bing.com");

	web_add_cookie("KievRPSSecAuth=FAB6BBRaTOJILtFsMkpLVWSG6AN6C/svRwNmAAAEgAAACH/mUTlacZh5OAQb7txY2Hmtl3kQ8lGciHw1xn4Bsbk1WYu8lQhSQZ+s1FndCSAlgD20IKrPrYop3TJTzmuW3oJiFARgj3C7EvIesPjC0GmlF5y0X7DSctk6BSpmMxXmbzRSLR8Mg65GyUkUjcHXdRe6FEQkUDq0Xn4/lmcbHwURb+onOdXmap1iCUY3Ny53CW3P0dXm1NnduH8qp5UUDwV1qTOYyA8DZWKg3LkNQcFZSMXSlz9nEQNouoCSLS7kJsiXuHBXD7qhaWYZ+7qUMTkKkFN2V2/VCGuYfyEoeGzOwoErtG+zbB7w05VgFIoVFgixNZLfAMW250R7epRUmacViQ2lLainWn3vEAyE+2se90TZTllKyFwLRtfNhhnPULLGqODoj220iC+E2E/"
		"svhFpo0U8OT0C3hPEKQOXitX3APenCaJNutxEIo/BZsFxAfWTU7KPFBUFsa2uAFV3sMU3iFfElT+7eHnEu3trymnd3/9V53VrmwBvab+mYjYlj7O13hqb5e0qZU6iiVW6jr6wL9S+z9uYM+BmIYxxzZdjhm4wMt1ik9oMqlYyCaAYbngwfRhVUbCu2maFEqKsaUib+WFm2+k6cTrazVHmlr7LoAoE7tQrlpxM5TZully4+uUOU13jEaIpxxxnKN3YIgWpKXhXEs/5KB6FsBXgBHBBYaA93ySrIQvhxrrHjoUDbET7//lxPUlGUnrcNqhX9yEERk57Vlr8niXMiXrHRfr1AssucaT8+nYL7giotEltuhCHOaKtCyzbqHzZNq6/btAmFVewSPOIftGsWHMFYd6QO5P9hmHJi3yJGmqWuM82bHnQyXk562O4V6KEdqoVZ+N/WHefD2KjWC8c55SOiQyZmm527WNGStlLfGtUOOd7xzHGMQ/"
		"OfYad+7tAY/LoLd6EjW+bJjo+KmoH0m4n6SSbLMC2dpX2ZdSiyTz371oaXlTvpM4eWF2T0XCGpeLSB/NTisTez7tGcXxl4QMS22StaPnoUOv1SArDzOczZiPqm+7Gl8HB58NRh37W/gHAVIm8/ojPRN3MD9s6Xk+yCFZhIhjDffs4QmGnFK3BvifnavuJCDOUcn51WlNLFNcLnwb+w9cC8c0XyS13/f6Ztb+6DfeK/KKIbEteD9cjvM3Axw3pPHlRdkPPXduXd1MJ5Lepldv+thPcYnm0XgSSC/wRd+4YnF3wX8uR9cQ90PluZDKuvTTLfWPnD7/W+i0kZequzaykcBMS4jAzGyHdh2BBuPRisZ9XJBUH+easGakaPjQH6vCbpt7yoL1WCltQiaYGIqC+"
		"UxqmY3ZJNFYBthacMY4GzwhBt70xFv8C44E2QmZEtYQ86MWUm90PbIjrE0Lihl3I4cggA40ZQnOvd27JSmOokq5bSUYxwQGUL42DAgGSmNMK02fpJE7OU7aZQwL8ZGy0/guaLo6uWeqP1e46KRUUAFVAg/JAOkeDabRJk7tsLdKbAs6i; DOMAIN=th.bing.com");

	web_add_cookie("MMCASM=ID=06438D28877A431F9ACC9F095B9B96F1; DOMAIN=th.bing.com");

	web_add_cookie("_RwBf=r=0&ilt=0&ihpd=0&ispd=0&rc=0&rb=0&gb=0&rg=0&pc=0&mtu=0&rbb=0&g=0&cid=&clo=0&v=0&l=0001-01-01T00:00:00.0000000&lft=0001-01-01T00:00:00.0000000&aof=0&ard=0001-01-01T00:00:00.0000000&rwdbt=0001-01-01T00:00:00.0000000&rwflt=0001-01-01T00:00:00.0000000&o=2&p=&c=&t=0&s=0001-01-01T00:00:00.0000000+00:00&ts=2024-03-16T08:16:43.5847123+00:00&rwred=0&wls=2&wlb=0&wle=0&ccp=0&lka=0&lkt=0&aad=0&TH=; DOMAIN=th.bing.com");

	web_add_cookie("SRCHUSR=DOB=20231118&T=1710999974000&POEX=W; DOMAIN=th.bing.com");

	web_add_cookie("Imported_MUID=39FEA931D3406BD01315BD78D25D6A20; DOMAIN=th.bing.com");

	web_add_cookie("EDGSRCHHPGUSR=CIBV=1.1690.0; DOMAIN=th.bing.com");

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_url("th", 
		"URL=https://th.bing.com/th?id=ORMS.fa5453af3f4100db79ec40c12bf6ea75&pid=Wdp&w=300&h=156&qlt=90&c=1&rs=1&dpr=1&p=0", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t175.inf", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Origin", 
		"https://ntp.msn.com");

	web_url("c145789aa55d34c0339db96cde8b348a.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/publishersubscribefollowbutton/default/config_en.json/c145789aa55d34c0339db96cde8b348a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t176.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_url("th_2", 
		"URL=https://th.bing.com/th?id=ORMS.d01649d3295ac4517d127368c31af13c&pid=Wdp&w=612&h=328&qlt=90&c=1&rs=1&dpr=1&p=0", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t177.inf", 
		LAST);

	web_add_auto_header("Origin", 
		"https://ntp.msn.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_url("BBV2H8k", 
		"URL=https://assets.msn.com/content/view/v1/Preview/BBV2H8k/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t178.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("c0f51f06cdc1be01d2c93fa39c3eb17f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/backgroundgallery/default/index.json/c0f51f06cdc1be01d2c93fa39c3eb17f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t179.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("fd960168183a172b20cde998e9b05821.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/backgroundgallery/default/index.json/fd960168183a172b20cde998e9b05821.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t180.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("fe7c57a8ec107f79936a34360b467dbe.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/conditionalbannerwc/default/index.json/fe7c57a8ec107f79936a34360b467dbe.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t181.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("3fe1c6cce9cdab1523a8ddf3dc7939f4.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/commonsettingsedgenext/default/index.json/3fe1c6cce9cdab1523a8ddf3dc7939f4.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t182.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("4d9f9f184cedafa6ef82decfad53fb9a.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/commonsettingsedgenext/default/index.json/4d9f9f184cedafa6ef82decfad53fb9a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t183.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("eaee621494ebc00ccd972234af10b047.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/wafflewc/default/index.json/eaee621494ebc00ccd972234af10b047.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t184.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("f1aeef1cee0a82d55ea893a1b137cfe7.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/wafflewc/default/index.json/f1aeef1cee0a82d55ea893a1b137cfe7.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t185.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("ed36a4f59ca9a903fe1bcc72a1aa4345.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/welcomegreetinglight/default/index.json/ed36a4f59ca9a903fe1bcc72a1aa4345.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t186.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("3167ace0e238bb3ad663713a9b9cda54.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/welcomegreetinglight/default/index.json/3167ace0e238bb3ad663713a9b9cda54.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t187.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("14d13a2608164551ea198c3dc78d2587.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/notificationbellwc/default/index.json/14d13a2608164551ea198c3dc78d2587.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t188.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("c12f15049ef70449f938b84a065eb871.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/notificationbellwc/default/index.json/c12f15049ef70449f938b84a065eb871.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t189.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("b0a99020b7ea27743aadf13a8cdad0b1.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/feedbacklinkwc/default/index.json/b0a99020b7ea27743aadf13a8cdad0b1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t190.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("fa3ff00544e9a0b65796af123e9294f6.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/feedbacklinkwc/default/index.json/fa3ff00544e9a0b65796af123e9294f6.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t191.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("7531650cbbac0523da2ce8c90a01e9e0.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/marketlanguagetogglewc/default/index.json/7531650cbbac0523da2ce8c90a01e9e0.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t192.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("c5cba2665d934b64ecf27b32d9c3fb78.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/marketlanguagetogglewc/default/index.json/c5cba2665d934b64ecf27b32d9c3fb78.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t193.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("b7fa6e0f35326f1cb700b37611955750.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/weatheroneliner/default/index.json/b7fa6e0f35326f1cb700b37611955750.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t194.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("bd0f263de9b3cf17060481a64a80c9d6.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/weatheroneliner/default/index.json/bd0f263de9b3cf17060481a64a80c9d6.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t195.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("9cda9b7ab92509dd508d6640e045a30e.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/msrewardswc/default/index.json/9cda9b7ab92509dd508d6640e045a30e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t196.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("c892fbcbbe41ffabd8516258f31b4d91.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/msrewardswc/default/index.json/c892fbcbbe41ffabd8516258f31b4d91.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t197.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("1ab21b919dfe65e72314f7cb5a5f90b1.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/signincontrolwc/default/index.json/1ab21b919dfe65e72314f7cb5a5f90b1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t198.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("fad0c36f5fb3552eb87f6c52a89f171a.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/signincontrolwc/default/index.json/fad0c36f5fb3552eb87f6c52a89f171a.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t199.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("c6e5a94ef3c26f2c1c765385bce9a26d.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/mobileappupsell/default/index.json/c6e5a94ef3c26f2c1c765385bce9a26d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t200.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("eb2f9f083ce796cd125bfbd08cd1b826.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/mobileappupsell/default/index.json/eb2f9f083ce796cd125bfbd08cd1b826.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t201.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("48b26cedb5a1fb079f41361b94a45eb6.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/nurturingcoachmark/default/index.json/48b26cedb5a1fb079f41361b94a45eb6.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t202.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("d746a86707cd37bf28d3f8716556925d.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/codexbingchat/default/index.json/d746a86707cd37bf28d3f8716556925d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t203.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("8240e0badd5f65ea89c7addee00f16b1.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/codexbingchat/default/index.json/8240e0badd5f65ea89c7addee00f16b1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t204.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("1e3d06c91cf46452566acd3dddfd11ca.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/pillwc/default/index.json/1e3d06c91cf46452566acd3dddfd11ca.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t205.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("76f8557c995f9f8a904f4d1f43497925.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/pillwc/default/index.json/76f8557c995f9f8a904f4d1f43497925.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t206.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("ce69842cc06b58687b27e856ca7153cd.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/cardactionwc/tellusmore/index.json/ce69842cc06b58687b27e856ca7153cd.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t207.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("173e77241c2270d6ef383f7c75f92342.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/cardactionwc/default/index.json/173e77241c2270d6ef383f7c75f92342.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t208.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("01f1ca370b32fa5b8d319d352e5c0076.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/superbreakingnews/default/index.json/01f1ca370b32fa5b8d319d352e5c0076.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t209.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("f683297120593e74736b56104372aabc.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/superbreakingnews/default/index.json/f683297120593e74736b56104372aabc.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t210.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("bd588dfaa1f085a4b831ce5a72462bb4.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/toastwc/default/index.json/bd588dfaa1f085a4b831ce5a72462bb4.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t211.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("c8aaa2d41bc2f31991095c17b3d70d08.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/toastwc/default/index.json/c8aaa2d41bc2f31991095c17b3d70d08.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t212.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("fc555330c90e75fa74ecc34d45bcbc99.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/backgroundgallery/default/config_en.json/fc555330c90e75fa74ecc34d45bcbc99.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t213.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_5", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/conditionalbannerwc/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t214.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("fa446b4cbec3ebccd8611a45913f824e.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/commonsettingsedgenext/default/config.json/fa446b4cbec3ebccd8611a45913f824e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t215.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("b6b11ce0694f7101a51906f39bd75603.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/backgroundgallery/default/config.json/b6b11ce0694f7101a51906f39bd75603.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t216.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("df4e4bb365a900724d0d7cf615f0a2b2.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/commonsettingsedgenext/default/config_en-xl.json/df4e4bb365a900724d0d7cf615f0a2b2.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t217.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("55cc29793ac0b5649d8c2468e72e423e.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/commonsettingsedgenext/default/config_adult.json/55cc29793ac0b5649d8c2468e72e423e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t218.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("39376f10c4b3f37b1a675da3d6e8c2a1.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/commonsettingsedgenext/default/config_prg-ncm.json/39376f10c4b3f37b1a675da3d6e8c2a1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t219.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("386621246cf473e7761c48a7abb5b0eb.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/commonsettingsedgenext/default/config_en.json/386621246cf473e7761c48a7abb5b0eb.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t220.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("066ea76c9c6a211a0a06b1b0e20df8ac.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/wafflewc/default/config_en.json/066ea76c9c6a211a0a06b1b0e20df8ac.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t221.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("a6fea764b076506d478f089717172659.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/wafflewc/default/config.json/a6fea764b076506d478f089717172659.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t222.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("1e155a5cd9936f77ef75a64e65f5cd3b.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/welcomegreetinglight/default/config.json/1e155a5cd9936f77ef75a64e65f5cd3b.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t223.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("8fb7b39ce55c734ba1cfad7acef79245.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/welcomegreetinglight/default/config_en.json/8fb7b39ce55c734ba1cfad7acef79245.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t224.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("5cb1856ef76556118ee33dae00457390.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/notificationbellwc/default/config.json/5cb1856ef76556118ee33dae00457390.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t225.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("abf137df6c377781a5e41dafd86280c7.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/notificationbellwc/default/config_en.json/abf137df6c377781a5e41dafd86280c7.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t226.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("4a48d9b48131eef49b36f865b07ebb16.json_6", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/feedbacklinkwc/default/config.json/4a48d9b48131eef49b36f865b07ebb16.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t227.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("58914b9c7b8a02f7de4c68debdeeb989.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/feedbacklinkwc/default/config_en.json/58914b9c7b8a02f7de4c68debdeeb989.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t228.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("077aea77d37b5642f847ef7a8e710420.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/marketlanguagetogglewc/default/config_en.json/077aea77d37b5642f847ef7a8e710420.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t229.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("2cc0e19f048cda04adb458d068ad30ee.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/weatheroneliner/default/config.json/2cc0e19f048cda04adb458d068ad30ee.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t230.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("8bfb2a6182ec8993f33bd44fdb61b818.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/weatheroneliner/default/config_en.json/8bfb2a6182ec8993f33bd44fdb61b818.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t231.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("f320387508c7365193a6008a6599d43b.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/marketlanguagetogglewc/default/config.json/f320387508c7365193a6008a6599d43b.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t232.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("b1abf8801f5437fade9328e91e778794.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/msrewardswc/default/config.json/b1abf8801f5437fade9328e91e778794.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t233.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("b4e3788958986731ae696789bcbaa494.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/msrewardswc/default/config_en.json/b4e3788958986731ae696789bcbaa494.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t234.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("cbed208a4debe96207450878146e0c79.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/signincontrolwc/default/config.json/cbed208a4debe96207450878146e0c79.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t235.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("37da5b72583635e8a8253ca015680912.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/signincontrolwc/default/config_en.json/37da5b72583635e8a8253ca015680912.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t236.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("0ffde60731794352f910992cdd32fe6f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/mobileappupsell/default/config.json/0ffde60731794352f910992cdd32fe6f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t237.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("f957f996f886204ef6e1b657d070e0d1.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/nurturingcoachmark/default/config.json/f957f996f886204ef6e1b657d070e0d1.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t238.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("6a5dac8849073a6068018f0caecc5380.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/mobileappupsell/default/config_en.json/6a5dac8849073a6068018f0caecc5380.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t239.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("9b8fd484ba3595a63fb45a1354203592.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/codexbingchat/default/config.json/9b8fd484ba3595a63fb45a1354203592.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t240.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("6d152f9b6f2364c1d90535385a7b61fd.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/codexbingchat/default/config_en.json/6d152f9b6f2364c1d90535385a7b61fd.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t241.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("cae98b1aa99fa2fbf657fa6902a5510d.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/pillwc/default/config.json/cae98b1aa99fa2fbf657fa6902a5510d.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t242.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("97b13f657eccc764df4dc4463ff88372.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/pillwc/default/config_en.json/97b13f657eccc764df4dc4463ff88372.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t243.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("0ac38507b87c07fc994a2a5e8c529e88.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/cardactionwc/tellusmore/config.json/0ac38507b87c07fc994a2a5e8c529e88.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t244.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("902146fd70e7af628843506d09e2bbbc.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/cardactionwc/tellusmore/config_en.json/902146fd70e7af628843506d09e2bbbc.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t245.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("902146fd70e7af628843506d09e2bbbc.json_2", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/cardactionwc/tellusmore/config_prg-rpt2.json/902146fd70e7af628843506d09e2bbbc.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t246.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("fe665f8c67764a36b4e6558d0c85aa17.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/cardactionwc/tellusmore/config_en_prg-rpt2.json/fe665f8c67764a36b4e6558d0c85aa17.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t247.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("106cfbd1a22e9fdde395d990b7754c2e.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/cardactionwc/default/config_en.json/106cfbd1a22e9fdde395d990b7754c2e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t248.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("8fdb7aaff4ad0dfc56bbf7b5a98c562f.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/superbreakingnews/default/config.json/8fdb7aaff4ad0dfc56bbf7b5a98c562f.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t249.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("4548e1027cc352294a82036dbc436a87.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/superbreakingnews/default/config_en-xl.json/4548e1027cc352294a82036dbc436a87.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t250.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("dc598f01287400438037e307dc244765.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/superbreakingnews/default/config_en.json/dc598f01287400438037e307dc244765.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t251.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("481ba17414e7899524eddb7f42af4f04.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/toastwc/default/config.json/481ba17414e7899524eddb7f42af4f04.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t252.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("dbebc4fb892d3e4ef9143e57e89305a9.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/toastwc/default/config_en.json/dbebc4fb892d3e4ef9143e57e89305a9.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t253.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("7e9289ff53373203953f2e827e0f33be.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/weathercarddata/default/index.json/7e9289ff53373203953f2e827e0f33be.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t254.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("d3287309247150652f3d743027ac2462.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/rewardsdata/default/index.json/d3287309247150652f3d743027ac2462.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t255.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("cbc3a1af7858651b0343ffd0ed2efaed.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/rewardscoachmarkdata/default/index.json/cbc3a1af7858651b0343ffd0ed2efaed.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t256.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("BBJDkuT", 
		"URL=https://assets.msn.com/breakingnews/v1/cms/api/amp/article/BBJDkuT", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t257.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("be48bb276aabfb8bb76222a4576fb9a4.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/rewardscoachmarkdata/default/index.json/be48bb276aabfb8bb76222a4576fb9a4.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t258.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("122b3261e158f9866a23f6386a26e1b7.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/weathercarddata/default/config.json/122b3261e158f9866a23f6386a26e1b7.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t259.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("ef039fd0b46c3da19e546741eae2f610.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/rewardsdata/default/config.json/ef039fd0b46c3da19e546741eae2f610.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t260.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("f46df0c66c7cdbf72878eb05be19a105.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/rewardscoachmarkdata/default/config.json/f46df0c66c7cdbf72878eb05be19a105.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t261.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("d0a1bfbea73f3fb64452953517a740a8.json", 
		"URL=https://assets.msn.com/periconfigs/feature-configs/rewardscoachmarkdata/default/config_adult.json/d0a1bfbea73f3fb64452953517a740a8.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t262.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("f790b9069aaa21bf78cd3802aee5766e.json", 
		"URL=https://assets.msn.com/periconfigs/loc-configs/rewardscoachmarkdata/default/config_en.json/f790b9069aaa21bf78cd3802aee5766e.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t263.inf", 
		"Mode=HTTP", 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-MS-GEC");

	web_revert_auto_header("Sec-MS-GEC-Version");

	web_revert_auto_header("X-Client-Data");

	web_revert_auto_header("X-Edge-Shopping-Flag");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_url("GetWalletConnectivity", 
		"URL=https://xpaywalletcdn.azureedge.net/mswallet/ExpressCheckout/v1/GetWalletConnectivity", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t264.inf", 
		LAST);

	web_add_header("X-Client-Data", 
		"eyIxIjoiMSIsIjEwIjoiXCJhazdIY1FwbmxabjhtOWFUeVJSK1RCbERzK051MGVBUHlQUEpsaEJnMy9nPVwiIiwiMiI6IjEiLCIzIjoiMCIsIjQiOiIzMzM3Mjg3NjA0ODc3Mjk4NjU3IiwiNSI6IlwiQ2t1QW1sUHhIejJDUmFJbkJWNmlhbTVVMmRSazdsREV6Z3RiK0I5TlVUOD1cIiIsIjYiOiJzdGFibGUiLCI3IjoiMjA0MDEwOTQ2NTYwMiIsIjkiOiJkZXNrdG9wIn0=");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Origin", 
		"https://ntp.msn.com");

	web_add_header("Sec-MS-GEC", 
		"ACC91C13C13940C5F92958826644C2D97BB012E5DE823C4011CFEE6F74688AAB");

	web_add_header("Sec-MS-GEC-Version", 
		"1-123.0.2420.81");

	web_add_header("X-Edge-Shopping-Flag", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("Rewards", 
		"URL=https://assets.msn.com/service/News/Users/me/Rewards?apikey=1hYoJsIRvPEnSkk0hlnJF2092mHqiz7xFenIFKa9uc&activityId=B81EDEE8-5B95-42D1-95E6-4839775097E5&ocid=rewards-peregrine&cm=en-xl&it=app&user=m-047FE09A36C068D9071EF357375969CA&scn=APP_ANON&version=2", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t265.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("X-AFS-CV", 
		"aZIzAAstxOMIbH0oW2TTua");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("X-AFS-ClientInfo", 
		"platform=Windows; os=Windows NT; osVer=10.0.22621; app=Microsoft Edge; appVer=123.0.2420.81; appChannel=stable; appInstallationId=3337287604877298657; region=RU;");

	web_add_auto_header("X-Client-Data", 
		"CLUICIcQCLMQCNyIywE=");

	web_custom_request("command_6", 
		"URL=https://edge.microsoft.com/sync/v1/feeds/me/syncEntities/command/?client=Chromium&client_id=xoA3wCAk%2BKGKcH9sFEoxyQ%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t266.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTTP", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x18xoA3wCAk+KGKcH9sFEoxyQ==\\x10c\\x18\\x02*\\xCF\\x04\\x12\\x04\\x08\\x00\\x10\\x01\\x18\\x012\\x1E\\x08\\x88\\x81\\x02\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xC6\\xA6\\x02\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x01(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xB1\\xE6\\x02\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00"
		"(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xCF\\xF3\\x03\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xCD\\xBE\\x02\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xF7\\xF7\\x02\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xC7\\x87\\x03\\x12\\x08="
		"\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x04(\\x000\\x008\\x00@\\x002\\x1E\\x08\\x9F\\xEF\\x05\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xEB\\x95\t\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\x9A\\xB7\t\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xFC\\xDE$\\x12\\x08="
		"\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xC9\\x8B)\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xA1\\xDD'\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xD0\\xAF:\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xA9\\xF0O\\x12\\x08="
		"\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xF1\\xBFG\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\xB5\\xDAD\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x002\\x1E\\x08\\x81\\xF5\\x02\\x12\\x08=\\x96\\x1E\\xDC\\x8E\\x01\\x00\\x00*\\x0E\\x10\\x00\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00H\\x0CP\\x00\\xC0>\\x01"
		":\\x1FProductionEnvironmentDefinitionRO\n)\\x12'8\\x00@\\x07R\\x04\\x08\\x00\\x10\\x00`\\x0C\\x92\\x03\\x18+yyLvICo/enGONOj7eldki.1\n\\x04\\x18\\xC7\\x87\\x03\n\\x04\\x18\\xC7\\x87\\x03\n\\x04\\x18\\xC7\\x87\\x03\n\\x04\\x18\\xC7\\x87\\x03\n\\x04\\x18\\xC6\\xA6\\x02\\x10\\x01\\x18\\x00 \\x00Z\\x05\n\\x03106b 00000000000000000000000000000000j\\x02\\x10\\x01r\\x1Cchr:xoA3wCAk+KGKcH9sFEoxyQ==", 
		LAST);

	web_add_header("X-AFS-CV", 
		"QxXh8wq8doy0fXF4X5BGzk");

	web_custom_request("command_7", 
		"URL=https://edge.microsoft.com/sync/v1/feeds/me/syncEntities/command/?client=Chromium&client_id=xoA3wCAk%2BKGKcH9sFEoxyQ%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t267.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTTP", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x18xoA3wCAk+KGKcH9sFEoxyQ==\\x10c\\x18\\x01\"\\xD8\\x08\n\\xDC\\x02\n$e3b18059-7bd9-4583-9fec-c47813cbf39e \\xB6\\xAC\\xFA\\xE0\\xED1(\\xA6\\xE6\\xFF\\xE0\\xED10\\xF7\\x9A\\xF8\\xA3\\xB81:\\x17ntp.record_user_choices\\x90\\x01\\x00\\xAA\\x01\\xE2\\x01\\xB2\\xB4\\x12\\xDD\\x01\n\\x17ntp.record_user_choices\\x12\\xC1\\x01[{\"setting\":\"tscollapsed\",\"source\":\"tscollapsed_to_off\",\"timestamp\":1.698734941076e+12,\"value\":0},{\"setting\":\"breaking_news_dismissed\",\"source\":\""
		"ntp\",\"timestamp\":1.713090065189e+12,\"value\":{}}]\\xBA\\x01\\x1CuOuWSaJEin0p2bX/hQqawC+tIgU=\n_\n$732e48c2-6c1a-496e-bdaf-07cbe9d8549d \\xB8\\xAC\\xFA\\xE0\\xED1(\\x9D\\xD6\\xFE\\xE0\\xED1:\\x00\\x90\\x01\\x01\\xAA\\x01\\x04\\xBA\\xBC\\x18\\x00\\xBA\\x01\\x1C20WG9Ij4Kh0slIEKN0PMSQMP3HI=\n_\n$7f699138-5b05-41f7-a89b-f9833f37891a \\xBA\\xAC\\xFA\\xE0\\xED1(\\x9D\\xD6\\xFE\\xE0\\xED1:\\x00\\x90\\x01\\x01\\xAA\\x01\\x04\\xBA\\xBC\\x18\\x00\\xBA\\x01\\x1CX3tO7O/YcASZuiU+ilg8r3eTiEY=\n_\n"
		"$d11f4c00-68b9-40db-b2aa-825f6f13d583 \\xBB\\xAC\\xFA\\xE0\\xED1(\\x9D\\xD6\\xFE\\xE0\\xED1:\\x00\\x90\\x01\\x01\\xAA\\x01\\x04\\xBA\\xBC\\x18\\x00\\xBA\\x01\\x1CjezMd4cNHOI6aV4/mnud+iX9eGo=\n_\n$abbbaf62-adfb-415f-a44c-052e3e53798c \\xBC\\xAC\\xFA\\xE0\\xED1(\\x9D\\xD6\\xFE\\xE0\\xED1:\\x00\\x90\\x01\\x01\\xAA\\x01\\x04\\xBA\\xBC\\x18\\x00\\xBA\\x01\\x1Ctv0Wlcv8QzeAM6/nQR0kudQ8e9E=\\x12\\x18xoA3wCAk+KGKcH9sFEoxyQ==\""
		"V\\x08\\x88\\x81\\x02\\x08\\xC6\\xA6\\x02\\x08\\xB1\\xE6\\x02\\x08\\xCF\\xF3\\x03\\x08\\xCD\\xBE\\x02\\x08\\xF7\\xF7\\x02\\x08\\xC7\\x87\\x03\\x08\\x9F\\xEF\\x05\\x08\\xEB\\x95\t\\x08\\x9A\\xB7\t\\x08\\xEE\\xF7!\\x08\\xFC\\xDE$\\x08\\xC9\\x8B)\\x08\\xA1\\xDD'\\x08\\xD0\\xAF:\\x08\\xA9\\xF0O\\x08\\xF1\\xBFG\\x08\\xB5\\xDAD\\x08\\x81\\xF5\\x02\\x10\\x01\\x18\\x00 \\x010\\x01@\\x012\\x80\\x02?CtKR,.0*;J_ M-tT$^x9%#YHWN&vw(!*ccFc\\\\Vcb;:Et/6Y^o>=G}Txxi\\\\>5GoTAM]q\"K?\"\\\\n.|p6R5bU|)3TvT;]HmF|idR1 "
		"pVfw>qs#UY2s{$rO:xvcir\";9iVM#D>UyZTJc^_Yb7Xv>JHAwun@bmU8&lV=Xsj8/| By6z~{@M.$n* $D7_(BK=uo+Jw@5c9!1tYZ14LLk+:\\\\34C{,&%%oTW*~nIu!vjmZlD#iN?lb0\"K]%qBe8y2:C:zot\\\\:\\x1FProductionEnvironmentDefinitionR\\x06\\x10\\x01\\x18\\x00 \\x00Z\\x05\n\\x03106b 00000000000000000000000000000000j\\x02\\x10\\x01r\\x1Cchr:xoA3wCAk+KGKcH9sFEoxyQ==", 
		LAST);

	web_revert_auto_header("X-AFS-ClientInfo");

	web_revert_auto_header("X-Client-Data");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(19);

	web_url("welcome.pl_2", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t268.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("nav.pl_3", 
		"URL=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"Snapshot=t269.inf", 
		"Mode=HTTP", 
		LAST);

	lr_think_time(6);

	web_url("home.html_2", 
		"URL=http://localhost:1080/WebTours/home.html", 
		"Resource=0", 
		"Referer=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"Snapshot=t270.inf", 
		"Mode=HTTP", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("MSA_DeviceTicket", 
		"t=EwCwAlN5BAAUu1V9OkIAK55tj6h8OjaXgvkszYkAAY9NEMMOG1ZC6Y77F/RDA0mh4UnGvcndoXhMVquNuZ9n8TZIGWc9//xSeF/c4+cV3Vq0aBVFi14JxFEDmbNfa8NriWoVVqcpXpx00LOiHa7WOpLDRDVN+WBoA4WjIxeI+J12n4mFT3uPotLcW31GZ1gDsEWs0bOc+D4Obylokyj98AC93St+benkpdlHHzc+eJUHW2z+12YL4rxo+Wc+k3h0Pp+/m8n04GtBsYQEv41s49MjA2Y0rEdztmIsYGiMaiaHxDAuRkdfCKYduEie4P8hyn4qVRVFvlmNlKszby2o8mOtF1KzDs54Fb6c3yTQSwQJgjowCuCVKanklnxjTAEDZgAACDgQ19u9HbjLgAFb5csmfK1UpLesGa3lheum/JopRJkMQxRj+w2Ve7LGlZ50sqYhdggs8+ggvpf0E4bepv+Ft39o5sShK21ScLw/nzBPHIWi/"
		"yXtCdh1UHcnBtFShZ8gBHWT0uvoVXjjZDT8xAfeDSTOaHkT1RRf769p+xppCxx96FVgeoXm5SnK3wQRfBQkqlFqwG8ppIFBpSsa7sPrREQuHSiTGb4AFiFtLfGTcrnA5nzZAu+We+tkTmYoMshC/BUuwFgN5eQ4/rb84EeDN5jkFcWrOgl+0cUqeqvcvESQLy1pKfgRRBrJqA5ZQqMrxafYLOFADMchmqAxaix92Zwo6GLDi4aBXK2n3p4iFJCzImbQzxZNVwp948aSTR5t5GtBPH77w3BJDKOa7Fgh3COTm7rZQz5hSlO7q3X78E++gsrX4kpKhlmccKRDqDggbV31CwpPibi/SzxcZShOTxThGQmNEG0v47sM5b92nPw/bN8Tk2E2cnV5wCLqWqMuprY6ZfhKp86RSRC2AQ==&p=");

	lr_think_time(36);

	web_custom_request("Telemetry.Request_2", 
		"URL=https://nw-umwatson.events.data.microsoft.com/Telemetry.Request", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t271.inf", 
		"Mode=HTTP", 
		"EncType=application/xml", 
		"BodyBinary=\\xD0\\x0E\\x00\\x00<?xml version=\"1.0\"?>\n<req ver=\"2\">\n <tlm>\n  <src>\n   <desc>\n    <mach>\n     <os>\n      <arg nm=\"vermaj\" val=\"10\"/>\n      <arg nm=\"vermin\" val=\"0\"/>\n      <arg nm=\"verbld\" val=\"22621\"/>\n      <arg nm=\"vercsdbld\" val=\"3447\"/>\n      <arg nm=\"verqfe\" val=\"3447\"/>\n      <arg nm=\"csdbld\" val=\"3447\"/>\n      <arg nm=\"versp\" val=\"0\"/>\n      <arg nm=\"arch\" val=\"9\"/>\n      <arg nm=\"lcid\" val=\"1049\"/>\n      <arg nm=\""
		"geoid\" val=\"203\"/>\n      <arg nm=\"sku\" val=\"100\"/>\n      <arg nm=\"domain\" val=\"0\"/>\n      <arg nm=\"portos\" val=\"0\"/>\n      <arg nm=\"ram\" val=\"10178\"/>\n      <arg nm=\"svolsz\" val=\"475\"/>\n      <arg nm=\"wimbt\" val=\"0\"/>\n      <arg nm=\"blddt\" val=\"220506\"/>\n      <arg nm=\"bldtm\" val=\"1250\"/>\n      <arg nm=\"bldbrch\" val=\"ni_release\"/>\n      <arg nm=\"os\" val=\"Windows\"/>\n      <arg nm=\"osver\" val=\"10.0.22621.3447.amd64fre.ni_release.220506-1250\"/"
		">\n      <arg nm=\"buildflightid\" val=\"2C34B461-1255-485F-8845-420F1E8BA2E3.1\"/>\n      <arg nm=\"expid\" val=\"RS:19AAF\"/>\n      <arg nm=\"edition\" val=\"CoreSingleLanguage\"/>\n     </os>\n     <hw>\n      <arg nm=\"form\" val=\"2\"/>\n      <arg nm=\"arch\" val=\"9\"/>\n      <arg nm=\"deviceclass\" val=\"Windows.Desktop\"/>\n      <arg nm=\"sysmfg\" val=\"LENOVO\"/>\n      <arg nm=\"syspro\" val=\"81NC\"/>\n      <arg nm=\"bv\" val=\"AMCN26WW(V1.09)\"/>\n      <arg nm=\"ram\" val=\""
		"12288\"/>\n      <arg nm=\"proccnt\" val=\"8\"/>\n      <arg nm=\"proclsp\" val=\"2296\"/>\n      <arg nm=\"wscpusc\" val=\"0\"/>\n      <arg nm=\"wsdsksc\" val=\"0\"/>\n      <arg nm=\"wscpudn\" val=\"AMD Ryzen 7 3700U with Radeon Vega Mobile Gfx  \"/>\n      <arg nm=\"wsdgsc\" val=\"0\"/>\n      <arg nm=\"aoac\" val=\"0\"/>\n      <arg nm=\"bssku\" val=\"LENOVO_MT_81NC_BU_idea_FM_IdeaPad S340-15API\"/>\n      <arg nm=\"chid\" val=\"{f2def22a-533a-5854-80c0-e4d4975be589}\"/>\n      <arg nm=\""
		"sdksz\" val=\"476\"/>\n     </hw>\n     <ctrl>\n      <arg nm=\"tm\" val=\"133575637220186840\"/>\n      <arg nm=\"mid\" val=\"35B0B1E1-AF52-4219-BA84-001C4F6E30CD\"/>\n      <arg nm=\"sample\" val=\"67722097\"/>\n      <arg nm=\"msft\" val=\"0\"/>\n      <arg nm=\"test\" val=\"0\"/>\n      <arg nm=\"scf\" val=\"0\"/>\n      <arg nm=\"commercialid\" val=\"\"/>\n      <arg nm=\"telemetry\" val=\"Optional\"/>\n     </ctrl>\n    </mach>\n   </desc>\n  </src>\n  <reqs>\n   <req key=\"1\">\n    "
		"<namespace svc=\"watson\" ptr=\"generic\" gp=\"generic\" app=\"msedge.exe\">\n     <arg nm=\"p1\" val=\"msedge.exe\"/>\n     <arg nm=\"p2\" val=\"123.0.2420.81\"/>\n     <arg nm=\"p3\" val=\"msedge_elf.dll\"/>\n     <arg nm=\"p4\" val=\"123.0.2420.81\"/>\n     <arg nm=\"p5\" val=\"3039847\"/>\n     <arg nm=\"p6\" val=\"utility\"/>\n     <arg nm=\"p7\" val=\"0x517a7ed\"/>\n     <arg nm=\"p8\" val=\"0\"/>\n    </namespace>\n    <ctrl>\n     <arg nm=\"reportid\" val=\""
		"cec7ab52-9904-4f61-be17-ce280805d66b\"/>\n     <arg nm=\"procmeta.Channel\" val=\"\"/>\n     <arg nm=\"procmeta.MetricsClientId\" val=\"a9f26822-0148-449d-839d-c1f5b6ea6f6f\"/>\n     <arg nm=\"procmeta.MetricsClientIdHash\" val=\"3337287604877298657\"/>\n     <arg nm=\"procmeta.MetricsSessionId\" val=\"476\"/>\n     <arg nm=\"procmeta.OfficialBuild\" val=\"1\"/>\n     <arg nm=\"procmeta.RuntimeVariationsSeedETag\" val=\"&quot;ak7HcQpnlZn8m9aTyRR+TBlDs+Nu0eAPyPPJlhBg3/g=&quot;\"/>\n     <arg nm=\""
		"procmeta.UXConfigCorrelationId\" val=\"htUAmUE/s5srHwFFnrD6S8HhSDlCxS4N4+NzDmg9iGA=\"/>\n     <arg nm=\"procmeta.VariationsSeedETag\" val=\"&quot;CkuAmlPxHz2CRaInBV6iam5U2dRk7lDEzgtb+B9NUT8=&quot;\"/>\n    </ctrl>\n    <cmd nm=\"event\">\n     <arg nm=\"eventtype\" val=\"crashpad_exp\"/>\n     <arg nm=\"cat\" val=\"generic\"/>\n     <arg nm=\"p1\" val=\"msedge.exe\"/>\n     <arg nm=\"p2\" val=\"123.0.2420.81\"/>\n     <arg nm=\"p3\" val=\"msedge_elf.dll\"/>\n     <arg nm=\"p4\" val=\""
		"123.0.2420.81\"/>\n     <arg nm=\"p5\" val=\"3039847\"/>\n     <arg nm=\"p6\" val=\"utility\"/>\n     <arg nm=\"p7\" val=\"0x517a7ed\"/>\n     <arg nm=\"p8\" val=\"0\"/>\n     <arg nm=\"appsessionguid\" val=\"00003fc4-0001-003e-e78f-cc92558eda01\"/>\n    </cmd>\n   </req>\n  </reqs>\n </tlm>\n</req>\n", 
		LAST);

	return 0;
}